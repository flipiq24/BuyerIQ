#!/bin/bash
npx tsx scripts/seed-database.ts