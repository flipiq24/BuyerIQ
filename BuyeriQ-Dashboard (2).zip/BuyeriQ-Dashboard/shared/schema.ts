import { pgTable, text, serial, integer, boolean, date, numeric, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Communication Module Enums
export const contactTypeEnum = pgEnum('contact_type', ['INVESTOR', 'AGENT', 'OFFICE', 'LENDER']);
export const channelTypeEnum = pgEnum('channel_type', ['CALL', 'SMS', 'EMAIL', 'VM']);
export const directionEnum = pgEnum('direction', ['OUTBOUND', 'INBOUND']);
export const statusEnum = pgEnum('status', ['QUEUED', 'SENT', 'DELIVERED', 'FAILED', 'PENDING', 'COMPLETE']);

// Counties
export const counties = pgTable("counties", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  value: text("value").notNull().unique(),
});

export const insertCountySchema = createInsertSchema(counties).pick({
  name: true,
  value: true,
});

export type InsertCounty = z.infer<typeof insertCountySchema>;
export type County = typeof counties.$inferSelect;

// Cities
export const cities = pgTable("cities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  value: text("value").notNull(),
  countyId: integer("county_id").notNull(),
});

export const insertCitySchema = createInsertSchema(cities).pick({
  name: true,
  value: true,
  countyId: true,
});

export type InsertCity = z.infer<typeof insertCitySchema>;
export type City = typeof cities.$inferSelect;

// Zip Codes
export const zipCodes = pgTable("zip_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull(),
  value: text("value").notNull(),
  cityId: integer("city_id").notNull(),
});

export const insertZipCodeSchema = createInsertSchema(zipCodes).pick({
  code: true,
  value: true,
  cityId: true,
});

export type InsertZipCode = z.infer<typeof insertZipCodeSchema>;
export type ZipCode = typeof zipCodes.$inferSelect;

// Investors
export const investors = pgTable("investors", {
  id: serial("id").primaryKey(),
  entityName: text("entity_name").notNull(),
  location: text("location").notNull(),
  lastPurchaseDate: date("last_purchase_date"),
  totalTransactions: integer("total_transactions").default(0),
  avgPurchasePrice: numeric("avg_purchase_price"),
  avgResalePrice: numeric("avg_resale_price"),
  purchaseToFutureValueRatio: numeric("purchase_to_future_value_ratio"),
  listToSoldPriceRatio: numeric("list_to_sold_price_ratio"),
  purchaseToMarketRatio: numeric("purchase_to_market_ratio"),
  purchaseToResaleRatio: numeric("purchase_to_resale_ratio"),
  financingType: text("financing_type").notNull(),
  agentRelationships: text("agent_relationships").default("0/0/0/0"),
  lastPropertyNumber: text("last_property_number"),
  lastPropertyAddress: text("last_property_address"),
  lastPropertyCity: text("last_property_city"),
  countyId: integer("county_id"),
  cityId: integer("city_id"),
  zipCodeId: integer("zip_code_id"),
  address: text("address"),
});

export const insertInvestorSchema = createInsertSchema(investors).pick({
  entityName: true,
  location: true,
  lastPurchaseDate: true,
  totalTransactions: true,
  avgPurchasePrice: true,
  avgResalePrice: true,
  purchaseToFutureValueRatio: true,
  listToSoldPriceRatio: true,
  purchaseToMarketRatio: true,
  purchaseToResaleRatio: true,
  financingType: true,
  agentRelationships: true,
  lastPropertyNumber: true,
  lastPropertyAddress: true,
  lastPropertyCity: true,
  countyId: true,
  cityId: true,
  zipCodeId: true,
  address: true,
});

export type InsertInvestor = z.infer<typeof insertInvestorSchema>;
export type Investor = typeof investors.$inferSelect;

// Agents
export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  agentName: text("agent_name").notNull(),
  avgTransactionPrice: numeric("avg_transaction_price"),
  totalTransactionsWithInvestors: integer("total_transactions_with_investors").default(0),
  listingsSoldToInvestors: integer("listings_sold_to_investors").default(0),
  percentageDoubleEndTransactions: numeric("percentage_double_end_transactions"),
  mostRecentBuyerTransaction: date("most_recent_buyer_transaction"),
  officeRepresentingBuyers: text("office_representing_buyers"),
  listingsResoldForInvestors: integer("listings_resold_for_investors").default(0),
  uniqueInvestorRelationships: integer("unique_investor_relationships").default(0),
  lastInvestorProperty: text("last_investor_property"),
  countyId: integer("county_id"),
  cityId: integer("city_id"),
  zipCodeId: integer("zip_code_id"),
  address: text("address"),
});

export const insertAgentSchema = createInsertSchema(agents).pick({
  agentName: true,
  avgTransactionPrice: true,
  totalTransactionsWithInvestors: true,
  listingsSoldToInvestors: true,
  percentageDoubleEndTransactions: true,
  mostRecentBuyerTransaction: true,
  officeRepresentingBuyers: true,
  listingsResoldForInvestors: true,
  uniqueInvestorRelationships: true,
  lastInvestorProperty: true,
  countyId: true,
  cityId: true,
  zipCodeId: true,
  address: true,
});

export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type Agent = typeof agents.$inferSelect;

// Offices
export const offices = pgTable("offices", {
  id: serial("id").primaryKey(),
  officeName: text("office_name").notNull(),
  avgTransactionPrice: numeric("avg_transaction_price"),
  totalTransactionsWithInvestors: integer("total_transactions_with_investors").default(0),
  listingsSoldToInvestors: integer("listings_sold_to_investors").default(0),
  buyerRepresentationTransactions: integer("buyer_representation_transactions").default(0),
  listingsResoldForInvestors: integer("listings_resold_for_investors").default(0),
  uniqueInvestorRelationships: integer("unique_investor_relationships").default(0),
  countyId: integer("county_id"),
  cityId: integer("city_id"),
  zipCodeId: integer("zip_code_id"),
  address: text("address"),
});

export const insertOfficeSchema = createInsertSchema(offices).pick({
  officeName: true,
  avgTransactionPrice: true,
  totalTransactionsWithInvestors: true,
  listingsSoldToInvestors: true,
  buyerRepresentationTransactions: true,
  listingsResoldForInvestors: true,
  uniqueInvestorRelationships: true,
  countyId: true,
  cityId: true,
  zipCodeId: true,
  address: true,
});

export type InsertOffice = z.infer<typeof insertOfficeSchema>;
export type Office = typeof offices.$inferSelect;

// Lenders
export const lenders = pgTable("lenders", {
  id: serial("id").primaryKey(),
  lenderName: text("lender_name").notNull(),
  avgLoanAmount: numeric("avg_loan_amount"),
  avgLoanToPurchasePriceRatio: numeric("avg_loan_to_purchase_price_ratio"),
  totalTransactionsToInvestors: integer("total_transactions_to_investors").default(0),
  uniqueInvestorRelationships: integer("unique_investor_relationships").default(0),
  avgLoansPerRelationship: numeric("avg_loans_per_relationship"),
  countyId: integer("county_id"),
  cityId: integer("city_id"),
  zipCodeId: integer("zip_code_id"),
  address: text("address"),
});

export const insertLenderSchema = createInsertSchema(lenders).pick({
  lenderName: true,
  avgLoanAmount: true,
  avgLoanToPurchasePriceRatio: true,
  totalTransactionsToInvestors: true,
  uniqueInvestorRelationships: true,
  avgLoansPerRelationship: true,
  countyId: true,
  cityId: true,
  zipCodeId: true,
  address: true,
});

export type InsertLender = z.infer<typeof insertLenderSchema>;
export type Lender = typeof lenders.$inferSelect;

// Filter Params
export const filterParamsSchema = z.object({
  county: z.string().optional(),
  city: z.string().optional(),
  zipCode: z.string().optional(),
  address: z.string().optional(),
  radius: z.coerce.number().min(1).max(30).default(10),
  name: z.string().optional(),
  minUnits: z.string().optional(),
  maxUnits: z.string().optional(),
  doubleEnd: z.boolean().optional(),
  filterByHometown: z.boolean().optional(),
  page: z.number().int().positive().default(1),
  pageSize: z.number().int().positive().default(10),
  sortBy: z.string().optional(),
  sortOrder: z.enum(["asc", "desc"]).default("asc"),
  sortByEntityTotals: z.boolean().optional().default(false),
});

export type FilterParams = z.infer<typeof filterParamsSchema>;

// Communication Module Tables
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  type: contactTypeEnum("type").notNull(),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  llcId: text("llc_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  entityId: integer("entity_id").notNull(), // References investor, agent, office, or lender id
  optOut: boolean("opt_out").default(false),
  notes: text("notes"),
});

export const insertContactSchema = createInsertSchema(contacts).pick({
  type: true,
  name: true,
  phone: true,
  email: true,
  llcId: true,
  entityId: true,
  optOut: true,
  notes: true,
});

export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  contactId: integer("contact_id").notNull(),
  channel: channelTypeEnum("channel").notNull(),
  direction: directionEnum("direction").notNull(),
  body: text("body"),
  status: statusEnum("status").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  metadata: text("metadata"), // JSON stringified
  externalId: text("external_id"), // Twilio/SendGrid ID
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  contactId: true,
  channel: true,
  direction: true,
  body: true,
  status: true,
  metadata: true,
  externalId: true,
});

export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;

export const aiTasks = pgTable("ai_tasks", {
  id: serial("id").primaryKey(),
  contactId: integer("contact_id").notNull(),
  templateKey: text("template_key").notNull(),
  dueAt: timestamp("due_at").notNull(),
  status: statusEnum("status").notNull(),
  threadId: text("thread_id"), // OpenAI thread reference
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  result: text("result"), // Result description
});

export const insertAiTaskSchema = createInsertSchema(aiTasks).pick({
  contactId: true,
  templateKey: true,
  dueAt: true,
  status: true,
  threadId: true,
  result: true,
});

export type InsertAiTask = z.infer<typeof insertAiTaskSchema>;
export type AiTask = typeof aiTasks.$inferSelect;

export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  name: text("name").notNull(),
  channel: channelTypeEnum("channel").notNull(),
  body: text("body").notNull(),
  variables: text("variables"), // JSON stringified list of variables
  followUp: text("follow_up"), // JSON stringified follow-up rules
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertTemplateSchema = createInsertSchema(templates).pick({
  key: true,
  name: true,
  channel: true,
  body: true,
  variables: true,
  followUp: true,
});

export type InsertTemplate = z.infer<typeof insertTemplateSchema>;
export type Template = typeof templates.$inferSelect;

export const corporations = pgTable("corporations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  address: text("address"),
  filingNumber: text("filing_number"),
  status: text("status"),
  registeredAgent: text("registered_agent"),
  officerName: text("officer_name"),
  officerAddress: text("officer_address"),
  dataSource: text("data_source"), // e.g., "opencorporates"
  fetchedAt: timestamp("fetched_at"),
  rawData: text("raw_data"), // JSON stringified 
});

export const insertCorporationSchema = createInsertSchema(corporations).pick({
  name: true,
  address: true,
  filingNumber: true,
  status: true,
  registeredAgent: true,
  officerName: true,
  officerAddress: true,
  dataSource: true,
  rawData: true,
});

export type InsertCorporation = z.infer<typeof insertCorporationSchema>;
export type Corporation = typeof corporations.$inferSelect;

// Communication Filter Parameters
export const commFilterParamsSchema = z.object({
  type: z.enum(['INVESTOR', 'AGENT', 'OFFICE', 'LENDER']).optional(),
  searchTerm: z.string().optional(),
  county: z.string().optional(),
  city: z.string().optional(),
  hasPhone: z.boolean().optional(),
  hasEmail: z.boolean().optional(),
  hasActivity: z.boolean().optional(), // Has previous conversations
  page: z.number().int().positive().default(1),
  pageSize: z.number().int().positive().default(10),
  sortBy: z.string().optional(),
  sortOrder: z.enum(["asc", "desc"]).default("asc"),
});

export type CommFilterParams = z.infer<typeof commFilterParamsSchema>;

// Properties Table
export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  address: text("address"),
  unit_type: text("unit_type"),
  unit_number: text("unit_number"),
  city: text("city"),
  county: text("county"),
  state: text("state"),
  zipcode: text("zipcode"),
  latitude: numeric("latitude"),
  longitude: numeric("longitude"),
  current_owner: text("current_owner"),
  investor: text("investor"),
  lender: text("lender"),
  // Mailing address fields
  mailing_address: text("mailing_address"),
  mailing_unit_type: text("mailing_unit_type"),
  mailing_unit_number: text("mailing_unit_number"),
  mailing_city: text("mailing_city"),
  mailing_state: text("mailing_state"),
  mailing_zip: text("mailing_zip"),
  mailing_zip4: text("mailing_zip4"),
});

export const insertPropertiesSchema = createInsertSchema(properties).pick({
  address: true,
  unit_type: true,
  unit_number: true,
  city: true,
  county: true,
  state: true,
  zipcode: true,
  latitude: true,
  longitude: true,
  current_owner: true,
  investor: true,
  lender: true,
  mailing_address: true,
  mailing_unit_type: true,
  mailing_unit_number: true,
  mailing_city: true,
  mailing_state: true,
  mailing_zip: true,
  mailing_zip4: true,
});

export type InsertProperty = z.infer<typeof insertPropertiesSchema>;
export type Property = typeof properties.$inferSelect;
