import {
  InsertCounty, County, InsertCity, City, InsertZipCode, ZipCode,
  InsertInvestor, Investor, InsertAgent, Agent, InsertOffice, Office,
  InsertLender, Lender, FilterParams, InsertContact, Contact, CommFilterParams,
  InsertConversation, Conversation, InsertAiTask, AiTask, InsertTemplate, Template,
  InsertCorporation, Corporation, InsertProperty, Property
} from "@shared/schema";
import { db, externalDb } from "./db";
import {
  counties, cities, zipCodes, investors, agents, offices, lenders,
  contacts, conversations, aiTasks, templates, corporations, properties
} from "@shared/schema";
import { eq, like, ilike, and, or, inArray, gte, lte, desc, asc } from "drizzle-orm";
import { sql } from "drizzle-orm/sql";
import { alias } from "drizzle-orm/pg-core";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export type SaveSearchParams = {
  name: string;
  tabType: 'investors' | 'agents' | 'offices' | 'lenders';
  filters: FilterParams;
};

export type SavedSearch = {
  id: number;
  name: string;
  userId: number;
  tabType: 'investors' | 'agents' | 'offices' | 'lenders';
  filters: FilterParams;
  createdAt: Date;
};

export interface IStorage {
  // Session Store
  sessionStore: session.Store;

  // Counties
  getCounties(): Promise<County[]>;
  getCountyById(id: number): Promise<County | undefined>;
  getCountyByValue(value: string): Promise<County | undefined>;
  createCounty(county: InsertCounty): Promise<County>;

  // Cities
  getCitiesByCounty(countyId: number): Promise<City[]>;
  getCityById(id: number): Promise<City | undefined>;
  getCityByValue(value: string, countyId: number): Promise<City | undefined>;
  createCity(city: InsertCity): Promise<City>;

  // Zip Codes
  getZipCodesByCity(cityId: number): Promise<ZipCode[]>;
  getZipCodeById(id: number): Promise<ZipCode | undefined>;
  getZipCodeByValue(value: string, cityId: number): Promise<ZipCode | undefined>;
  createZipCode(zipCode: InsertZipCode): Promise<ZipCode>;

  // Investors
  getInvestors(filters: FilterParams): Promise<{ 
    results: Investor[]; 
    total: number; 
    totalPages: number;
    resultTotals?: any;
    entityTotals?: any;
  }>;
  getInvestorById(id: number): Promise<Investor | undefined>;
  createInvestor(investor: InsertInvestor): Promise<Investor>;

  // Agents
  getAgents(filters: FilterParams): Promise<{ 
    results: Agent[]; 
    total: number; 
    totalPages: number;
    resultTotals?: any;
    entityTotals?: any;
  }>;
  getAgentById(id: number): Promise<Agent | undefined>;
  createAgent(agent: InsertAgent): Promise<Agent>;

  // Offices
  getOffices(filters: FilterParams): Promise<{ 
    results: Office[]; 
    total: number; 
    totalPages: number;
    resultTotals?: any;
    entityTotals?: any; 
  }>;
  getOfficeById(id: number): Promise<Office | undefined>;
  createOffice(office: InsertOffice): Promise<Office>;

  // Lenders
  getLenders(filters: FilterParams): Promise<{ 
    results: Lender[]; 
    total: number; 
    totalPages: number;
    resultTotals?: any;
    entityTotals?: any;
  }>;
  getLenderById(id: number): Promise<Lender | undefined>;
  createLender(lender: InsertLender): Promise<Lender>;
  
  // Saved Searches
  getSavedSearches(userId: number): Promise<SavedSearch[]>;
  getSavedSearchById(id: number): Promise<SavedSearch | undefined>;
  createSavedSearch(search: SaveSearchParams, userId: number): Promise<SavedSearch>;
  deleteSavedSearch(id: number): Promise<void>;
  
  // Communication Module
  
  // Contacts
  getContacts(filters: CommFilterParams): Promise<{ results: Contact[]; total: number; totalPages: number }>;
  getContactById(id: number): Promise<Contact | undefined>;
  getContactByEntityId(type: string, entityId: number): Promise<Contact | undefined>;
  createContact(contact: InsertContact): Promise<Contact>;
  updateContact(id: number, contact: Partial<InsertContact>): Promise<Contact>;
  
  // Conversations
  getConversationsByContactId(contactId: number): Promise<Conversation[]>;
  getConversationById(id: number): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversationStatus(id: number, status: string): Promise<Conversation>;
  
  // AI Tasks
  getTasksByContactId(contactId: number): Promise<AiTask[]>;
  getTaskById(id: number): Promise<AiTask | undefined>;
  createTask(task: InsertAiTask): Promise<AiTask>;
  updateTaskStatus(id: number, status: string, result?: string): Promise<AiTask>;
  updateTaskThread(id: number, threadId: string): Promise<AiTask>;
  getPendingTasks(): Promise<AiTask[]>;
  
  // Templates
  getTemplates(channel?: string): Promise<Template[]>;
  getTemplateByKey(key: string): Promise<Template | undefined>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  updateTemplate(key: string, template: Partial<InsertTemplate>): Promise<Template>;
  
  // Corporations
  getCorporations(): Promise<Corporation[]>;
  getCorporationById(id: number): Promise<Corporation | undefined>;
  getCorporationByName(name: string): Promise<Corporation | undefined>;
  createCorporation(corporation: InsertCorporation): Promise<Corporation>;
  updateCorporation(id: number, corporation: Partial<InsertCorporation>): Promise<Corporation>;
  
  // Properties
  getProperties(filters: any): Promise<{ results: Property[]; total: number; totalPages: number }>;
  getPropertyById(id: number): Promise<Property | undefined>;
  createProperty(property: InsertProperty): Promise<Property>;
  updateProperty(id: number, property: Partial<InsertProperty>): Promise<Property>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true
    });
  }

  // County methods
  async getCounties(): Promise<County[]> {
    return await db.select().from(counties).orderBy(counties.name);
  }

  async getCountyById(id: number): Promise<County | undefined> {
    const [result] = await db.select().from(counties).where(eq(counties.id, id));
    return result;
  }

  async getCountyByValue(value: string): Promise<County | undefined> {
    const [result] = await db.select().from(counties).where(eq(counties.value, value));
    return result;
  }

  async createCounty(county: InsertCounty): Promise<County> {
    const [result] = await db.insert(counties).values(county).returning();
    return result;
  }

  // City methods
  async getCitiesByCounty(countyId: number): Promise<City[]> {
    return await db.select().from(cities).where(eq(cities.countyId, countyId)).orderBy(cities.name);
  }

  async getCityById(id: number): Promise<City | undefined> {
    const [result] = await db.select().from(cities).where(eq(cities.id, id));
    return result;
  }

  async getCityByValue(value: string, countyId: number): Promise<City | undefined> {
    const [result] = await db.select().from(cities).where(
      and(eq(cities.value, value), eq(cities.countyId, countyId))
    );
    return result;
  }

  async createCity(city: InsertCity): Promise<City> {
    const [result] = await db.insert(cities).values(city).returning();
    return result;
  }

  // Zip Code methods
  async getZipCodesByCity(cityId: number): Promise<ZipCode[]> {
    return await db.select().from(zipCodes).where(eq(zipCodes.cityId, cityId)).orderBy(zipCodes.code);
  }

  async getZipCodeById(id: number): Promise<ZipCode | undefined> {
    const [result] = await db.select().from(zipCodes).where(eq(zipCodes.id, id));
    return result;
  }

  async getZipCodeByValue(value: string, cityId: number): Promise<ZipCode | undefined> {
    const [result] = await db.select().from(zipCodes).where(
      and(eq(zipCodes.value, value), eq(zipCodes.cityId, cityId))
    );
    return result;
  }

  async createZipCode(zipCode: InsertZipCode): Promise<ZipCode> {
    const [result] = await db.insert(zipCodes).values(zipCode).returning();
    return result;
  }

  // Investor methods
  async getInvestors(filters: FilterParams): Promise<{ 
    results: Investor[]; 
    total: number; 
    totalPages: number;
    resultTotals?: any;
    entityTotals?: any;
  }> {
    const { page = 1, pageSize = 10, sortBy, sortOrder = 'asc', name, county, city, zipCode, address } = filters;
    
    const offset = (page - 1) * pageSize;
    const limit = pageSize;
    
    let whereClause = sql`1 = 1`;
    
    if (name) {
      whereClause = sql`${whereClause} AND ${investors.entityName} ILIKE ${`%${name}%`}`;
    }
    
    if (county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        whereClause = sql`${whereClause} AND ${investors.countyId} = ${countyRecord.id}`;
      }
    }
    
    if (city && county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        const cityRecord = await this.getCityByValue(city, countyRecord.id);
        if (cityRecord) {
          whereClause = sql`${whereClause} AND ${investors.cityId} = ${cityRecord.id}`;
        }
      }
    }
    
    if (zipCode && city && county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        const cityRecord = await this.getCityByValue(city, countyRecord.id);
        if (cityRecord) {
          const zipCodeRecord = await this.getZipCodeByValue(zipCode, cityRecord.id);
          if (zipCodeRecord) {
            whereClause = sql`${whereClause} AND ${investors.zipCodeId} = ${zipCodeRecord.id}`;
          }
        }
      }
    }
    
    if (address) {
      whereClause = sql`${whereClause} AND ${investors.address} ILIKE ${`%${address}%`}`;
    }
    
    // Calculate total count
    const [{ count }] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(investors)
      .where(whereClause);
    
    const totalPages = Math.ceil(count / pageSize);
    
    // Build the query to fetch data
    let query = db
      .select()
      .from(investors)
      .where(whereClause)
      .limit(limit)
      .offset(offset);
    
    // Add sorting if specified
    if (sortBy) {
      if (sortOrder === 'desc') {
        query = query.orderBy(desc(sql.raw(`"${sortBy}"`)));
      } else {
        query = query.orderBy(asc(sql.raw(`"${sortBy}"`)));
      }
    } else {
      // Default sorting by entity name
      query = query.orderBy(asc(investors.entityName));
    }
    
    const results = await query;
    
    // For entity totals, we need to get the entities that match the filter criteria
    // but then use their unfiltered data for the totals
    const matchingInvestors = await db
      .select({ id: investors.id })
      .from(investors)
      .where(whereClause);
    
    const matchingIds = matchingInvestors.map(inv => inv.id);
    
    // Get the complete, unfiltered data for the matching entities
    const entityTotals = await db
      .select()
      .from(investors)
      .where(inArray(investors.id, matchingIds));
      
    // Calculate result totals for filtered investors
    const [resultTotals] = await db
      .select({
        totalTransactions: sql<number>`SUM(${investors.totalTransactions})`,
        avgPurchasePrice: sql<string>`TO_CHAR(AVG(NULLIF(${investors.avgPurchasePrice}, 0)), 'FM$999,999,999')`,
        avgResalePrice: sql<string>`TO_CHAR(AVG(NULLIF(${investors.avgResalePrice}, 0)), 'FM$999,999,999')`,
        avgPurchaseToFutureValueRatio: sql<string>`TO_CHAR(AVG(NULLIF(${investors.purchaseToFutureValueRatio}, 0)) * 100, 'FM990.0%')`,
        avgListToSoldPriceRatio: sql<string>`TO_CHAR(AVG(NULLIF(${investors.listToSoldPriceRatio}, 0)) * 100, 'FM990.0%')`,
        avgPurchaseToMarketRatio: sql<string>`TO_CHAR(AVG(NULLIF(${investors.purchaseToMarketRatio}, 0)) * 100, 'FM990.0%')`,
        avgPurchaseToResaleRatio: sql<string>`TO_CHAR(AVG(NULLIF(${investors.purchaseToResaleRatio}, 0)) * 100, 'FM990.0%')`,
      })
      .from(investors)
      .where(whereClause);
    
    return {
      results,
      total: Number(count),
      totalPages,
      resultTotals,
      entityTotals
    };
  }

  async getInvestorById(id: number): Promise<Investor | undefined> {
    const [result] = await db.select().from(investors).where(eq(investors.id, id));
    return result;
  }

  async createInvestor(investor: InsertInvestor): Promise<Investor> {
    const [result] = await db.insert(investors).values(investor).returning();
    return result;
  }

  // Agent methods
  async getAgents(filters: FilterParams): Promise<{ 
    results: Agent[]; 
    total: number; 
    totalPages: number; 
    resultTotals?: any;
    entityTotals?: any;
  }> {
    const { page = 1, pageSize = 10, sortBy, sortOrder = 'asc', name, county, city, zipCode, address } = filters;
    
    const offset = (page - 1) * pageSize;
    const limit = pageSize;
    
    let whereClause = sql`1 = 1`;
    
    if (name) {
      whereClause = sql`${whereClause} AND ${agents.agentName} ILIKE ${`%${name}%`}`;
    }
    
    if (county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        whereClause = sql`${whereClause} AND ${agents.countyId} = ${countyRecord.id}`;
      }
    }
    
    if (city && county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        const cityRecord = await this.getCityByValue(city, countyRecord.id);
        if (cityRecord) {
          whereClause = sql`${whereClause} AND ${agents.cityId} = ${cityRecord.id}`;
        }
      }
    }
    
    if (zipCode && city && county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        const cityRecord = await this.getCityByValue(city, countyRecord.id);
        if (cityRecord) {
          const zipCodeRecord = await this.getZipCodeByValue(zipCode, cityRecord.id);
          if (zipCodeRecord) {
            whereClause = sql`${whereClause} AND ${agents.zipCodeId} = ${zipCodeRecord.id}`;
          }
        }
      }
    }
    
    if (address) {
      whereClause = sql`${whereClause} AND ${agents.address} ILIKE ${`%${address}%`}`;
    }
    
    // Calculate total count
    const [{ count }] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(agents)
      .where(whereClause);
    
    const totalPages = Math.ceil(count / pageSize);
    
    // Build the query to fetch data
    let query = db
      .select()
      .from(agents)
      .where(whereClause)
      .limit(limit)
      .offset(offset);
    
    // Add sorting if specified
    if (sortBy) {
      if (sortOrder === 'desc') {
        query = query.orderBy(desc(sql.raw(`"${sortBy}"`)));
      } else {
        query = query.orderBy(asc(sql.raw(`"${sortBy}"`)));
      }
    } else {
      // Default sorting by agent name
      query = query.orderBy(asc(agents.agentName));
    }
    
    const results = await query;
    
    // For entity totals, we need to get the entities that match the filter criteria
    // but then use their unfiltered data for the totals
    const matchingAgents = await db
      .select({ id: agents.id })
      .from(agents)
      .where(whereClause);
    
    const matchingIds = matchingAgents.map(agent => agent.id);
    
    // Get the complete, unfiltered data for the matching entities
    const entityTotals = await db
      .select()
      .from(agents)
      .where(inArray(agents.id, matchingIds));
    
    // Calculate result totals for filtered agents
    const [resultTotals] = await db
      .select({
        totalTransactionsWithInvestors: sql<number>`SUM(${agents.totalTransactionsWithInvestors})`,
        listingsSoldToInvestors: sql<number>`SUM(${agents.listingsSoldToInvestors})`,
        listingsResoldForInvestors: sql<number>`SUM(${agents.listingsResoldForInvestors})`,
        uniqueInvestorRelationships: sql<number>`SUM(${agents.uniqueInvestorRelationships})`,
        avgTransactionPrice: sql<string>`TO_CHAR(AVG(NULLIF(${agents.avgTransactionPrice}, 0)), 'FM$999,999,999')`,
        avgPercentageDoubleEndTransactions: sql<string>`TO_CHAR(AVG(NULLIF(${agents.percentageDoubleEndTransactions}, 0)) * 100, 'FM990.0%')`,
      })
      .from(agents)
      .where(whereClause);
    
    return {
      results,
      total: Number(count),
      totalPages,
      resultTotals,
      entityTotals
    };
  }

  async getAgentById(id: number): Promise<Agent | undefined> {
    const [result] = await db.select().from(agents).where(eq(agents.id, id));
    return result;
  }

  async createAgent(agent: InsertAgent): Promise<Agent> {
    const [result] = await db.insert(agents).values(agent).returning();
    return result;
  }

  // Office methods
  async getOffices(filters: FilterParams): Promise<{ 
    results: Office[]; 
    total: number; 
    totalPages: number;
    resultTotals?: any;
    entityTotals?: any;
  }> {
    const { page = 1, pageSize = 10, sortBy, sortOrder = 'asc', name, county, city, zipCode, address } = filters;
    
    const offset = (page - 1) * pageSize;
    const limit = pageSize;
    
    let whereClause = sql`1 = 1`;
    
    if (name) {
      whereClause = sql`${whereClause} AND ${offices.officeName} ILIKE ${`%${name}%`}`;
    }
    
    if (county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        whereClause = sql`${whereClause} AND ${offices.countyId} = ${countyRecord.id}`;
      }
    }
    
    if (city && county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        const cityRecord = await this.getCityByValue(city, countyRecord.id);
        if (cityRecord) {
          whereClause = sql`${whereClause} AND ${offices.cityId} = ${cityRecord.id}`;
        }
      }
    }
    
    if (zipCode && city && county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        const cityRecord = await this.getCityByValue(city, countyRecord.id);
        if (cityRecord) {
          const zipCodeRecord = await this.getZipCodeByValue(zipCode, cityRecord.id);
          if (zipCodeRecord) {
            whereClause = sql`${whereClause} AND ${offices.zipCodeId} = ${zipCodeRecord.id}`;
          }
        }
      }
    }
    
    if (address) {
      whereClause = sql`${whereClause} AND ${offices.address} ILIKE ${`%${address}%`}`;
    }
    
    // Calculate total count
    const [{ count }] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(offices)
      .where(whereClause);
    
    const totalPages = Math.ceil(count / pageSize);
    
    // Build the query to fetch data
    let query = db
      .select()
      .from(offices)
      .where(whereClause)
      .limit(limit)
      .offset(offset);
    
    // Add sorting if specified
    if (sortBy) {
      if (sortOrder === 'desc') {
        query = query.orderBy(desc(sql.raw(`"${sortBy}"`)));
      } else {
        query = query.orderBy(asc(sql.raw(`"${sortBy}"`)));
      }
    } else {
      // Default sorting by office name
      query = query.orderBy(asc(offices.officeName));
    }
    
    const results = await query;
    
    // For entity totals, we need to get the entities that match the filter criteria
    // but then use their unfiltered data for the totals
    const matchingOffices = await db
      .select({ id: offices.id })
      .from(offices)
      .where(whereClause);
    
    const matchingIds = matchingOffices.map(office => office.id);
    
    // Get the complete, unfiltered data for the matching entities
    const entityTotals = await db
      .select()
      .from(offices)
      .where(inArray(offices.id, matchingIds));
    
    // Calculate result totals for filtered offices
    const [resultTotals] = await db
      .select({
        totalTransactionsWithInvestors: sql<number>`SUM(${offices.totalTransactionsWithInvestors})`,
        listingsSoldToInvestors: sql<number>`SUM(${offices.listingsSoldToInvestors})`,
        listingsResoldForInvestors: sql<number>`SUM(${offices.listingsResoldForInvestors})`,
        uniqueInvestorRelationships: sql<number>`SUM(${offices.uniqueInvestorRelationships})`,
        buyerRepresentationTransactions: sql<number>`SUM(${offices.buyerRepresentationTransactions})`,
        avgTransactionPrice: sql<string>`TO_CHAR(AVG(NULLIF(${offices.avgTransactionPrice}, 0)), 'FM$999,999,999')`,
      })
      .from(offices)
      .where(whereClause);
    
    return {
      results,
      total: Number(count),
      totalPages,
      resultTotals,
      entityTotals
    };
  }

  async getOfficeById(id: number): Promise<Office | undefined> {
    const [result] = await db.select().from(offices).where(eq(offices.id, id));
    return result;
  }

  async createOffice(office: InsertOffice): Promise<Office> {
    const [result] = await db.insert(offices).values(office).returning();
    return result;
  }

  // Lender methods
  async getLenders(filters: FilterParams): Promise<{ 
    results: Lender[]; 
    total: number; 
    totalPages: number;
    resultTotals?: any;
    entityTotals?: any;
  }> {
    const { page = 1, pageSize = 10, sortBy, sortOrder = 'asc', name, county, city, zipCode, address } = filters;
    
    const offset = (page - 1) * pageSize;
    const limit = pageSize;
    
    let whereClause = sql`1 = 1`;
    
    if (name) {
      whereClause = sql`${whereClause} AND ${lenders.lenderName} ILIKE ${`%${name}%`}`;
    }
    
    if (county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        whereClause = sql`${whereClause} AND ${lenders.countyId} = ${countyRecord.id}`;
      }
    }
    
    if (city && county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        const cityRecord = await this.getCityByValue(city, countyRecord.id);
        if (cityRecord) {
          whereClause = sql`${whereClause} AND ${lenders.cityId} = ${cityRecord.id}`;
        }
      }
    }
    
    if (zipCode && city && county) {
      const countyRecord = await this.getCountyByValue(county);
      if (countyRecord) {
        const cityRecord = await this.getCityByValue(city, countyRecord.id);
        if (cityRecord) {
          const zipCodeRecord = await this.getZipCodeByValue(zipCode, cityRecord.id);
          if (zipCodeRecord) {
            whereClause = sql`${whereClause} AND ${lenders.zipCodeId} = ${zipCodeRecord.id}`;
          }
        }
      }
    }
    
    if (address) {
      whereClause = sql`${whereClause} AND ${lenders.address} ILIKE ${`%${address}%`}`;
    }
    
    // Calculate total count
    const [{ count }] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(lenders)
      .where(whereClause);
    
    const totalPages = Math.ceil(count / pageSize);
    
    // Build the query to fetch data
    let query = db
      .select()
      .from(lenders)
      .where(whereClause)
      .limit(limit)
      .offset(offset);
    
    // Add sorting if specified
    if (sortBy) {
      if (sortOrder === 'desc') {
        query = query.orderBy(desc(sql.raw(`"${sortBy}"`)));
      } else {
        query = query.orderBy(asc(sql.raw(`"${sortBy}"`)));
      }
    } else {
      // Default sorting by lender name
      query = query.orderBy(asc(lenders.lenderName));
    }
    
    const results = await query;
    
    // For entity totals, we need to get the entities that match the filter criteria
    // but then use their unfiltered data for the totals
    const matchingLenders = await db
      .select({ id: lenders.id })
      .from(lenders)
      .where(whereClause);
    
    const matchingIds = matchingLenders.map(lender => lender.id);
    
    // Get the complete, unfiltered data for the matching entities
    const entityTotals = await db
      .select()
      .from(lenders)
      .where(inArray(lenders.id, matchingIds));
    
    // Calculate result totals for filtered lenders
    const [resultTotals] = await db
      .select({
        totalTransactionsToInvestors: sql<number>`SUM(${lenders.totalTransactionsToInvestors})`,
        uniqueInvestorRelationships: sql<number>`SUM(${lenders.uniqueInvestorRelationships})`,
        avgLoanAmount: sql<string>`TO_CHAR(AVG(NULLIF(${lenders.avgLoanAmount}, 0)), 'FM$999,999,999')`,
        avgLoanToPurchasePriceRatio: sql<string>`TO_CHAR(AVG(NULLIF(${lenders.avgLoanToPurchasePriceRatio}, 0)) * 100, 'FM990.0%')`,
        avgLoansPerRelationship: sql<string>`TO_CHAR(AVG(NULLIF(${lenders.avgLoansPerRelationship}, 0)), 'FM90.0')`,
      })
      .from(lenders)
      .where(whereClause);
    
    return {
      results,
      total: Number(count),
      totalPages,
      resultTotals,
      entityTotals
    };
  }

  async getLenderById(id: number): Promise<Lender | undefined> {
    const [result] = await db.select().from(lenders).where(eq(lenders.id, id));
    return result;
  }

  async createLender(lender: InsertLender): Promise<Lender> {
    const [result] = await db.insert(lenders).values(lender).returning();
    return result;
  }

  // Saved Search methods - we will implement these later
  async getSavedSearches(userId: number): Promise<SavedSearch[]> {
    // This will be implemented with a saved_searches table later
    return [];
  }

  async getSavedSearchById(id: number): Promise<SavedSearch | undefined> {
    // This will be implemented with a saved_searches table later
    return undefined;
  }

  async createSavedSearch(search: SaveSearchParams, userId: number): Promise<SavedSearch> {
    // This will be implemented with a saved_searches table later
    return {
      id: 1,
      name: search.name,
      userId,
      tabType: search.tabType,
      filters: search.filters,
      createdAt: new Date()
    };
  }

  async deleteSavedSearch(id: number): Promise<void> {
    // This will be implemented with a saved_searches table later
  }

  // Contact methods
  async getContacts(filters: CommFilterParams): Promise<{ results: Contact[]; total: number; totalPages: number }> {
    const { page = 1, pageSize = 10, sortBy, sortOrder = 'asc', type, searchTerm } = filters;
    
    const offset = (page - 1) * pageSize;
    const limit = pageSize;
    
    let whereClause = sql`1 = 1`;
    
    if (type) {
      whereClause = sql`${whereClause} AND ${contacts.type} = ${type}`;
    }
    
    if (searchTerm) {
      whereClause = sql`${whereClause} AND (
        ${contacts.name} ILIKE ${`%${searchTerm}%`} OR 
        ${contacts.phone} ILIKE ${`%${searchTerm}%`} OR 
        ${contacts.email} ILIKE ${`%${searchTerm}%`}
      )`;
    }
    
    // Calculate total count
    const [{ count }] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(contacts)
      .where(whereClause);
    
    const totalPages = Math.ceil(count / pageSize);
    
    // Build the query to fetch data
    let query = db
      .select()
      .from(contacts)
      .where(whereClause)
      .limit(limit)
      .offset(offset);
    
    // Add sorting if specified
    if (sortBy) {
      if (sortOrder === 'desc') {
        query = query.orderBy(desc(sql.raw(`"${sortBy}"`)));
      } else {
        query = query.orderBy(asc(sql.raw(`"${sortBy}"`)));
      }
    } else {
      // Default sorting by name
      query = query.orderBy(asc(contacts.name));
    }
    
    const results = await query;
    
    return {
      results,
      total: Number(count),
      totalPages
    };
  }

  async getContactById(id: number): Promise<Contact | undefined> {
    const [result] = await db.select().from(contacts).where(eq(contacts.id, id));
    return result;
  }

  async getContactByEntityId(type: string, entityId: number): Promise<Contact | undefined> {
    const [result] = await db.select().from(contacts).where(
      and(
        eq(contacts.type, type as any),
        eq(contacts.entityId, entityId)
      )
    );
    return result;
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const [result] = await db.insert(contacts).values(contact).returning();
    return result;
  }

  async updateContact(id: number, contact: Partial<InsertContact>): Promise<Contact> {
    const [result] = await db
      .update(contacts)
      .set({ ...contact, updatedAt: new Date() })
      .where(eq(contacts.id, id))
      .returning();
    return result;
  }

  // Conversation methods
  async getConversationsByContactId(contactId: number): Promise<Conversation[]> {
    return await db
      .select()
      .from(conversations)
      .where(eq(conversations.contactId, contactId))
      .orderBy(desc(conversations.timestamp));
  }

  async getConversationById(id: number): Promise<Conversation | undefined> {
    const [result] = await db.select().from(conversations).where(eq(conversations.id, id));
    return result;
  }

  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const [result] = await db
      .insert(conversations)
      .values({ ...conversation, timestamp: new Date() })
      .returning();
    return result;
  }

  async updateConversationStatus(id: number, status: string): Promise<Conversation> {
    const [result] = await db
      .update(conversations)
      .set({ status: status as any })
      .where(eq(conversations.id, id))
      .returning();
    return result;
  }

  // AI Task methods
  async getTasksByContactId(contactId: number): Promise<AiTask[]> {
    return await db
      .select()
      .from(aiTasks)
      .where(eq(aiTasks.contactId, contactId))
      .orderBy(desc(aiTasks.createdAt));
  }

  async getTaskById(id: number): Promise<AiTask | undefined> {
    const [result] = await db.select().from(aiTasks).where(eq(aiTasks.id, id));
    return result;
  }

  async createTask(task: InsertAiTask): Promise<AiTask> {
    const [result] = await db.insert(aiTasks).values(task).returning();
    return result;
  }

  async updateTaskStatus(id: number, status: string, result?: string): Promise<AiTask> {
    const updates: any = { status: status as any };
    if (result) {
      updates.result = result;
    }
    
    if (status === 'COMPLETE') {
      updates.completedAt = new Date();
    }
    
    const [resultTask] = await db
      .update(aiTasks)
      .set(updates)
      .where(eq(aiTasks.id, id))
      .returning();
    return resultTask;
  }

  async updateTaskThread(id: number, threadId: string): Promise<AiTask> {
    const [result] = await db
      .update(aiTasks)
      .set({ threadId })
      .where(eq(aiTasks.id, id))
      .returning();
    return result;
  }

  async getPendingTasks(): Promise<AiTask[]> {
    return await db
      .select()
      .from(aiTasks)
      .where(eq(aiTasks.status, 'PENDING'))
      .orderBy(asc(aiTasks.dueAt));
  }

  // Template methods
  async getTemplates(channel?: string): Promise<Template[]> {
    if (channel) {
      return await db
        .select()
        .from(templates)
        .where(eq(templates.channel, channel as any))
        .orderBy(asc(templates.name));
    } else {
      return await db
        .select()
        .from(templates)
        .orderBy(asc(templates.name));
    }
  }

  async getTemplateByKey(key: string): Promise<Template | undefined> {
    const [result] = await db.select().from(templates).where(eq(templates.key, key));
    return result;
  }

  async createTemplate(template: InsertTemplate): Promise<Template> {
    const [result] = await db.insert(templates).values(template).returning();
    return result;
  }

  async updateTemplate(key: string, template: Partial<InsertTemplate>): Promise<Template> {
    const [result] = await db
      .update(templates)
      .set({ ...template, updatedAt: new Date() })
      .where(eq(templates.key, key))
      .returning();
    return result;
  }

  // Corporation methods
  async getCorporations(): Promise<Corporation[]> {
    return await db.select().from(corporations).orderBy(asc(corporations.name));
  }

  async getCorporationById(id: number): Promise<Corporation | undefined> {
    const [result] = await db.select().from(corporations).where(eq(corporations.id, id));
    return result;
  }

  async getCorporationByName(name: string): Promise<Corporation | undefined> {
    const [result] = await db.select().from(corporations).where(eq(corporations.name, name));
    return result;
  }

  async createCorporation(corporation: InsertCorporation): Promise<Corporation> {
    const [result] = await db.insert(corporations).values(corporation).returning();
    return result;
  }

  async updateCorporation(id: number, corporation: Partial<InsertCorporation>): Promise<Corporation> {
    const [result] = await db
      .update(corporations)
      .set(corporation)
      .where(eq(corporations.id, id))
      .returning();
    return result;
  }
  
  // Property methods - uses externalPool for direct SQL queries to access the external 35.6K property dataset
  async getProperties(filters: any = {}): Promise<{ results: Property[]; total: number; totalPages: number }> {
    try {
      console.log("Getting properties with filters:", JSON.stringify(filters));
      
      // Import externalPool directly to avoid module import issues
      const { externalPool } = await import('./db');
      
      // First, let's check the actual column names in the external database
      try {
        const columnsResult = await externalPool.query(`
          SELECT column_name 
          FROM information_schema.columns 
          WHERE table_name = 'properties' 
          ORDER BY ordinal_position;
        `);
        console.log("External database columns:", columnsResult.rows.map(row => row.column_name));
      } catch (columnError: any) {
        console.error("Error fetching columns:", columnError.message || columnError);
      }
      
      // Use raw SQL queries with the externalPool instead of Drizzle ORM
      // Build the WHERE conditions
      const conditions = [];
      const params: any[] = [];
      let paramCount = 1;
      
      // Add location filters
      if (filters.county) {
        conditions.push(`county = $${paramCount++}`);
        params.push(filters.county);
        
        // If we have a city filter
        if (filters.city) {
          conditions.push(`city = $${paramCount++}`);
          params.push(filters.city);
          
          // If we have a zipcode filter
          if (filters.zipCode) {
            conditions.push(`zipcode = $${paramCount++}`);
            params.push(filters.zipCode);
          }
        }
      }
      
      // Add address filter - search in street_name field which contains the address
      if (filters.address) {
        conditions.push(`(street_name ILIKE $${paramCount})`);
        params.push(`%${filters.address}%`);
        paramCount++;
      }
      
      // Add name search filter using the actual column names in the external database
      if (filters.name) {
        conditions.push(`(current_owner ILIKE $${paramCount} OR investor ILIKE $${paramCount} OR lender ILIKE $${paramCount})`);
        params.push(`%${filters.name}%`);
        paramCount++;
      }
      
      // Calculate pagination
      const page = Number(filters.page) || 1;
      const pageSize = Number(filters.pageSize) || 10;
      const offset = (page - 1) * pageSize;
      
      // Create the WHERE clause
      const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
      
      // Execute the count query
      const countQuery = `SELECT COUNT(*) FROM properties ${whereClause}`;
      console.log("Count query:", countQuery);
      console.log("Count params:", params);
      
      const countResult = await externalPool.query(countQuery, params);
      console.log("Count result:", countResult.rows[0]);
      
      const total = parseInt(countResult.rows[0].count, 10);
      const totalPages = Math.ceil(total / pageSize);
      
      // Execute the data query - sort by id instead of address
      let sortClause = 'ORDER BY id';
      if (filters.sortBy) {
        // Safely handle column names for ORDER BY
        const safeColumnName = filters.sortBy.replace(/[^a-zA-Z0-9_]/g, '');
        if (safeColumnName) {
          // Map frontend column names to actual backend column names in the external database
          const columnMap: Record<string, string> = {
            'address': 'street_name',
            'current_owner': 'current_owner',
            'investor': 'investor',
            'lender': 'lender'
          };
          
          const columnToUse = columnMap[safeColumnName] || safeColumnName;
          sortClause = `ORDER BY ${columnToUse} ${filters.sortOrder === 'desc' ? 'DESC' : 'ASC'}`;
        }
      }
      
      // Clone the params array for the data query
      const dataParams = [...params];
      
      const dataQuery = `
        SELECT * FROM properties 
        ${whereClause} 
        ${sortClause} 
        LIMIT $${paramCount++} OFFSET $${paramCount++}
      `;
      dataParams.push(pageSize, offset);
      
      console.log("Data query:", dataQuery);
      console.log("Data params:", dataParams);
      
      const dataResult = await externalPool.query(dataQuery, dataParams);
      console.log(`Data result: ${dataResult.rows.length} rows returned`);
      
      // Sample the first row to understand the schema
      if (dataResult.rows.length > 0) {
        console.log("Sample row keys:", Object.keys(dataResult.rows[0]));
      }
      
      const results = dataResult.rows;
      
      // Map results to match our frontend schema based on the columns we observed and Property type
      const mappedResults: Property[] = results.map(row => {
        // Construct address from street_number and street_name
        const address = row.street_number && row.street_name 
          ? `${row.street_number} ${row.street_name}` 
          : '';
          
        // Convert latitude/longitude to string to match our schema
        const latStr = row.latitude ? row.latitude.toString() : null;
        const lngStr = row.longitude ? row.longitude.toString() : null;
        
        return {
          id: row.id,
          address: address,
          unit_type: null,
          unit_number: row.unit_number || null,
          city: row.city || null,
          county: row.county || null,
          state: row.state || null,
          zipcode: row.zipcode || null,
          latitude: latStr,
          longitude: lngStr,
          current_owner: row.current_owner || null,
          investor: row.investor || null,
          lender: row.lender || null,
          // Defaulting mailing fields since they don't exist in the external DB
          mailing_address: address || null, // Use property address as mailing address
          mailing_unit_type: null,
          mailing_unit_number: row.unit_number || null,
          mailing_city: row.city || null,
          mailing_state: row.state || null,
          mailing_zip: row.zipcode || null,
          mailing_zip4: null
        };
      });
      
      return {
        results: mappedResults,
        total,
        totalPages
      };
    } catch (error) {
      console.error("Error in getProperties:", error);
      throw error;
    }
  }

  async getPropertyById(id: number): Promise<Property | undefined> {
    try {
      // Import externalPool directly to avoid module import issues
      const { externalPool } = await import('./db');
      
      // Use raw SQL for the external database
      const query = 'SELECT * FROM properties WHERE id = $1';
      const result = await externalPool.query(query, [id]);
      
      if (result.rows.length === 0) {
        return undefined;
      }
      
      const row = result.rows[0];
      
      // Construct address from street_number and street_name
      const address = row.street_number && row.street_name 
        ? `${row.street_number} ${row.street_name}` 
        : '';
        
      // Convert latitude/longitude to string to match our schema
      const latStr = row.latitude ? row.latitude.toString() : null;
      const lngStr = row.longitude ? row.longitude.toString() : null;
      
      // Map the result to match our Property type
      const mappedProperty: Property = {
        id: row.id,
        address: address,
        unit_type: null,
        unit_number: row.unit_number || null,
        city: row.city || null,
        county: row.county || null,
        state: row.state || null,
        zipcode: row.zipcode || null,
        latitude: latStr,
        longitude: lngStr,
        current_owner: row.current_owner || null,
        investor: row.investor || null,
        lender: row.lender || null,
        // Defaulting mailing fields since they don't exist in the external DB
        mailing_address: address || null, // Use property address as mailing address
        mailing_unit_type: null,
        mailing_unit_number: row.unit_number || null,
        mailing_city: row.city || null,
        mailing_state: row.state || null,
        mailing_zip: row.zipcode || null,
        mailing_zip4: null
      };
      
      return mappedProperty;
    } catch (error) {
      console.error("Error in getPropertyById:", error);
      throw error;
    }
  }

  // Still use the main database for property creation (we don't want to modify the external DB)
  async createProperty(property: InsertProperty): Promise<Property> {
    const [result] = await db.insert(properties).values(property).returning();
    return result;
  }

  // Still use the main database for property updates (we don't want to modify the external DB)
  async updateProperty(id: number, property: Partial<InsertProperty>): Promise<Property> {
    const [result] = await db
      .update(properties)
      .set(property)
      .where(eq(properties.id, id))
      .returning();
    return result;
  }
}

export const storage = new DatabaseStorage();