import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { filterParamsSchema, commFilterParamsSchema, 
         insertContactSchema, insertConversationSchema,
         insertAiTaskSchema, insertTemplateSchema, 
         insertCorporationSchema, insertPropertiesSchema,
         properties } from "@shared/schema";
import { z } from "zod";
import { SaveSearchParams, TabType } from "@/types";

// Import sample data
import {
  sampleInvestors,
  sampleAgents,
  sampleOffices,
  sampleLenders,
  sampleContacts,
  sampleConversations,
  sampleTasks
} from "../client/src/data/sampleData";

// Helper function to calculate investor totals
function calculateInvestorTotals(investors: any[]) {
  if (!investors || investors.length === 0) return {};
  
  // Calculate aggregate values
  const totals = {
    count: investors.length,
    avgPurchasePrice: 0,
    avgResalePrice: 0,
    totalTransactions: 0,
    purchaseToFutureValueRatio: 0,
    listToSoldPriceRatio: 0
  };
  
  // Sum values across all investors
  investors.forEach(investor => {
    totals.avgPurchasePrice += Number(investor.avgPurchasePrice) || 0;
    totals.avgResalePrice += Number(investor.avgResalePrice) || 0;
    totals.totalTransactions += Number(investor.totalTransactions) || 0;
    
    // For ratio fields, we need to convert from percentage strings to numbers
    const purchaseToFutureValue = investor.purchaseToFutureValueRatio ? 
      parseFloat(investor.purchaseToFutureValueRatio.replace('%', '')) : 0;
    totals.purchaseToFutureValueRatio += purchaseToFutureValue;
    
    const listToSoldPrice = investor.listToSoldPriceRatio ? 
      parseFloat(investor.listToSoldPriceRatio.replace('%', '')) : 0;
    totals.listToSoldPriceRatio += listToSoldPrice;
  });
  
  // Calculate averages
  if (totals.count > 0) {
    totals.avgPurchasePrice = totals.avgPurchasePrice / totals.count;
    totals.avgResalePrice = totals.avgResalePrice / totals.count;
    totals.purchaseToFutureValueRatio = (totals.purchaseToFutureValueRatio / totals.count).toFixed(1) + '%';
    totals.listToSoldPriceRatio = (totals.listToSoldPriceRatio / totals.count).toFixed(1) + '%';
  }
  
  return totals;
}

// Helper function to calculate agent totals
function calculateAgentTotals(agents: any[]) {
  if (!agents || agents.length === 0) return {};
  
  // Calculate aggregate values
  const totals = {
    count: agents.length,
    avgTransactionPrice: 0,
    totalTransactionsWithInvestors: 0,
    listingsSoldToInvestors: 0,
    listingsResoldForInvestors: 0,
    percentageDoubleEndTransactions: 0,
    uniqueInvestorRelationships: 0
  };
  
  // Sum values across all agents
  agents.forEach(agent => {
    totals.avgTransactionPrice += Number(agent.avgTransactionPrice) || 0;
    totals.totalTransactionsWithInvestors += Number(agent.totalTransactionsWithInvestors) || 0;
    totals.listingsSoldToInvestors += Number(agent.listingsSoldToInvestors) || 0;
    totals.listingsResoldForInvestors += Number(agent.listingsResoldForInvestors) || 0;
    totals.percentageDoubleEndTransactions += Number(agent.percentageDoubleEndTransactions) || 0;
    totals.uniqueInvestorRelationships += Number(agent.uniqueInvestorRelationships) || 0;
  });
  
  // Calculate averages
  if (totals.count > 0) {
    totals.avgTransactionPrice = totals.avgTransactionPrice / totals.count;
    totals.percentageDoubleEndTransactions = Math.round(totals.percentageDoubleEndTransactions / totals.count);
  }
  
  return totals;
}

// Helper function to calculate office totals
function calculateOfficeTotals(offices: any[]) {
  if (!offices || offices.length === 0) return {};
  
  // Calculate aggregate values
  const totals = {
    count: offices.length,
    avgTransactionPrice: 0,
    totalTransactionsWithInvestors: 0,
    listingsSoldToInvestors: 0,
    listingsResoldForInvestors: 0,
    buyerRepresentationTransactions: 0,
    uniqueAgentCount: 0
  };
  
  // Sum values across all offices
  offices.forEach(office => {
    totals.avgTransactionPrice += Number(office.avgTransactionPrice) || 0;
    totals.totalTransactionsWithInvestors += Number(office.totalTransactionsWithInvestors) || 0;
    totals.listingsSoldToInvestors += Number(office.listingsSoldToInvestors) || 0;
    totals.listingsResoldForInvestors += Number(office.listingsResoldForInvestors) || 0;
    totals.buyerRepresentationTransactions += Number(office.buyerRepresentationTransactions) || 0;
    totals.uniqueAgentCount += Number(office.uniqueAgentCount) || 0;
  });
  
  // Calculate averages
  if (totals.count > 0) {
    totals.avgTransactionPrice = totals.avgTransactionPrice / totals.count;
  }
  
  return totals;
}

// Helper function to calculate lender totals
function calculateLenderTotals(lenders: any[]) {
  if (!lenders || lenders.length === 0) return {};
  
  // Calculate aggregate values
  const totals = {
    count: lenders.length,
    avgLoanAmount: 0,
    totalTransactionsToInvestors: 0,
    avgLoanToPurchasePriceRatio: 0,
    avgLoansPerRelationship: 0,
    uniqueInvestorRelationships: 0
  };
  
  // Sum values across all lenders
  lenders.forEach(lender => {
    totals.avgLoanAmount += Number(lender.avgLoanAmount) || 0;
    totals.totalTransactionsToInvestors += Number(lender.totalTransactionsToInvestors) || 0;
    
    // For ratio fields, this is a decimal value (0.72, 0.68, etc.)
    totals.avgLoanToPurchasePriceRatio += Number(lender.avgLoanToPurchasePriceRatio) || 0;
    
    totals.avgLoansPerRelationship += Number(lender.avgLoansPerRelationship) || 0;
    totals.uniqueInvestorRelationships += Number(lender.uniqueInvestorRelationships) || 0;
  });
  
  // Calculate averages
  if (totals.count > 0) {
    totals.avgLoanAmount = totals.avgLoanAmount / totals.count;
    // Convert decimal to percentage format for display
    totals.avgLoanToPurchasePriceRatio = Math.round(100 * totals.avgLoanToPurchasePriceRatio / totals.count) + '%';
    totals.avgLoansPerRelationship = totals.avgLoansPerRelationship / totals.count;
  }
  
  return totals;
}

// Zod schema for validating saved search requests
const saveSearchSchema = z.object({
  name: z.string().min(1, "Search name is required"),
  tabType: z.enum(["investors", "agents", "offices", "lenders"] as const),
  filters: filterParamsSchema
});

// Mock user ID for demonstration (in a real app, this would come from auth)
const DEMO_USER_ID = 1;

export async function registerRoutes(app: Express): Promise<Server> {
  // API prefix for all routes
  const API_PREFIX = "/api";

  // Handle errors for all API routes
  const handleError = (res: Response, error: any) => {
    console.error("API Error:", error);
    
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        message: "Invalid request parameters", 
        errors: error.errors 
      });
    }
    
    return res.status(500).json({ 
      message: "Internal server error" 
    });
  };

  // Location API Routes
  // Get Counties
  app.get(`${API_PREFIX}/locations/counties`, async (_req: Request, res: Response) => {
    try {
      const counties = await storage.getCounties();
      const formattedCounties = counties.map(county => ({
        label: county.name,
        value: county.value
      }));
      res.json(formattedCounties);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Get Cities by County
  app.get(`${API_PREFIX}/locations/cities`, async (req: Request, res: Response) => {
    try {
      const countyValue = req.query.county as string;
      
      if (!countyValue) {
        return res.status(400).json({ message: "County is required" });
      }
      
      const county = await storage.getCountyByValue(countyValue);
      
      if (!county) {
        return res.status(404).json({ message: "County not found" });
      }
      
      const cities = await storage.getCitiesByCounty(county.id);
      const formattedCities = cities.map(city => ({
        label: city.name,
        value: city.value
      }));
      
      res.json(formattedCities);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Get Zip Codes by City
  app.get(`${API_PREFIX}/locations/zipcodes`, async (req: Request, res: Response) => {
    try {
      const countyValue = req.query.county as string;
      const cityValue = req.query.city as string;
      
      if (!countyValue || !cityValue) {
        return res.status(400).json({ message: "County and city are required" });
      }
      
      const county = await storage.getCountyByValue(countyValue);
      
      if (!county) {
        return res.status(404).json({ message: "County not found" });
      }
      
      const city = await storage.getCityByValue(cityValue, county.id);
      
      if (!city) {
        return res.status(404).json({ message: "City not found" });
      }
      
      const zipCodes = await storage.getZipCodesByCity(city.id);
      const formattedZipCodes = zipCodes.map(zip => ({
        label: zip.code,
        value: zip.value
      }));
      
      res.json(formattedZipCodes);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Parse filter parameters from request query
  const parseFilterParams = (req: Request) => {
    const { 
      county, city, zipCode, address, radius, 
      name, minUnits, maxUnits, doubleEnd,
      page, pageSize, sortBy, sortOrder, sortByEntityTotals
    } = req.query;
    
    return filterParamsSchema.parse({
      county: county as string,
      city: city as string,
      zipCode: zipCode as string,
      address: address as string,
      radius: radius ? parseInt(radius as string) : 10,
      name: name as string,
      minUnits: minUnits as string,
      maxUnits: maxUnits as string,
      doubleEnd: doubleEnd === 'true',
      page: page ? parseInt(page as string) : 1,
      pageSize: pageSize ? parseInt(pageSize as string) : 10,
      sortBy: sortBy as string,
      sortOrder: sortOrder as 'asc' | 'desc',
      sortByEntityTotals: sortByEntityTotals === 'true'
    });
  };

  // Investors API Routes
  app.get(`${API_PREFIX}/investors`, async (req: Request, res: Response) => {
    try {
      const filters = parseFilterParams(req);
      
      // Return sample data for demo purposes
      if (process.env.USE_SAMPLE_DATA === 'true') {
        // Apply pagination to sample data
        const startIndex = (filters.page - 1) * filters.pageSize;
        const endIndex = startIndex + filters.pageSize;
        const results = sampleInvestors.slice(startIndex, endIndex);
        const total = sampleInvestors.length;
        const totalPages = Math.ceil(total / filters.pageSize);
        
        // Calculate entity totals (using all data)
        const entityTotals = calculateInvestorTotals(sampleInvestors);
        
        // Calculate result totals (using filtered data)
        const resultTotals = calculateInvestorTotals(results);

        res.json({
          results,
          total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages,
          entityTotals,
          resultTotals
        });
      } else {
        // Use real data from storage
        const result = await storage.getInvestors(filters);
        
        // If using real data, we'd get the totals from the database
        // This is a placeholder for the actual implementation
        const entityTotals = result.entityTotals || {};
        const resultTotals = result.resultTotals || {};
        
        res.json({
          results: result.results,
          total: result.total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages: result.totalPages,
          entityTotals,
          resultTotals
        });
      }
    } catch (error) {
      handleError(res, error);
    }
  });

  // Get Investor by ID
  app.get(`${API_PREFIX}/investors/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid investor ID" });
      }
      
      const investor = await storage.getInvestorById(id);
      
      if (!investor) {
        return res.status(404).json({ message: "Investor not found" });
      }
      
      res.json(investor);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Agents API Routes
  app.get(`${API_PREFIX}/agents`, async (req: Request, res: Response) => {
    try {
      const filters = parseFilterParams(req);
      
      // Return sample data for demo purposes
      if (process.env.USE_SAMPLE_DATA === 'true') {
        // Apply pagination to sample data
        const startIndex = (filters.page - 1) * filters.pageSize;
        const endIndex = startIndex + filters.pageSize;
        const results = sampleAgents.slice(startIndex, endIndex);
        const total = sampleAgents.length;
        const totalPages = Math.ceil(total / filters.pageSize);
        
        // Calculate entity totals (using all data)
        const entityTotals = calculateAgentTotals(sampleAgents);
        
        // Calculate result totals (using filtered data)
        const resultTotals = calculateAgentTotals(results);
        
        res.json({
          results,
          total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages,
          entityTotals,
          resultTotals
        });
      } else {
        // Use real data from storage
        const result = await storage.getAgents(filters);
        
        // If using real data, we'd get the totals from the database
        // This is a placeholder for the actual implementation
        const entityTotals = result.entityTotals || {};
        const resultTotals = result.resultTotals || {};
        
        res.json({
          results: result.results,
          total: result.total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages: result.totalPages,
          entityTotals,
          resultTotals
        });
      }
    } catch (error) {
      handleError(res, error);
    }
  });

  // Get Agent by ID
  app.get(`${API_PREFIX}/agents/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid agent ID" });
      }
      
      const agent = await storage.getAgentById(id);
      
      if (!agent) {
        return res.status(404).json({ message: "Agent not found" });
      }
      
      res.json(agent);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Offices API Routes
  app.get(`${API_PREFIX}/offices`, async (req: Request, res: Response) => {
    try {
      const filters = parseFilterParams(req);
      
      // Return sample data for demo purposes
      if (process.env.USE_SAMPLE_DATA === 'true') {
        // Apply pagination to sample data
        const startIndex = (filters.page - 1) * filters.pageSize;
        const endIndex = startIndex + filters.pageSize;
        const results = sampleOffices.slice(startIndex, endIndex);
        const total = sampleOffices.length;
        const totalPages = Math.ceil(total / filters.pageSize);
        
        // Calculate entity totals (using all data)
        const entityTotals = calculateOfficeTotals(sampleOffices);
        
        // Calculate result totals (using filtered data)
        const resultTotals = calculateOfficeTotals(results);
        
        res.json({
          results,
          total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages,
          entityTotals,
          resultTotals
        });
      } else {
        // Use real data from storage
        const result = await storage.getOffices(filters);
        
        // If using real data, we'd get the totals from the database
        // This is a placeholder for the actual implementation
        const entityTotals = result.entityTotals || {};
        const resultTotals = result.resultTotals || {};
        
        res.json({
          results: result.results,
          total: result.total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages: result.totalPages,
          entityTotals,
          resultTotals
        });
      }
    } catch (error) {
      handleError(res, error);
    }
  });

  // Get Office by ID
  app.get(`${API_PREFIX}/offices/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid office ID" });
      }
      
      const office = await storage.getOfficeById(id);
      
      if (!office) {
        return res.status(404).json({ message: "Office not found" });
      }
      
      res.json(office);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Lenders API Routes
  app.get(`${API_PREFIX}/lenders`, async (req: Request, res: Response) => {
    try {
      const filters = parseFilterParams(req);
      
      // Return sample data for demo purposes
      if (process.env.USE_SAMPLE_DATA === 'true') {
        // Apply pagination to sample data
        const startIndex = (filters.page - 1) * filters.pageSize;
        const endIndex = startIndex + filters.pageSize;
        const results = sampleLenders.slice(startIndex, endIndex);
        const total = sampleLenders.length;
        const totalPages = Math.ceil(total / filters.pageSize);
        
        // Calculate entity totals (using all data)
        const entityTotals = calculateLenderTotals(sampleLenders);
        
        // Calculate result totals (using filtered data)
        const resultTotals = calculateLenderTotals(results);
        
        res.json({
          results,
          total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages,
          entityTotals,
          resultTotals
        });
      } else {
        // Use real data from storage
        const result = await storage.getLenders(filters);
        
        // If using real data, we'd get the totals from the database
        // This is a placeholder for the actual implementation
        const entityTotals = result.entityTotals || {};
        const resultTotals = result.resultTotals || {};
        
        res.json({
          results: result.results,
          total: result.total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages: result.totalPages,
          entityTotals,
          resultTotals
        });
      }
    } catch (error) {
      handleError(res, error);
    }
  });

  // Get Lender by ID
  app.get(`${API_PREFIX}/lenders/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid lender ID" });
      }
      
      const lender = await storage.getLenderById(id);
      
      if (!lender) {
        return res.status(404).json({ message: "Lender not found" });
      }
      
      res.json(lender);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Saved Searches API Routes
  // Get all saved searches for a user
  app.get(`${API_PREFIX}/saved-searches`, async (_req: Request, res: Response) => {
    try {
      const savedSearches = await storage.getSavedSearches(DEMO_USER_ID);
      res.json(savedSearches);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Get saved search by ID
  app.get(`${API_PREFIX}/saved-searches/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid saved search ID" });
      }
      
      const savedSearch = await storage.getSavedSearchById(id);
      
      if (!savedSearch) {
        return res.status(404).json({ message: "Saved search not found" });
      }
      
      res.json(savedSearch);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Create a new saved search
  app.post(`${API_PREFIX}/saved-searches`, async (req: Request, res: Response) => {
    try {
      const saveSearchData = saveSearchSchema.parse(req.body);
      const savedSearch = await storage.createSavedSearch(saveSearchData, DEMO_USER_ID);
      res.status(201).json(savedSearch);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Delete a saved search
  app.delete(`${API_PREFIX}/saved-searches/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid saved search ID" });
      }
      
      const savedSearch = await storage.getSavedSearchById(id);
      
      if (!savedSearch) {
        return res.status(404).json({ message: "Saved search not found" });
      }
      
      await storage.deleteSavedSearch(id);
      res.status(204).send();
    } catch (error) {
      handleError(res, error);
    }
  });

  // Communication Module API Routes
  
  // Parse communication filter parameters from request query
  const parseCommFilterParams = (req: Request) => {
    const { 
      type, searchTerm, county, city, 
      hasPhone, hasEmail, hasActivity,
      page, pageSize, sortBy, sortOrder
    } = req.query;
    
    return commFilterParamsSchema.parse({
      type: type as string,
      searchTerm: searchTerm as string,
      county: county as string,
      city: city as string,
      hasPhone: hasPhone === 'true',
      hasEmail: hasEmail === 'true',
      hasActivity: hasActivity === 'true',
      page: page ? parseInt(page as string) : 1,
      pageSize: pageSize ? parseInt(pageSize as string) : 10,
      sortBy: sortBy as string,
      sortOrder: sortOrder as 'asc' | 'desc'
    });
  };
  
  // Contacts API Routes
  app.get(`${API_PREFIX}/contacts`, async (req: Request, res: Response) => {
    try {
      const filters = parseCommFilterParams(req);
      
      // Return sample data for demo purposes
      if (process.env.USE_SAMPLE_DATA === 'true') {
        // Filter contacts based on type if specified
        let filteredContacts = [...sampleContacts];
        
        if (filters.type) {
          filteredContacts = filteredContacts.filter(contact => 
            contact.type === filters.type
          );
        }
        
        // Apply search term filter if specified
        if (filters.searchTerm) {
          const term = filters.searchTerm.toLowerCase();
          filteredContacts = filteredContacts.filter(contact => 
            contact.name.toLowerCase().includes(term) || 
            (contact.email && contact.email.toLowerCase().includes(term)) ||
            (contact.phone && contact.phone.includes(term))
          );
        }
        
        // Apply pagination
        const startIndex = (filters.page - 1) * filters.pageSize;
        const endIndex = startIndex + filters.pageSize;
        const results = filteredContacts.slice(startIndex, endIndex);
        const total = filteredContacts.length;
        const totalPages = Math.ceil(total / filters.pageSize);
        
        res.json({
          results,
          total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages
        });
      } else {
        // Use real data from storage
        const result = await storage.getContacts(filters);
        
        res.json({
          results: result.results,
          total: result.total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages: result.totalPages
        });
      }
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get Contact by ID
  app.get(`${API_PREFIX}/contacts/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid contact ID" });
      }
      
      const contact = await storage.getContactById(id);
      
      if (!contact) {
        return res.status(404).json({ message: "Contact not found" });
      }
      
      res.json(contact);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Create a new contact
  app.post(`${API_PREFIX}/contacts`, async (req: Request, res: Response) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      res.status(201).json(contact);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Update a contact
  app.patch(`${API_PREFIX}/contacts/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid contact ID" });
      }
      
      const contact = await storage.getContactById(id);
      
      if (!contact) {
        return res.status(404).json({ message: "Contact not found" });
      }
      
      const contactData = insertContactSchema.partial().parse(req.body);
      const updatedContact = await storage.updateContact(id, contactData);
      res.json(updatedContact);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Conversations API Routes
  app.get(`${API_PREFIX}/contacts/:contactId/conversations`, async (req: Request, res: Response) => {
    try {
      const contactId = parseInt(req.params.contactId);
      
      if (isNaN(contactId)) {
        return res.status(400).json({ message: "Invalid contact ID" });
      }
      
      // Return sample data for demo purposes
      if (process.env.USE_SAMPLE_DATA === 'true') {
        // Filter conversations for this contact
        const filteredConversations = sampleConversations.filter(
          conversation => conversation.contactId === contactId
        );
        
        res.json(filteredConversations);
      } else {
        const contact = await storage.getContactById(contactId);
        
        if (!contact) {
          return res.status(404).json({ message: "Contact not found" });
        }
        
        const conversations = await storage.getConversationsByContactId(contactId);
        res.json(conversations);
      }
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get Conversation by ID
  app.get(`${API_PREFIX}/conversations/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      const conversation = await storage.getConversationById(id);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      res.json(conversation);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Create a new conversation
  app.post(`${API_PREFIX}/conversations`, async (req: Request, res: Response) => {
    try {
      const conversationData = insertConversationSchema.parse(req.body);
      const conversation = await storage.createConversation(conversationData);
      res.status(201).json(conversation);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Update a conversation status
  app.patch(`${API_PREFIX}/conversations/:id/status`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      const { status } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      const conversation = await storage.getConversationById(id);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      const updatedConversation = await storage.updateConversationStatus(id, status);
      res.json(updatedConversation);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // AI Tasks API Routes
  app.get(`${API_PREFIX}/contacts/:contactId/tasks`, async (req: Request, res: Response) => {
    try {
      const contactId = parseInt(req.params.contactId);
      
      if (isNaN(contactId)) {
        return res.status(400).json({ message: "Invalid contact ID" });
      }
      
      // Return sample data for demo purposes
      if (process.env.USE_SAMPLE_DATA === 'true') {
        // Filter tasks for this contact
        const filteredTasks = sampleTasks.filter(
          task => task.contactId === contactId
        );
        
        res.json(filteredTasks);
      } else {
        const contact = await storage.getContactById(contactId);
        
        if (!contact) {
          return res.status(404).json({ message: "Contact not found" });
        }
        
        const tasks = await storage.getTasksByContactId(contactId);
        res.json(tasks);
      }
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get Task by ID
  app.get(`${API_PREFIX}/tasks/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const task = await storage.getTaskById(id);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Create a new task
  app.post(`${API_PREFIX}/tasks`, async (req: Request, res: Response) => {
    try {
      const taskData = insertAiTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Update a task status
  app.patch(`${API_PREFIX}/tasks/:id/status`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const { status, result } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      const task = await storage.getTaskById(id);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      const updatedTask = await storage.updateTaskStatus(id, status, result);
      res.json(updatedTask);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Update a task thread
  app.patch(`${API_PREFIX}/tasks/:id/thread`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const { threadId } = req.body;
      
      if (!threadId) {
        return res.status(400).json({ message: "Thread ID is required" });
      }
      
      const task = await storage.getTaskById(id);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      const updatedTask = await storage.updateTaskThread(id, threadId);
      res.json(updatedTask);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get pending tasks
  app.get(`${API_PREFIX}/tasks/pending`, async (_req: Request, res: Response) => {
    try {
      const tasks = await storage.getPendingTasks();
      res.json(tasks);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Templates API Routes
  app.get(`${API_PREFIX}/templates`, async (req: Request, res: Response) => {
    try {
      const channel = req.query.channel as string;
      const templates = await storage.getTemplates(channel);
      res.json(templates);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get Template by Key
  app.get(`${API_PREFIX}/templates/:key`, async (req: Request, res: Response) => {
    try {
      const key = req.params.key;
      
      const template = await storage.getTemplateByKey(key);
      
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.json(template);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Create a new template
  app.post(`${API_PREFIX}/templates`, async (req: Request, res: Response) => {
    try {
      const templateData = insertTemplateSchema.parse(req.body);
      const template = await storage.createTemplate(templateData);
      res.status(201).json(template);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Update a template
  app.patch(`${API_PREFIX}/templates/:key`, async (req: Request, res: Response) => {
    try {
      const key = req.params.key;
      
      const template = await storage.getTemplateByKey(key);
      
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      const templateData = insertTemplateSchema.partial().parse(req.body);
      const updatedTemplate = await storage.updateTemplate(key, templateData);
      res.json(updatedTemplate);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Corporations API Routes
  
  // Get Corporation by Name (specific route must come before generic routes)
  app.get(`${API_PREFIX}/corporations/by-name/:name`, async (req: Request, res: Response) => {
    try {
      const name = req.params.name;
      
      const corporation = await storage.getCorporationByName(name);
      
      if (!corporation) {
        return res.status(404).json({ message: "Corporation not found" });
      }
      
      res.json(corporation);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get Corporation by ID
  app.get(`${API_PREFIX}/corporations/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid corporation ID" });
      }
      
      const corporation = await storage.getCorporationById(id);
      
      if (!corporation) {
        return res.status(404).json({ message: "Corporation not found" });
      }
      
      res.json(corporation);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Create a new corporation
  app.post(`${API_PREFIX}/corporations`, async (req: Request, res: Response) => {
    try {
      const corporationData = insertCorporationSchema.parse(req.body);
      const corporation = await storage.createCorporation(corporationData);
      res.status(201).json(corporation);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Update a corporation
  app.patch(`${API_PREFIX}/corporations/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid corporation ID" });
      }
      
      const corporation = await storage.getCorporationById(id);
      
      if (!corporation) {
        return res.status(404).json({ message: "Corporation not found" });
      }
      
      const corporationData = insertCorporationSchema.partial().parse(req.body);
      const updatedCorporation = await storage.updateCorporation(id, corporationData);
      res.json(updatedCorporation);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get all corporations
  app.get(`${API_PREFIX}/corporations`, async (_req: Request, res: Response) => {
    try {
      const corporations = await storage.getCorporations();
      res.json(corporations);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Property API Routes
  
  // Get Properties with filtering
  app.get(`${API_PREFIX}/properties`, async (req: Request, res: Response) => {
    try {
      // Parse query parameters
      const filters = {
        county: req.query.county as string,
        city: req.query.city as string,
        zipCode: req.query.zipCode as string, // Make sure this matches our storage method parameter naming
        name: req.query.name as string,
        address: req.query.address as string,
        page: parseInt(req.query.page as string) || 1,
        pageSize: parseInt(req.query.pageSize as string) || 10,
        sortBy: req.query.sortBy as string,
        sortOrder: req.query.sortOrder as 'asc' | 'desc' || 'asc'
      };
      
      const result = await storage.getProperties(filters);
      res.json(result);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get Property by ID
  app.get(`${API_PREFIX}/properties/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const property = await storage.getPropertyById(id);
      
      if (!property) {
        return res.status(404).json({ message: "Property not found" });
      }
      
      res.json(property);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Create Property
  app.post(`${API_PREFIX}/properties`, async (req: Request, res: Response) => {
    try {
      const propertyData = insertPropertiesSchema.parse(req.body);
      const property = await storage.createProperty(propertyData);
      res.status(201).json(property);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Update Property
  app.patch(`${API_PREFIX}/properties/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const propertyData = req.body;
      
      // Check if property exists
      const existingProperty = await storage.getPropertyById(id);
      if (!existingProperty) {
        return res.status(404).json({ message: "Property not found" });
      }
      
      const updatedProperty = await storage.updateProperty(id, propertyData);
      res.json(updatedProperty);
    } catch (error) {
      handleError(res, error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
