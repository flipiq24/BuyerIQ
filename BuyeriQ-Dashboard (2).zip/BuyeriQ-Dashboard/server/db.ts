import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Main application database
export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool, { schema });

// External database with 35.6K property records - for properties data
// If EXTERNAL_DATABASE_URL is set, use it; otherwise use the main database
console.log("Attempting to connect to external database...");
if (process.env.EXTERNAL_DATABASE_URL) {
  console.log("EXTERNAL_DATABASE_URL is defined");
  // Print a masked version of the URL for debugging
  const maskedUrl = process.env.EXTERNAL_DATABASE_URL.replace(/:[^:@]*@/, ':***@');
  console.log("External database URL (masked):", maskedUrl);
} else {
  console.log("EXTERNAL_DATABASE_URL is not defined");
}

// Also log the main database URL (masked)
const maskedMainUrl = process.env.DATABASE_URL.replace(/:[^:@]*@/, ':***@');
console.log("Main database URL (masked):", maskedMainUrl);

// Create the pool based on the external URL or fall back to the main pool
export const externalPool = process.env.EXTERNAL_DATABASE_URL 
  ? new Pool({ connectionString: process.env.EXTERNAL_DATABASE_URL }) 
  : pool;

// Test the external connection
externalPool.query('SELECT 1 as test').then(result => {
  console.log("External database connection test successful:", result.rows);
  
  // Check properties table count
  externalPool.query('SELECT COUNT(*) FROM properties').then(countResult => {
    console.log("Properties count in externalPool:", countResult.rows[0].count);
  }).catch(err => {
    console.error("Error counting properties in externalPool:", err.message);
  });
  
  // Direct test with environment variables
  if (process.env.EXTERNAL_DATABASE_URL) {
    const testPool = new Pool({ connectionString: process.env.EXTERNAL_DATABASE_URL });
    testPool.query('SELECT COUNT(*) FROM properties').then(directResult => {
      console.log("Properties count direct from EXTERNAL_DATABASE_URL:", directResult.rows[0].count);
    }).catch(err => {
      console.error("Error counting properties direct from EXTERNAL_DATABASE_URL:", err.message);
    });
  }
}).catch(error => {
  console.error("External database connection test failed:", error.message);
});

// We'll use raw queries with the pool for the external database to avoid schema mismatch issues
// This is a read-only connection so raw queries are acceptable
export const externalDb = drizzle(externalPool, { schema });

if (process.env.EXTERNAL_DATABASE_URL) {
  console.log("Using external database for property data");
} else {
  console.log("EXTERNAL_DATABASE_URL not provided, using main database for property data");
}