import fetch from 'node-fetch';

// Direct API tests to check if the location endpoints are working correctly
async function testLocationsAPI() {
  console.log('Testing Counties API...');
  const countiesResponse = await fetch('http://localhost:3000/api/locations/counties');
  if (!countiesResponse.ok) {
    console.error('Counties API failed:', countiesResponse.statusText);
    return;
  }
  const counties = await countiesResponse.json();
  console.log('Counties:', counties);
  
  // Test with a valid county
  if (counties.length > 0) {
    const testCounty = counties[0].value;
    console.log(`\nTesting Cities API with county=${testCounty}...`);
    const citiesResponse = await fetch(`http://localhost:3000/api/locations/cities?county=${testCounty}`);
    if (!citiesResponse.ok) {
      console.error('Cities API failed:', citiesResponse.statusText);
    } else {
      const cities = await citiesResponse.json();
      console.log('Cities:', cities);
      
      // Test with a valid city
      if (cities.length > 0) {
        const testCity = cities[0].value;
        console.log(`\nTesting Zip Codes API with county=${testCounty}&city=${testCity}...`);
        const zipCodesResponse = await fetch(`http://localhost:3000/api/locations/zipcodes?county=${testCounty}&city=${testCity}`);
        if (!zipCodesResponse.ok) {
          console.error('Zip Codes API failed:', zipCodesResponse.statusText);
        } else {
          const zipCodes = await zipCodesResponse.json();
          console.log('Zip Codes:', zipCodes);
        }
      }
    }
  }
}

// Run the test
testLocationsAPI().catch(console.error);