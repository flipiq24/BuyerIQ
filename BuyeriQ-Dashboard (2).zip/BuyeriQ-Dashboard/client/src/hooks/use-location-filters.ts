import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { LocationOption } from "@/types";

interface UseLocationFiltersProps {
  selectedCounty: string;
  selectedCity: string;
}

export function useLocationFilters({ selectedCounty, selectedCity }: UseLocationFiltersProps) {
  // Fetch counties
  const { data: countiesData, isLoading: isLoadingCounties } = useQuery({
    queryKey: ["/api/locations/counties"],
  });

  // Fetch cities based on selected county
  const { data: citiesData, isLoading: isLoadingCities } = useQuery({
    queryKey: selectedCounty ? ["/api/locations/cities", "county", selectedCounty] : ["/api/locations/cities"],
    enabled: !!selectedCounty,
  });

  // Fetch zip codes based on selected city
  const { data: zipCodesData, isLoading: isLoadingZipCodes } = useQuery({
    queryKey: selectedCity && selectedCounty ? 
      ["/api/locations/zipcodes", "county", selectedCounty, "city", selectedCity] : 
      ["/api/locations/zipcodes"],
    enabled: !!selectedCity && !!selectedCounty,
  });

  const [counties, setCounties] = useState<LocationOption[]>([]);
  const [cities, setCities] = useState<LocationOption[]>([]);
  const [zipCodes, setZipCodes] = useState<LocationOption[]>([]);

  // Update counties when data changes
  useEffect(() => {
    console.log("Counties data:", countiesData);
    if (countiesData && Array.isArray(countiesData)) {
      setCounties(countiesData);
    } else {
      setCounties([]);
    }
  }, [countiesData]);

  // Update cities when data changes
  useEffect(() => {
    console.log("Cities data:", citiesData, "Selected county:", selectedCounty);
    if (citiesData && Array.isArray(citiesData)) {
      setCities(citiesData);
    } else {
      setCities([]);
    }
  }, [citiesData]);

  // Update zip codes when data changes
  useEffect(() => {
    console.log("Zip codes data:", zipCodesData, "Selected city:", selectedCity);
    if (zipCodesData && Array.isArray(zipCodesData)) {
      setZipCodes(zipCodesData);
    } else {
      setZipCodes([]);
    }
  }, [zipCodesData]);

  return {
    counties,
    cities,
    zipCodes,
    isLoadingCounties,
    isLoadingCities,
    isLoadingZipCodes,
  };
}
