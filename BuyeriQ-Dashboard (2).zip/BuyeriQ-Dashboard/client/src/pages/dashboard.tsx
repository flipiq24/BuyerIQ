import { useState } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import TabNavigation from "@/components/layout/tab-navigation";
import InvestorsTab from "@/components/investors-tab";
import AgentsTab from "@/components/agents-tab";
import OfficesTab from "@/components/offices-tab";
import LendersTab from "@/components/lenders-tab";
import { TabType } from "@/types";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<TabType>("investors");

  const renderActiveTab = () => {
    switch (activeTab) {
      case "investors":
        return <InvestorsTab />;
      case "agents":
        return <AgentsTab />;
      case "offices":
        return <OfficesTab />;
      case "lenders":
        return <LendersTab />;
      default:
        return <InvestorsTab />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <div className="flex-grow flex flex-col">
        <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />
        <div className="container mx-auto px-4 py-5">
          {renderActiveTab()}
        </div>
      </div>
      <Footer />
    </div>
  );
}
