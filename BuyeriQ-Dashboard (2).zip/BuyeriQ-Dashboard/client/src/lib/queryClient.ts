import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  const res = await fetch(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    console.log("QueryKey received:", queryKey); // Debug log
  
    // Base URL is the first element
    const baseUrl = queryKey[0] as string;
    
    // Initialize URL parameters object
    const urlParams = new URLSearchParams();
    
    // Handle additional parameters if present in queryKey
    if (queryKey.length > 1) {
      // Special case for when the second element is an object (filter params)
      if (queryKey.length >= 2 && typeof queryKey[1] === 'object' && queryKey[1] !== null && !Array.isArray(queryKey[1])) {
        const filterParams = queryKey[1] as Record<string, any>;
        
        // Add each property of the filter object as a separate URL parameter
        for (const key in filterParams) {
          const value = filterParams[key];
          if (value !== undefined && value !== null && value !== '') {
            urlParams.append(key, String(value));
          }
        }
        
        // Handle any additional parameters after the filter object
        for (let i = 2; i < queryKey.length; i += 2) {
          if (i + 1 >= queryKey.length) break;
          
          const paramName = String(queryKey[i]);
          const paramValue = queryKey[i + 1];
          
          if (paramValue !== undefined && paramValue !== null && paramValue !== '') {
            urlParams.append(paramName, String(paramValue));
          }
        }
      } else {
        // Standard key-value pair processing (for non-object parameters)
        for (let i = 1; i < queryKey.length; i += 2) {
          // If we have a key but no value (odd number of elements), skip
          if (i + 1 >= queryKey.length) break;
          
          const paramName = String(queryKey[i]);
          const paramValue = queryKey[i + 1];
          
          // Only add the parameter if the value is defined and not empty
          if (paramValue !== undefined && paramValue !== null && paramValue !== '') {
            urlParams.append(paramName, String(paramValue));
          }
        }
      }
    }
    
    // Build the final URL with parameters
    const queryString = urlParams.toString();
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    
    console.log("Final URL for fetch:", url); // Debug log
    
    const res = await fetch(url, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
