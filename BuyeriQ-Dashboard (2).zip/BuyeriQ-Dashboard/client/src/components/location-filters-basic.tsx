import { useState, useEffect } from "react";

interface LocationOption {
  label: string;
  value: string;
}

interface LocationFiltersProps {
  county: string;
  city: string;
  zipcode: string; // Changed from zipCode to zipcode
  onCountyChange: (value: string) => void;
  onCityChange: (value: string) => void;
  onZipCodeChange: (value: string) => void;
}

export default function LocationFiltersBasic({
  county,
  city,
  zipcode, // Changed from zipCode to zipcode
  onCountyChange,
  onCityChange,
  onZipCodeChange
}: LocationFiltersProps) {
  const [counties, setCounties] = useState<LocationOption[]>([]);
  const [cities, setCities] = useState<LocationOption[]>([]);
  const [zipCodes, setZipCodes] = useState<LocationOption[]>([]);
  
  const [isLoadingCounties, setIsLoadingCounties] = useState(false);
  const [isLoadingCities, setIsLoadingCities] = useState(false);
  const [isLoadingZipCodes, setIsLoadingZipCodes] = useState(false);

  // Hardcoded test data in case API fails
  const hardcodedCounties = [
    { label: "Los Angeles", value: "los_angeles" },
    { label: "Orange", value: "orange" },
    { label: "San Diego", value: "san_diego" }
  ];
  
  const hardcodedCities = {
    "los_angeles": [
      { label: "Los Angeles", value: "los_angeles" },
      { label: "Long Beach", value: "long_beach" },
      { label: "Pasadena", value: "pasadena" }
    ],
    "orange": [
      { label: "Anaheim", value: "anaheim" },
      { label: "Irvine", value: "irvine" },
      { label: "Santa Ana", value: "santa_ana" }
    ],
    "san_diego": [
      { label: "San Diego", value: "san_diego" },
      { label: "Chula Vista", value: "chula_vista" },
      { label: "Oceanside", value: "oceanside" }
    ]
  };
  
  const hardcodedZipCodes = {
    "los_angeles": [
      { label: "90001", value: "90001" },
      { label: "90002", value: "90002" },
      { label: "90003", value: "90003" }
    ],
    "long_beach": [
      { label: "90801", value: "90801" },
      { label: "90802", value: "90802" },
      { label: "90803", value: "90803" }
    ],
    "pasadena": [
      { label: "91101", value: "91101" },
      { label: "91102", value: "91102" },
      { label: "91103", value: "91103" }
    ],
    "anaheim": [
      { label: "92801", value: "92801" },
      { label: "92802", value: "92802" },
      { label: "92803", value: "92803" }
    ],
    "irvine": [
      { label: "92601", value: "92601" },
      { label: "92602", value: "92602" },
      { label: "92603", value: "92603" }
    ],
    "santa_ana": [
      { label: "92701", value: "92701" },
      { label: "92702", value: "92702" },
      { label: "92703", value: "92703" }
    ],
    "san_diego": [
      { label: "92101", value: "92101" },
      { label: "92102", value: "92102" },
      { label: "92103", value: "92103" }
    ],
    "chula_vista": [
      { label: "91901", value: "91901" },
      { label: "91902", value: "91902" },
      { label: "91903", value: "91903" }
    ],
    "oceanside": [
      { label: "92051", value: "92051" },
      { label: "92052", value: "92052" },
      { label: "92053", value: "92053" }
    ]
  };

  // Load counties on component mount
  useEffect(() => {
    setCounties(hardcodedCounties);
  }, []);

  // When county changes, load cities
  useEffect(() => {
    if (!county) {
      setCities([]);
      return;
    }
    
    if (county in hardcodedCities) {
      // @ts-ignore
      setCities(hardcodedCities[county]);
    } else {
      setCities([]);
    }
  }, [county]);

  // When city changes, load zip codes
  useEffect(() => {
    if (!city) {
      setZipCodes([]);
      return;
    }
    
    if (city in hardcodedZipCodes) {
      // @ts-ignore
      setZipCodes(hardcodedZipCodes[city]);
    } else {
      setZipCodes([]);
    }
  }, [city]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div>
        <label htmlFor="county" className="block text-sm font-medium text-text-secondary mb-1">County</label>
        <select
          id="county"
          name="county"
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          value={county}
          onChange={(e) => onCountyChange(e.target.value)}
          disabled={isLoadingCounties}
        >
          <option value="">Select County</option>
          {counties.map((countyOption) => (
            <option key={countyOption.value} value={countyOption.value}>{countyOption.label}</option>
          ))}
        </select>
      </div>
      
      <div>
        <label htmlFor="city" className="block text-sm font-medium text-text-secondary mb-1">City</label>
        <select
          id="city"
          name="city"
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          value={city}
          onChange={(e) => onCityChange(e.target.value)}
          disabled={!county || isLoadingCities}
        >
          <option value="">Select City</option>
          {cities.map((cityOption) => (
            <option key={cityOption.value} value={cityOption.value}>{cityOption.label}</option>
          ))}
        </select>
      </div>
      
      <div>
        <label htmlFor="zipcode" className="block text-sm font-medium text-text-secondary mb-1">Zip Code</label>
        <select
          id="zipcode"
          name="zipcode"
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          value={zipcode}
          onChange={(e) => onZipCodeChange(e.target.value)}
          disabled={!city || isLoadingZipCodes}
        >
          <option value="">Select Zip</option>
          {zipCodes.map((zipOption) => (
            <option key={zipOption.value} value={zipOption.value}>{zipOption.label}</option>
          ))}
        </select>
      </div>
    </div>
  );
}