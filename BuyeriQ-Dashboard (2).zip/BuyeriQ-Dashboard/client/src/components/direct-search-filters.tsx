import { useState, useEffect, ReactNode } from "react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Search, Loader2 } from "lucide-react";
import { FilterParams } from "@/types";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";

interface SearchFiltersProps {
  onSearch: (filters: FilterParams) => void;
  additionalFilters: ReactNode;
  filters: FilterParams;
  setFilters: (filters: FilterParams) => void;
  onSaveSearch?: () => void;
}

// Location types
type LocationOption = {
  label: string;
  value: string;
};

export default function DirectSearchFilters({ onSearch, additionalFilters, filters, setFilters, onSaveSearch }: SearchFiltersProps) {
  const [localFilters, setLocalFilters] = useState<FilterParams>({
    ...filters,
    zipcode: filters.zipcode || '' // Ensure we're using zipcode (lowercase) not zipCode
  });
  
  // Update local filters when parent filters change
  useEffect(() => {
    setLocalFilters({
      ...filters,
      zipcode: filters.zipcode || '' // Ensure we're using zipcode (lowercase) not zipCode
    });
  }, [filters]);

  // Hardcoded data - use this since it was working before
  const ALL_COUNTIES = [
    { id: 1, label: "Los Angeles", value: "los_angeles" },
    { id: 2, label: "Orange", value: "orange" },
    { id: 3, label: "San Diego", value: "san_diego" }
  ];

  const ALL_CITIES = [
    // Los Angeles County
    { id: 1, label: "Los Angeles", value: "los_angeles", countyId: 1 },
    { id: 2, label: "Long Beach", value: "long_beach", countyId: 1 },
    { id: 3, label: "Pasadena", value: "pasadena", countyId: 1 },
    
    // Orange County
    { id: 4, label: "Anaheim", value: "anaheim", countyId: 2 },
    { id: 5, label: "Irvine", value: "irvine", countyId: 2 },
    { id: 6, label: "Santa Ana", value: "santa_ana", countyId: 2 },
    
    // San Diego County
    { id: 7, label: "San Diego", value: "san_diego", countyId: 3 },
    { id: 8, label: "Chula Vista", value: "chula_vista", countyId: 3 },
    { id: 9, label: "Oceanside", value: "oceanside", countyId: 3 }
  ];

  const ALL_ZIPCODES = [
    // Los Angeles
    { id: 1, label: "90001", value: "90001", cityId: 1 },
    { id: 2, label: "90002", value: "90002", cityId: 1 },
    { id: 3, label: "90003", value: "90003", cityId: 1 },
    
    // Long Beach
    { id: 4, label: "90801", value: "90801", cityId: 2 },
    { id: 5, label: "90802", value: "90802", cityId: 2 },
    { id: 6, label: "90803", value: "90803", cityId: 2 },
    
    // Pasadena
    { id: 7, label: "91101", value: "91101", cityId: 3 },
    { id: 8, label: "91102", value: "91102", cityId: 3 },
    { id: 9, label: "91103", value: "91103", cityId: 3 },
    
    // Anaheim
    { id: 10, label: "92801", value: "92801", cityId: 4 },
    { id: 11, label: "92802", value: "92802", cityId: 4 },
    { id: 12, label: "92803", value: "92803", cityId: 4 },
    
    // Irvine
    { id: 13, label: "92602", value: "92602", cityId: 5 },
    { id: 14, label: "92603", value: "92603", cityId: 5 },
    { id: 15, label: "92604", value: "92604", cityId: 5 },
    
    // Santa Ana
    { id: 16, label: "92701", value: "92701", cityId: 6 },
    { id: 17, label: "92702", value: "92702", cityId: 6 },
    { id: 18, label: "92703", value: "92703", cityId: 6 },
    
    // San Diego
    { id: 19, label: "92101", value: "92101", cityId: 7 },
    { id: 20, label: "92102", value: "92102", cityId: 7 },
    { id: 21, label: "92103", value: "92103", cityId: 7 },
    
    // Chula Vista
    { id: 22, label: "91910", value: "91910", cityId: 8 },
    { id: 23, label: "91911", value: "91911", cityId: 8 },
    { id: 24, label: "91912", value: "91912", cityId: 8 },
    
    // Oceanside
    { id: 25, label: "92049", value: "92049", cityId: 9 },
    { id: 26, label: "92051", value: "92051", cityId: 9 },
    { id: 27, label: "92052", value: "92052", cityId: 9 }
  ];

  // Filter cities based on selected county
  const counties = ALL_COUNTIES;
  const isLoadingCounties = false;
  
  // Filter cities based on selected county
  const filteredCities = localFilters.county 
    ? ALL_CITIES.filter(c => {
        const selectedCounty = ALL_COUNTIES.find(county => county.value === localFilters.county);
        return selectedCounty ? c.countyId === selectedCounty.id : false;
      })
    : [];
  const cities = filteredCities;
  const isLoadingCities = false;
  
  // Filter zip codes based on selected city
  const filteredZipCodes = localFilters.city
    ? ALL_ZIPCODES.filter(z => {
        const selectedCity = ALL_CITIES.find(city => city.value === localFilters.city);
        return selectedCity ? z.cityId === selectedCity.id : false;
      })
    : [];
  const zipCodes = filteredZipCodes;
  const isLoadingZipCodes = false;
  
  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setLocalFilters({ ...localFilters, [name]: value });
  };

  const handleCountyChange = (value: string) => {
    // Reset city and zipcode when county changes
    if (value === 'all_counties') {
      setLocalFilters({ ...localFilters, county: '', city: '', zipcode: '' });
    } else {
      setLocalFilters({ ...localFilters, county: value, city: '', zipcode: '' });
    }
  };

  const handleCityChange = (value: string) => {
    // Reset zipcode when city changes
    if (value === 'all_cities') {
      setLocalFilters({ ...localFilters, city: '', zipcode: '' });
    } else {
      setLocalFilters({ ...localFilters, city: value, zipcode: '' });
    }
  };

  const handleZipCodeChange = (value: string) => {
    if (value === 'all_zip_codes') {
      setLocalFilters({ ...localFilters, zipcode: '' });
    } else {
      setLocalFilters({ ...localFilters, zipcode: value });
    }
  };

  const handleRadiusChange = (value: number[]) => {
    setLocalFilters({ ...localFilters, radius: value[0] });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(localFilters);
  };

  return (
    <div className="bg-white rounded-lg shadow mb-5 p-4">
      <h2 className="text-lg font-semibold mb-4 text-primary-dark">Search Filters</h2>
      
      <form onSubmit={handleSubmit}>
        {/* Location filters */}
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-text-secondary mb-2">Location Filters</h3>
          
          {/* Waterfall filtering system with live data */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="space-y-2">
              <Label htmlFor="county">County</Label>
              <Select
                value={localFilters.county}
                onValueChange={handleCountyChange}
              >
                <SelectTrigger id="county">
                  <SelectValue placeholder="Select county">
                    {isLoadingCounties && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_counties">All Counties</SelectItem>
                  {counties.map((county, index) => (
                    <SelectItem key={index} value={county.value}>
                      {county.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <Select
                value={localFilters.city}
                onValueChange={handleCityChange}
                disabled={!localFilters.county || isLoadingCities}
              >
                <SelectTrigger id="city">
                  <SelectValue placeholder={!localFilters.county ? "Select county first" : "Select city"}>
                    {isLoadingCities && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_cities">All Cities</SelectItem>
                  {cities && cities.length > 0 ? (
                    cities.map((city, index) => (
                      <SelectItem key={index} value={city.value}>
                        {city.label}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="_no_cities_found" disabled>No cities found</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="zipcode">ZIP Code</Label>
              <Select
                value={localFilters.zipcode}
                onValueChange={handleZipCodeChange}
                disabled={!localFilters.city || isLoadingZipCodes}
              >
                <SelectTrigger id="zipcode">
                  <SelectValue placeholder={!localFilters.city ? "Select city first" : "Select ZIP code"}>
                    {isLoadingZipCodes && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_zip_codes">All ZIP Codes</SelectItem>
                  {zipCodes && zipCodes.length > 0 ? (
                    zipCodes.map((zipCode, index) => (
                      <SelectItem key={index} value={zipCode.value}>
                        {zipCode.label}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="_no_zipcodes_found" disabled>No ZIP codes found</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div>
              <label htmlFor="address" className="block text-sm font-medium text-text-secondary mb-1">Address</label>
              <input
                type="text"
                id="address"
                name="address"
                placeholder="Enter specific address"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                value={localFilters.address}
                onChange={handleFilterChange}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1">
                Radius: <span id="radius-value">{localFilters.radius}</span> miles
              </label>
              <Slider
                defaultValue={[10]}
                min={1}
                max={30}
                step={1}
                value={[localFilters.radius]}
                onValueChange={handleRadiusChange}
                className="w-full"
              />
            </div>
          </div>
        </div>
        
        {/* Additional filters */}
        <div>
          <h3 className="text-sm font-semibold text-text-secondary mb-2">Additional Filters</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {additionalFilters}
            
            <div className="flex items-end space-x-2">
              <Button type="submit" className="w-full sm:w-auto px-4 py-2 bg-accent hover:bg-amber-500 text-white">
                <Search className="h-5 w-5 mr-2" />
                Search
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                className="w-full sm:w-auto px-4 py-2 border-primary hover:bg-primary-light text-primary hover:text-primary-dark"
                onClick={() => onSaveSearch && onSaveSearch()}
              >
                Save Search
              </Button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}