import React, { useState, useEffect } from "react";
import { Eye, ArrowDown, ArrowUp, Download, SlidersHorizontal, HelpCircle, MessageSquare, BarChart2, ListFilter } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { DataTable } from "@/components/ui/data-table";
import { 
  Pagination, 
  PaginationContent, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from "@/components/ui/pagination";
import { Column } from "@/types";

interface ResultsTableProps {
  title: string;
  count: number;
  data: any[];
  columns: Column[];
  page: number;
  pageSize: number;
  totalPages: number;
  resultTotals?: any;  // Totals from current filtered results
  entityTotals?: any;  // Totals from all entity data
  onPageChange: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  onViewChange?: (view: "results" | "communication") => void;
}

export default function ResultsTable({
  title,
  count,
  data,
  columns,
  page,
  pageSize,
  totalPages,
  resultTotals,
  entityTotals,
  onPageChange,
  onPageSizeChange,
  onViewChange
}: ResultsTableProps) {
  const [activeView, setActiveView] = useState<"results" | "communication">("results");
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [localPageSize, setLocalPageSize] = useState<number>(pageSize);

  const [showTotalsOption, setShowTotalsOption] = useState<"both" | "results" | "entity">("both");
  
  // For debugging
  useEffect(() => {
    if (entityTotals) {
      console.log('Entity Totals:', entityTotals);
      console.log('Is Array:', Array.isArray(entityTotals));
      console.log('Type:', typeof entityTotals);
      
      if (Array.isArray(entityTotals) && entityTotals.length > 0) {
        console.log('First Entity:', entityTotals[0]);
      }
    }
  }, [entityTotals]);
  
  // Handle page size change
  const handlePageSizeChange = (newSize: number) => {
    setLocalPageSize(newSize);
    onPageChange(1); // Reset to first page when changing page size
  };
  
  useEffect(() => {
    // Only trigger the callback if localPageSize doesn't match the incoming pageSize
    if (localPageSize !== pageSize) {
      // This assumes parent component provides an onPageSizeChange callback
      if (onPageSizeChange) {
        onPageSizeChange(localPageSize);
      }
    }
  }, [localPageSize, pageSize, onPageSizeChange]);
  
  const formatCurrency = (value: any) => {
    // If it's already a string formatted as currency, return it as is
    if (typeof value === 'string' && value.startsWith('$')) {
      return value;
    }
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(Number(value));
  };

  const formatPercentage = (value: any) => {
    // If it's already a string ending with '%', return it as is
    if (typeof value === 'string' && value.endsWith('%')) {
      return value;
    }
    // Otherwise format it as a percentage
    return `${(Number(value) * 100).toFixed(0)}%`;
  };

  const formatRatio = (value: any) => {
    // If it's a string (already formatted as days), return it as is
    if (typeof value === 'string') {
      return value;
    }
    // Otherwise format it as a decimal
    return Number(value).toFixed(2);
  };

  const handleSort = (columnId: string) => {
    if (sortColumn === columnId) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(columnId);
      setSortDirection("asc");
    }
  };
  
  // Function is no longer needed as the "Sort by Entity Totals" toggle was removed

  const renderCellValue = (row: any, column: Column) => {
    const value = row[column.accessorKey];
    
    if (column.isTag && value) {
      const isLoan = value.toString().toLowerCase() === 'loan';
      return (
        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
          isLoan ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
        }`}>
          {value}
        </span>
      );
    }
    
    if (column.isCurrency && value) {
      return formatCurrency(value);
    }
    
    if (column.isPercentage && value) {
      return formatPercentage(value);
    }
    
    if (column.accessorKey.includes('Ratio') && value !== undefined) {
      return formatRatio(value);
    }
    
    // Special handling for Last Property Purchase column
    if (column.id === "lastPropertyPurchase" || column.id === "lastInvestorProperty") {
      // Check if we have all the required fields
      if (row.lastPropertyNumber && row.lastPropertyAddress && row.lastPropertyCity) {
        return (
          <div className="max-w-xs truncate">
            <span className="font-medium">{row.lastPropertyNumber}</span> {row.lastPropertyAddress}, {row.lastPropertyCity}
          </div>
        );
      } 
      // Some entity types might have these fields named differently
      else if (row.lastInvestorProperty) {
        return (
          <div className="max-w-xs truncate">
            {row.lastInvestorProperty}
          </div>
        );
      }
      // In entity totals rows, copy the data from the original entity if available
      else if ((row.isEntityTotal || typeof row.totalTransactions === 'number') && data) {
        // Look for a matching entity ID in the filtered data
        const matchingEntity = data.find((entity: any) => entity.id === row.id);
        if (matchingEntity) {
          if (matchingEntity.lastPropertyNumber && matchingEntity.lastPropertyAddress && matchingEntity.lastPropertyCity) {
            return (
              <div className="max-w-xs truncate">
                <span className="font-medium">{matchingEntity.lastPropertyNumber}</span> {matchingEntity.lastPropertyAddress}, {matchingEntity.lastPropertyCity}
              </div>
            );
          } else if (matchingEntity.lastInvestorProperty) {
            return (
              <div className="max-w-xs truncate">
                {matchingEntity.lastInvestorProperty}
              </div>
            );
          }
        }
      }
      // If we only have parts of the required data, show what we have
      else if (row.lastPropertyAddress) {
        return row.lastPropertyAddress;
      }
      else if (row.lastPropertyCity) {
        return row.lastPropertyCity;
      }
      // If nothing is available after all these checks, show the last purchased date as a fallback
      else if (row.lastPurchaseDate) {
        return `Property purchased on ${new Date(row.lastPurchaseDate).toLocaleDateString()}`;
      }
      // If absolutely nothing is available, return "N/A"
      else {
        return "N/A";
      }
    }
    
    // Handle hometown, location, and address fields with consistent display
    if (column.accessorKey === "hometown" || column.accessorKey === "location") {
      if (row[column.accessorKey]) {
        return row[column.accessorKey];
      } else if (row.location) {
        return row.location;
      } else if (row.hometown) {
        return row.hometown;
      } else if (row.city) {
        return row.city;
      } else if (row.address) {
        // Extract city from address if possible
        const addressParts = row.address.split(',');
        if (addressParts.length > 1) {
          return addressParts[1].trim();
        }
        return row.address;
      } else {
        return "N/A";
      }
    }
    
    return value;
  };

  // Calculate pagination details
  const start = (page - 1) * pageSize + 1;
  const end = Math.min(start + pageSize - 1, count);
  
  const getPageNumbers = () => {
    const pageNumbers = [];
    let startPage = Math.max(1, page - 2);
    let endPage = Math.min(totalPages, page + 2);
    
    // Ensure we always show 5 page numbers if available
    if (endPage - startPage < 4 && totalPages > 4) {
      if (startPage === 1) {
        endPage = Math.min(startPage + 4, totalPages);
      } else if (endPage === totalPages) {
        startPage = Math.max(endPage - 4, 1);
      }
    }
    
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }
    
    return pageNumbers;
  };

  return (
    <div>
      {/* Results Header */}
      <div className="mb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <h2 className="text-lg font-semibold text-primary-dark mb-2 sm:mb-0">
          Results ({count} {title.toLowerCase()} found)
        </h2>
        <div className="flex items-center space-x-2">
          {onViewChange && (
            <div className="flex bg-muted rounded-lg p-1 mr-2">
              <button
                className={`px-4 py-[6px] rounded-md text-sm ${
                  activeView === "results" 
                    ? "bg-white text-primary shadow" 
                    : "text-muted-foreground hover:text-primary"
                }`}
                onClick={() => {
                  setActiveView("results");
                  onViewChange("results");
                }}
              >
                Results
              </button>
              <button
                className={`px-4 py-[6px] rounded-md text-sm ${
                  activeView === "communication"
                    ? "bg-white text-primary shadow" 
                    : "text-muted-foreground hover:text-primary"
                }`}
                onClick={() => {
                  setActiveView("communication");
                  onViewChange("communication");
                }}
              >
                Communication
              </button>
            </div>
          )}
          
          <Button 
            variant="outline" 
            size="sm" 
            className="h-9"
            onClick={() => {
              // Prepare the data to export - combine results and entity totals
              const exportData = [...data];
              
              // Add entity totals if available
              if (entityTotals) {
                if (Array.isArray(entityTotals)) {
                  entityTotals.forEach((entityTotal: any) => {
                    // Add a flag to identify entity total rows
                    exportData.push({
                      ...entityTotal,
                      isEntityTotal: true // Add marker to easily identify total rows in the CSV
                    });
                  });
                } else if (typeof entityTotals === 'object') {
                  // If it's a single object
                  exportData.push({
                    ...entityTotals,
                    isEntityTotal: true
                  });
                }
              }
              
              // Convert to CSV
              const headers = columns.map(col => col.header).join(',');
              const rows = exportData.map(row => {
                // Add a prefix to the first column if this is a total row
                return columns.map(col => {
                  if (row.isEntityTotal && col.id === columns[0].id) {
                    // For the first column of entity totals, add a label
                    const nameKey = 
                      columns.some(col => col.id === "entityName") ? "entityName" :
                      columns.some(col => col.id === "agentName") ? "agentName" :
                      columns.some(col => col.id === "officeName") ? "officeName" :
                      columns.some(col => col.id === "lenderName") ? "lenderName" : null;
                    
                    if (nameKey && row[nameKey]) {
                      return `${row[nameKey]} (ALL DATA)`;
                    }
                  }
                  
                  // For all other cells, just render the value
                  let value = row[col.accessorKey];
                  if (col.isCurrency && value) {
                    // Remove currency symbols for CSV export
                    value = Number(value).toString();
                  }
                  return value;
                }).join(',');
              }).join('\n');
              
              // Create a CSV file
              const csv = `${headers}\n${rows}`;
              const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
              const url = URL.createObjectURL(blob);
              
              // Create a download link and trigger it
              const link = document.createElement('a');
              link.setAttribute('href', url);
              const fileName = `${title.toLowerCase()}_export_${new Date().toISOString().split('T')[0]}.csv`;
              link.setAttribute('download', fileName);
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              
              // Free up the object URL
              URL.revokeObjectURL(url);
            }}
          >
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
          
          {/* Totals Display Toggle Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9">
                <BarChart2 className="h-4 w-4 mr-1" />
                Totals Display
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setShowTotalsOption("both")}>
                Show Both Totals {showTotalsOption === "both" && <span className="ml-2">✓</span>}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setShowTotalsOption("results")}>
                Filtered Results Only {showTotalsOption === "results" && <span className="ml-2">✓</span>}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setShowTotalsOption("entity")}>
                Entity Totals Only {showTotalsOption === "entity" && <span className="ml-2">✓</span>}
              </DropdownMenuItem>

            </DropdownMenuContent>
          </DropdownMenu>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9">
                <SlidersHorizontal className="h-4 w-4 mr-1" />
                Sort By
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {columns
                .filter(col => col.sortable)
                .map(column => (
                  <DropdownMenuItem 
                    key={column.id}
                    onClick={() => handleSort(column.id)}
                  >
                    {column.header} {sortColumn === column.id && (
                      sortDirection === "asc" ? <ArrowUp className="h-4 w-4 ml-2" /> : <ArrowDown className="h-4 w-4 ml-2" />
                    )}
                  </DropdownMenuItem>
                ))
              }
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      {/* Results Table */}
      <div className="overflow-x-auto bg-white rounded-lg shadow">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-primary-light bg-opacity-50">
            <tr>
              {columns.map(column => (
                <th
                  key={column.id}
                  scope="col"
                  className="px-4 py-3 text-left text-xs font-semibold text-text-primary tracking-wider cursor-pointer relative group"
                  onClick={() => column.sortable && handleSort(column.id)}
                >
                  <div className="flex items-center">
                    {column.tooltip ? (
                      <TooltipProvider>
                        <Tooltip delayDuration={300}>
                          <TooltipTrigger asChild onClick={(e) => {
                            if (column.sortable) {
                              e.stopPropagation();
                              handleSort(column.id);
                            }
                          }}>
                            <span className="cursor-help underline decoration-dotted decoration-gray-400">{column.header}</span>
                          </TooltipTrigger>
                          <TooltipContent className="z-[99999] max-w-xs">
                            <div className="font-medium text-xs mb-1 text-blue-300">{column.header}</div>
                            <div className="text-xs">{column.tooltip}</div>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    ) : (
                      column.header
                    )}
                    {column.sortable && sortColumn === column.id && (
                      <span className="ml-1">
                        {sortDirection === "asc" ? "↑" : "↓"}
                      </span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {showTotalsOption === "entity" && entityTotals ? (
              // Modified Entity Totals Only view - we'll use data as our entity list
              // and map through entityTotals to find the corresponding all-time data for each entity
              data.map((entityData: any, idx: number) => {
                // Find the matching entity total for this specific entity
                const entityId = entityData.id;
                let matchingEntityTotal = null;
                
                // Check if entityTotals is an array before using find
                if (Array.isArray(entityTotals)) {
                  // Find the matching entity in the entityTotals array
                  matchingEntityTotal = entityTotals.find((entity: any) => entity.id === entityId);
                } else if (entityTotals && typeof entityTotals === 'object') {
                  // If it's a single object, only use it if the IDs match
                  // In the absence of proper entityTotals array, we'll use this for display
                  matchingEntityTotal = entityTotals;
                }
                
                // If no matching entity total was found, don't render this row
                if (!matchingEntityTotal) {
                  return null;
                }
                
                return (
                  <tr key={`entity-total-${idx}`} className="bg-green-50">
                    {columns.map((column) => {
                      let value = null;
                      
                      if (column.id === columns[0].id) {
                        // For the first column, show the entity name
                        const nameKey = 
                          columns.some(col => col.id === "entityName") ? "entityName" :
                          columns.some(col => col.id === "agentName") ? "agentName" :
                          columns.some(col => col.id === "officeName") ? "officeName" :
                          columns.some(col => col.id === "lenderName") ? "lenderName" : null;
                          
                        if (nameKey && entityData[nameKey]) {
                          value = <span className="text-green-700">{entityData[nameKey]} (All Data)</span>;
                        } else {
                          value = <span className="text-green-700">Entity #{entityData.id} (All Data)</span>;
                        }
                      } 
                      // Special handling for the Last Property Purchase column in Entity Totals view
                      else if (column.id === "lastPropertyPurchase" || column.id === "lastInvestorProperty") {
                        // For property columns, always copy the data from the original entity
                        const enhancedTotal = {
                          ...matchingEntityTotal,
                          lastPropertyNumber: entityData.lastPropertyNumber,
                          lastPropertyAddress: entityData.lastPropertyAddress,
                          lastPropertyCity: entityData.lastPropertyCity,
                          lastInvestorProperty: entityData.lastInvestorProperty,
                          // Make sure to identify this as an entity total for rendering
                          isEntityTotal: true,
                          // Copy the ID to ensure entity matching
                          id: entityData.id,
                        };
                        value = renderCellValue(enhancedTotal, column);
                      }
                      else if (matchingEntityTotal[column.accessorKey] !== undefined) {
                        // Use entity totals when available
                        value = renderCellValue({ [column.accessorKey]: matchingEntityTotal[column.accessorKey] }, column);
                      } else if (entityData[column.accessorKey] !== undefined) {
                        // Fall back to using the regular data if totals don't have this field
                        value = renderCellValue({ [column.accessorKey]: entityData[column.accessorKey] }, column);
                      } else {
                        // Fallback for missing data
                        value = "-";
                      }
                      
                      return (
                        <td 
                          key={column.id} 
                          className="px-4 py-3 whitespace-nowrap text-sm text-green-700 font-medium"
                        >
                          {value}
                        </td>
                      );
                    })}
                  </tr>
                );
              }).filter(Boolean) // Filter out any null elements
                
            ) : (
              // Regular view with both totals or filtered results only
              data.map((row, i) => {
                // Using array instead of fragment to apply key at the outer level
                return [
                  // Regular data row (results totals) - only render if showing results totals
                  (showTotalsOption === "both" || showTotalsOption === "results") && (
                    <tr key={`data-row-${i}`} className="hover:bg-gray-50">
                      {columns.map(column => (
                        <td key={column.id} className="px-4 py-3 whitespace-nowrap text-sm text-text-secondary">
                          {column.id === columns[0].id ? (
                            <span className="font-medium text-text-primary">{renderCellValue(row, column)}</span>
                          ) : (
                            renderCellValue(row, column)
                          )}
                        </td>
                      ))}
                    </tr>
                  ),
                  
                  // All-time data row (entity totals) - only render if showing both totals
                  (entityTotals && showTotalsOption === "both") && (
                    <tr key={`totals-row-${i}`} className="bg-green-50">
                      {columns.map((column) => {
                        // Find the matching entity total for this specific entity
                        const entityId = row.id;
                        let matchingEntityTotal = null;
                        
                        // Use the same approach as for Entity Totals Only view
                        if (Array.isArray(entityTotals)) {
                          // Find the matching entity in the entityTotals array
                          matchingEntityTotal = entityTotals.find((entity: any) => entity.id === entityId);
                        } else if (entityTotals && typeof entityTotals === 'object') {
                          // If it's a single object, we'll use it as a fallback
                          // This isn't ideal but ensures something displays even with aggregated data
                          matchingEntityTotal = entityTotals;
                        }
                        
                        // Build the column value for all-time data
                        let value = null;
                        
                        if (column.id === columns[0].id) {
                          // For the first column (entity name), show a label
                          const nameKey = 
                            columns.some(col => col.id === "entityName") ? "entityName" :
                            columns.some(col => col.id === "agentName") ? "agentName" :
                            columns.some(col => col.id === "officeName") ? "officeName" :
                            columns.some(col => col.id === "lenderName") ? "lenderName" : null;
                            
                          if (nameKey && row[nameKey]) {
                            // Use the entity name from the current row data
                            value = <span className="text-green-700">{row[nameKey]} (All Data)</span>;
                          } else {
                            value = <span className="text-green-700">Entity #{row.id} (All Data)</span>;
                          }
                        } 
                        // Special handling for the Last Property Purchase column
                        else if (column.id === "lastPropertyPurchase" || column.id === "lastInvestorProperty") {
                          // For property columns, always use the data from the original row
                          const enhancedTotal = {
                            ...matchingEntityTotal,
                            lastPropertyNumber: row.lastPropertyNumber,
                            lastPropertyAddress: row.lastPropertyAddress,
                            lastPropertyCity: row.lastPropertyCity,
                            lastInvestorProperty: row.lastInvestorProperty,
                            // Make sure to identify this as an entity total for rendering
                            isEntityTotal: true,
                            // Copy the ID to ensure entity matching
                            id: row.id,
                          };
                          value = renderCellValue(enhancedTotal, column);
                        }
                        else if (matchingEntityTotal && matchingEntityTotal[column.accessorKey] !== undefined) {
                          // Use entity totals when available
                          value = renderCellValue({ [column.accessorKey]: matchingEntityTotal[column.accessorKey] }, column);
                        } else if (row[column.accessorKey] !== undefined) {
                          // Fallback to using regular row data when entity totals don't have the field
                          value = renderCellValue({ [column.accessorKey]: row[column.accessorKey] }, column);
                        } else {
                          // Final fallback for missing data
                          value = "-";
                        }
                        
                        return (
                          <td 
                            key={column.id} 
                            className="px-4 py-1 whitespace-nowrap text-xs text-green-700 font-medium border-t border-green-200"
                          >
                            {value}
                          </td>
                        );
                      })}
                    </tr>
                  )
                ].filter(Boolean); // Filter to remove any false/null values
              })
            )}
          </tbody>
        </table>
      </div>
      
      {/* Pagination */}
      <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6 rounded-b-lg shadow">
        <div className="flex-1 flex justify-between sm:hidden">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange(page - 1)}
            disabled={page === 1}
          >
            Previous
          </Button>
          <Button
            variant="outline" 
            size="sm"
            onClick={() => onPageChange(page + 1)}
            disabled={page === totalPages}
          >
            Next
          </Button>
        </div>
        <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
          <div>
            <p className="text-sm text-text-secondary">
              Showing <span className="font-medium">{start}</span> to <span className="font-medium">{end}</span> of{" "}
              <span className="font-medium">{count}</span> results
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-text-secondary">Show</span>
              <select 
                className="px-2 py-1 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-primary focus:border-primary"
                value={localPageSize}
                onChange={(e) => handlePageSizeChange(Number(e.target.value))}
              >
                <option value={5}>5</option>
                <option value={10}>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
              <span className="text-sm text-text-secondary">per page</span>
            </div>
            
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (page > 1) onPageChange(page - 1);
                    }} 
                    className={page === 1 ? "pointer-events-none opacity-50" : ""}
                  />
                </PaginationItem>
                
                {getPageNumbers().map(num => (
                  <PaginationItem key={num}>
                    <PaginationLink
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        onPageChange(num);
                      }}
                      isActive={page === num}
                    >
                      {num}
                    </PaginationLink>
                  </PaginationItem>
                ))}
                
                <PaginationItem>
                  <PaginationNext 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (page < totalPages) onPageChange(page + 1);
                    }}
                    className={page === totalPages ? "pointer-events-none opacity-50" : ""}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        </div>
      </div>
    </div>
  );
}