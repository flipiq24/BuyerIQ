import { useState, useEffect, ReactNode } from "react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { FilterParams } from "@/types";
import LocationFiltersBasic from "./location-filters-basic";

interface SearchFiltersProps {
  onSearch: (filters: FilterParams) => void;
  additionalFilters: ReactNode;
  filters: FilterParams;
  setFilters: (filters: FilterParams) => void;
  onSaveSearch?: () => void;
}

export default function SearchFilters({ onSearch, additionalFilters, filters, setFilters, onSaveSearch }: SearchFiltersProps) {
  const [localFilters, setLocalFilters] = useState<FilterParams>(filters);

  // Update local filters when parent filters change
  useEffect(() => {
    setLocalFilters(filters);
  }, [filters]);

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setLocalFilters({ ...localFilters, [name]: value });
  };

  const handleCountyChange = (value: string) => {
    // Reset city and zipcode when county changes
    setLocalFilters({ ...localFilters, county: value, city: '', zipcode: '' });
  };

  const handleCityChange = (value: string) => {
    // Reset zipcode when city changes
    setLocalFilters({ ...localFilters, city: value, zipcode: '' });
  };

  const handleZipCodeChange = (value: string) => {
    setLocalFilters({ ...localFilters, zipcode: value });
  };

  const handleRadiusChange = (value: number[]) => {
    setLocalFilters({ ...localFilters, radius: value[0] });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(localFilters);
  };

  return (
    <div className="bg-white rounded-lg shadow mb-5 p-4">
      <h2 className="text-lg font-semibold mb-4 text-primary-dark">Search Filters</h2>
      
      <form onSubmit={handleSubmit}>
        {/* Location filters */}
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-text-secondary mb-2">Location Filters</h3>
          
          {/* Location filters using new component */}
          <LocationFiltersBasic 
            county={localFilters.county}
            city={localFilters.city}
            zipcode={localFilters.zipcode} 
            onCountyChange={handleCountyChange}
            onCityChange={handleCityChange}
            onZipCodeChange={handleZipCodeChange}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div>
              <label htmlFor="address" className="block text-sm font-medium text-text-secondary mb-1">Address</label>
              <input
                type="text"
                id="address"
                name="address"
                placeholder="Enter specific address"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                value={localFilters.address}
                onChange={handleFilterChange}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1">
                Radius: <span id="radius-value">{localFilters.radius}</span> miles
              </label>
              <Slider
                defaultValue={[10]}
                min={1}
                max={30}
                step={1}
                value={[localFilters.radius]}
                onValueChange={handleRadiusChange}
                className="w-full"
              />
            </div>
          </div>
        </div>
        
        {/* Additional filters */}
        <div>
          <h3 className="text-sm font-semibold text-text-secondary mb-2">Additional Filters</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {additionalFilters}
            
            <div className="flex items-end space-x-2">
              <Button type="submit" className="w-full sm:w-auto px-4 py-2 bg-accent hover:bg-amber-500 text-white">
                <Search className="h-5 w-5 mr-2" />
                Search
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                className="w-full sm:w-auto px-4 py-2 border-primary hover:bg-primary-light text-primary hover:text-primary-dark"
                onClick={() => onSaveSearch && onSaveSearch()}
              >
                Save Search
              </Button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
