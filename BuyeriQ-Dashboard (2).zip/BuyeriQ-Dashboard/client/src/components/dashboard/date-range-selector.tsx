import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format, subDays, subMonths, subYears } from "date-fns";
import { cn } from "@/lib/utils";

interface DateRangeSelectorProps {
  onRangeChange: (startDate: Date, endDate: Date) => void;
}

export default function DateRangeSelector({ onRangeChange }: DateRangeSelectorProps) {
  const today = new Date();
  const [startDate, setStartDate] = useState<Date | undefined>(subMonths(today, 3));
  const [endDate, setEndDate] = useState<Date | undefined>(today);
  const [isStartOpen, setIsStartOpen] = useState(false);
  const [isEndOpen, setIsEndOpen] = useState(false);

  const presetRanges = [
    { label: 'Last 7 days', range: () => [subDays(today, 7), today] },
    { label: 'Last 30 days', range: () => [subDays(today, 30), today] },
    { label: 'Last 90 days', range: () => [subDays(today, 90), today] },
    { label: 'Last 12 months', range: () => [subYears(today, 1), today] },
    { label: 'Year to date', range: () => [new Date(today.getFullYear(), 0, 1), today] },
  ];

  const applyDateRange = (start: Date, end: Date) => {
    setStartDate(start);
    setEndDate(end);
    onRangeChange(start, end);
    setIsStartOpen(false);
    setIsEndOpen(false);
  };

  const applyPresetRange = (preset: typeof presetRanges[0]) => {
    const [start, end] = preset.range();
    applyDateRange(start, end);
  };

  return (
    <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4 items-start sm:items-center">
      <div className="flex space-x-2">
        <Popover open={isStartOpen} onOpenChange={setIsStartOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "w-[180px] justify-start text-left font-normal",
                !startDate && "text-muted-foreground"
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {startDate ? format(startDate, "PPP") : "Pick a date"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <Calendar
              mode="single"
              selected={startDate}
              onSelect={(date) => {
                setStartDate(date);
                if (endDate && date && date > endDate) {
                  setEndDate(date);
                }
                if (date && endDate) {
                  onRangeChange(date, endDate);
                  setIsStartOpen(false);
                }
              }}
              initialFocus
            />
          </PopoverContent>
        </Popover>

        <Popover open={isEndOpen} onOpenChange={setIsEndOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "w-[180px] justify-start text-left font-normal",
                !endDate && "text-muted-foreground"
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {endDate ? format(endDate, "PPP") : "Pick a date"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <Calendar
              mode="single"
              selected={endDate}
              onSelect={(date) => {
                setEndDate(date);
                if (startDate && date && date < startDate) {
                  setStartDate(date);
                }
                if (date && startDate) {
                  onRangeChange(startDate, date);
                  setIsEndOpen(false);
                }
              }}
              initialFocus
              disabled={(date) => startDate ? date < startDate : false}
            />
          </PopoverContent>
        </Popover>
      </div>

      <div className="flex flex-wrap gap-2">
        {presetRanges.map((preset, index) => (
          <Button
            key={index}
            variant="outline"
            size="sm"
            onClick={() => applyPresetRange(preset)}
          >
            {preset.label}
          </Button>
        ))}
      </div>
    </div>
  );
}