import { ArrowDown, ArrowUp, Minus } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MetricCard as MetricCardType } from "@/data/dashboardData";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface MetricCardProps {
  metric: MetricCardType;
}

export default function MetricCard({ metric }: MetricCardProps) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-base font-medium">{metric.title}</CardTitle>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className={`flex items-center px-2 py-1 rounded-full text-xs font-medium 
                  ${metric.trend === 'up' ? 'bg-green-100 text-green-800' : 
                    metric.trend === 'down' ? 'bg-red-100 text-red-800' : 
                    'bg-gray-100 text-gray-800'}`}
                >
                  {metric.trend === 'up' ? (
                    <ArrowUp className="h-3 w-3 mr-1" />
                  ) : metric.trend === 'down' ? (
                    <ArrowDown className="h-3 w-3 mr-1" />
                  ) : (
                    <Minus className="h-3 w-3 mr-1" />
                  )}
                  {Math.abs(metric.change)}%
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">
                  {metric.trend === 'up' 
                    ? `Increased by ${metric.change}% compared to previous period` 
                    : metric.trend === 'down' 
                    ? `Decreased by ${Math.abs(metric.change)}% compared to previous period`
                    : 'No significant change'}
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{metric.value}</div>
        <CardDescription className="mt-1 text-xs">{metric.description}</CardDescription>
      </CardContent>
    </Card>
  );
}