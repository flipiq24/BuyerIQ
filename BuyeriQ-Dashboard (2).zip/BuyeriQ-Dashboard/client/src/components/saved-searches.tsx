import { useState } from "react";
import { SavedSearch, TabType, FilterParams } from "@/types";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { 
  Button,
  buttonVariants,
} from "@/components/ui/button";
import {
  Bookmark,
  Clock,
  ArrowRight,
  Trash2,
  AlertCircle,
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SavedSearchesProps {
  onLoadSearch: (search: SavedSearch) => void;
}

// Placeholder data for demonstration
const placeholderSearches: SavedSearch[] = [
  {
    id: 1,
    name: "Los Angeles Cash Investors",
    tabType: "investors" as TabType,
    filters: {
      county: "los_angeles",
      city: "",
      zipCode: "",
      address: "",
      radius: 10,
      name: "",
      minUnits: "3",
      maxUnits: "10",
      filterByHometown: true
    } as FilterParams,
    createdAt: "2025-04-10T15:30:45.000Z",
    userId: 1
  },
  {
    id: 2,
    name: "Double-End Agents in Orange County",
    tabType: "agents" as TabType,
    filters: {
      county: "orange",
      city: "irvine",
      zipCode: "",
      address: "",
      radius: 5,
      name: "",
      minUnits: "",
      maxUnits: "",
      doubleEnd: true
    } as FilterParams,
    createdAt: "2025-04-15T09:45:12.000Z",
    userId: 1
  },
  {
    id: 3,
    name: "San Diego Lenders - High LTV",
    tabType: "lenders" as TabType,
    filters: {
      county: "san_diego",
      city: "",
      zipCode: "",
      address: "",
      radius: 15,
      name: "",
      minUnits: "",
      maxUnits: ""
    } as FilterParams,
    createdAt: "2025-04-18T14:22:38.000Z",
    userId: 1
  },
  {
    id: 4,
    name: "Beverly Hills Offices",
    tabType: "offices" as TabType,
    filters: {
      county: "los_angeles",
      city: "beverly_hills",
      zipCode: "90210",
      address: "",
      radius: 2,
      name: "",
      minUnits: "",
      maxUnits: ""
    } as FilterParams,
    createdAt: "2025-04-22T11:15:30.000Z",
    userId: 1
  },
  {
    id: 5,
    name: "San Francisco Bay Area Investors",
    tabType: "investors" as TabType,
    filters: {
      county: "san_francisco",
      city: "",
      zipCode: "",
      address: "",
      radius: 25,
      name: "",
      minUnits: "5",
      maxUnits: "20"
    } as FilterParams,
    createdAt: "2025-04-23T08:30:15.000Z",
    userId: 1
  }
];

export default function SavedSearches({ onLoadSearch }: SavedSearchesProps) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  
  // For demo, using the placeholder data instead of a real query
  const savedSearches = placeholderSearches;
  const isLoading = false;

  const handleDelete = async (id: number) => {
    try {
      await apiRequest("DELETE", `/api/saved-searches/${id}`);
      toast({
        title: "Search deleted",
        description: "The saved search has been deleted successfully",
      });
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: ["/api/saved-searches"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete saved search",
        variant: "destructive",
      });
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="gap-2"
        >
          <Bookmark className="h-4 w-4" />
          Saved Searches
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-0" align="end">
        <div className="p-4 border-b">
          <h3 className="font-medium text-sm">Saved Searches</h3>
          <p className="text-xs text-muted-foreground mt-1">
            Load or delete your previously saved searches
          </p>
        </div>
        
        {isLoading ? (
          <div className="p-4 text-center text-sm text-muted-foreground">
            Loading saved searches...
          </div>
        ) : !savedSearches || savedSearches.length === 0 ? (
          <div className="p-4 text-center text-sm text-muted-foreground">
            No saved searches found
          </div>
        ) : (
          <div className="max-h-[300px] overflow-auto">
            {savedSearches.map((search) => (
              <div 
                key={search.id} 
                className="p-3 border-b last:border-b-0 hover:bg-muted/50 flex justify-between items-center"
              >
                <div>
                  <div className="font-medium text-sm">{search.name}</div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                    <Clock className="h-3 w-3" />
                    <span>
                      {new Date(search.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => {
                      onLoadSearch(search);
                      setOpen(false);
                    }}
                  >
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive"
                    onClick={() => handleDelete(search.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}