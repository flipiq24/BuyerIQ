import { useState, useEffect } from "react";
import { Eye, ArrowDown, ArrowUp, Download, SlidersHorizontal, HelpCircle, MessageSquare, BarChart2, ListFilter } from "lucide-react";
import { useRef } from "react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { DataTable } from "@/components/ui/data-table";
import { 
  Pagination, 
  PaginationContent, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from "@/components/ui/pagination";
import { Column } from "@/types";

interface ResultsTableProps {
  title: string;
  count: number;
  data: any[];
  columns: Column[];
  page: number;
  pageSize: number;
  totalPages: number;
  resultTotals?: any;  // Totals from current filtered results
  entityTotals?: any;  // Totals from all entity data
  onPageChange: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  onViewChange?: (view: "results" | "communication") => void;
  onSortByTotalsChange?: (sortByEntityTotals: boolean) => void;
}

export default function ResultsTable({
  title,
  count,
  data,
  columns,
  page,
  pageSize,
  totalPages,
  resultTotals,
  entityTotals,
  onPageChange,
  onPageSizeChange,
  onViewChange,
  onSortByTotalsChange
}: ResultsTableProps) {
  const [activeView, setActiveView] = useState<"results" | "communication">("results");
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [localPageSize, setLocalPageSize] = useState<number>(pageSize);
  const [sortByEntityTotals, setSortByEntityTotals] = useState<boolean>(false);
  const [showTotalsOption, setShowTotalsOption] = useState<"both" | "results" | "entity">("both");
  
  // Handle page size change
  const handlePageSizeChange = (newSize: number) => {
    setLocalPageSize(newSize);
    onPageChange(1); // Reset to first page when changing page size
  };
  
  // Handle toggling between filtered results and entity totals
  const handleToggleShowTotals = (option: "both" | "results" | "entity") => {
    setShowTotalsOption(option);
  };
  
  useEffect(() => {
    // Only trigger the callback if localPageSize doesn't match the incoming pageSize
    if (localPageSize !== pageSize) {
      // This assumes parent component provides an onPageSizeChange callback
      if (onPageSizeChange) {
        onPageSizeChange(localPageSize);
      }
    }
  }, [localPageSize, pageSize, onPageSizeChange]);
  
  const formatCurrency = (value: any) => {
    // If it's already a string formatted as currency, return it as is
    if (typeof value === 'string' && value.startsWith('$')) {
      return value;
    }
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(Number(value));
  };

  const formatPercentage = (value: any) => {
    // If it's already a string ending with '%', return it as is
    if (typeof value === 'string' && value.endsWith('%')) {
      return value;
    }
    // Otherwise format it as a percentage
    return `${(Number(value) * 100).toFixed(0)}%`;
  };

  const formatRatio = (value: any) => {
    // If it's a string (already formatted as days), return it as is
    if (typeof value === 'string') {
      return value;
    }
    // Otherwise format it as a decimal
    return Number(value).toFixed(2);
  };

  const handleSort = (columnId: string) => {
    if (sortColumn === columnId) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(columnId);
      setSortDirection("asc");
    }
  };
  
  const handleToggleSortByTotals = (value: boolean) => {
    setSortByEntityTotals(value);
    if (onSortByTotalsChange) {
      onSortByTotalsChange(value);
    }
  };

  const renderCellValue = (row: any, column: Column) => {
    const value = row[column.accessorKey];
    
    if (column.isTag && value) {
      const isLoan = value.toString().toLowerCase() === 'loan';
      return (
        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
          isLoan ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
        }`}>
          {value}
        </span>
      );
    }
    
    if (column.isCurrency && value) {
      return formatCurrency(value);
    }
    
    if (column.isPercentage && value) {
      return formatPercentage(value);
    }
    
    if (column.accessorKey.includes('Ratio') && value !== undefined) {
      return formatRatio(value);
    }
    
    // Special handling for Last Property Purchase column
    if (column.id === "lastPropertyPurchase") {
      return (
        <div className="max-w-xs truncate">
          <span className="font-medium">{row.lastPropertyNumber}</span> {row.lastPropertyAddress}, {row.lastPropertyCity}
        </div>
      );
    }
    
    return value;
  };

  // Calculate pagination details
  const start = (page - 1) * pageSize + 1;
  const end = Math.min(start + pageSize - 1, count);
  
  const getPageNumbers = () => {
    const pageNumbers = [];
    let startPage = Math.max(1, page - 2);
    let endPage = Math.min(totalPages, page + 2);
    
    // Ensure we always show 5 page numbers if available
    if (endPage - startPage < 4 && totalPages > 4) {
      if (startPage === 1) {
        endPage = Math.min(startPage + 4, totalPages);
      } else if (endPage === totalPages) {
        startPage = Math.max(endPage - 4, 1);
      }
    }
    
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }
    
    return pageNumbers;
  };

  return (
    <div>
      {/* Results Header */}
      <div className="mb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <h2 className="text-lg font-semibold text-primary-dark mb-2 sm:mb-0">
          Results ({count} {title.toLowerCase()} found)
        </h2>
        <div className="flex items-center space-x-2">
          {onViewChange && (
            <div className="flex bg-muted rounded-lg p-1 mr-2">
              <button
                className={`px-4 py-[6px] rounded-md text-sm ${
                  activeView === "results" 
                    ? "bg-white text-primary shadow" 
                    : "text-muted-foreground hover:text-primary"
                }`}
                onClick={() => {
                  setActiveView("results");
                  onViewChange("results");
                }}
              >
                Results
              </button>
              <button
                className={`px-4 py-[6px] rounded-md text-sm ${
                  activeView === "communication"
                    ? "bg-white text-primary shadow" 
                    : "text-muted-foreground hover:text-primary"
                }`}
                onClick={() => {
                  setActiveView("communication");
                  onViewChange("communication");
                }}
              >
                Communication
              </button>
            </div>
          )}
          
          <Button variant="outline" size="sm" className="h-9">
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9">
                <BarChart2 className="h-4 w-4 mr-1" />
                Totals
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleToggleShowTotals("both")}>
                Both Totals {showTotalsOption === "both" && <span className="ml-2">✓</span>}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleToggleShowTotals("results")}>
                Results Totals Only {showTotalsOption === "results" && <span className="ml-2">✓</span>}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleToggleShowTotals("entity")}>
                Entity Totals Only {showTotalsOption === "entity" && <span className="ml-2">✓</span>}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <div className="flex items-center px-2 py-2">
                <Switch
                  id="sort-by-totals"
                  checked={sortByEntityTotals}
                  onCheckedChange={handleToggleSortByTotals}
                />
                <Label htmlFor="sort-by-totals" className="ml-2 text-sm cursor-pointer">
                  Sort by Entity Totals
                </Label>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9">
                <SlidersHorizontal className="h-4 w-4 mr-1" />
                Sort By
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {columns
                .filter(col => col.sortable)
                .map(column => (
                  <DropdownMenuItem 
                    key={column.id}
                    onClick={() => handleSort(column.id)}
                  >
                    {column.header} {sortColumn === column.id && (
                      sortDirection === "asc" ? <ArrowUp className="h-4 w-4 ml-2" /> : <ArrowDown className="h-4 w-4 ml-2" />
                    )}
                  </DropdownMenuItem>
                ))
              }
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      {/* Results Table */}
      <div className="overflow-x-auto bg-white rounded-lg shadow">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-primary-light bg-opacity-50">
            <tr>
              {columns.map(column => (
                <th
                  key={column.id}
                  scope="col"
                  className="px-4 py-3 text-left text-xs font-semibold text-text-primary tracking-wider cursor-pointer relative group"
                  onClick={() => column.sortable && handleSort(column.id)}
                >
                  <div className="flex items-center">
                    {column.tooltip ? (
                      <TooltipProvider>
                        <Tooltip delayDuration={300}>
                          <TooltipTrigger asChild onClick={(e) => {
                            if (column.sortable) {
                              e.stopPropagation();
                              handleSort(column.id);
                            }
                          }}>
                            <span className="cursor-help underline decoration-dotted decoration-gray-400">{column.header}</span>
                          </TooltipTrigger>
                          <TooltipContent className="z-[99999] max-w-xs">
                            <div className="font-medium text-xs mb-1 text-blue-300">{column.header}</div>
                            <div className="text-xs">{column.tooltip}</div>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    ) : (
                      column.header
                    )}
                    {column.sortable && sortColumn === column.id && (
                      <span className="ml-1">
                        {sortDirection === "asc" ? "↑" : "↓"}
                      </span>
                    )}
                  </div>
                </th>
              ))}

            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {data.map((row, i) => (
              <tr key={i} className="hover:bg-gray-50">
                {columns.map(column => (
                  <td key={column.id} className="px-4 py-3 whitespace-nowrap text-sm text-text-secondary">
                    {column.id === columns[0].id ? (
                      <span className="font-medium text-text-primary">{renderCellValue(row, column)}</span>
                    ) : (
                      renderCellValue(row, column)
                    )}
                  </td>
                ))}
              </tr>
            ))}
            
            {/* Totals rows */}
            {resultTotals && (showTotalsOption === "both" || showTotalsOption === "results") && (
              <tr className="bg-blue-50">
                {columns.map((column) => {
                  // Skip rendering totals for columns that shouldn't be totaled (like location, name, etc.)
                  const skipTotals = ['location', 'entityName', 'agentName', 'officeName', 'lenderName', 'financingType', 'lastPropertyPurchase', 'lastInvestorProperty'].includes(column.id);
                  
                  return (
                    <td 
                      key={column.id} 
                      className="px-4 py-3 whitespace-nowrap text-sm font-semibold border-t-2 border-blue-200"
                    >
                      {column.id === columns[0].id ? (
                        <span className="font-bold text-blue-700">Results Total</span>
                      ) : skipTotals ? (
                        ""
                      ) : (
                        renderCellValue({ ...resultTotals, [column.accessorKey]: resultTotals[column.accessorKey] }, column)
                      )}
                    </td>
                  );
                })}
              </tr>
            )}
            
            {entityTotals && (showTotalsOption === "both" || showTotalsOption === "entity") && (
              <tr className="bg-green-50">
                {columns.map((column) => {
                  // Skip rendering totals for columns that shouldn't be totaled
                  const skipTotals = ['location', 'entityName', 'agentName', 'officeName', 'lenderName', 'financingType', 'lastPropertyPurchase', 'lastInvestorProperty'].includes(column.id);
                  
                  return (
                    <td 
                      key={column.id} 
                      className="px-4 py-3 whitespace-nowrap text-sm font-semibold border-t-2 border-green-200"
                    >
                      {column.id === columns[0].id ? (
                        <span className="font-bold text-green-700">Entity Total</span>
                      ) : skipTotals ? (
                        ""
                      ) : (
                        renderCellValue({ ...entityTotals, [column.accessorKey]: entityTotals[column.accessorKey] }, column)
                      )}
                    </td>
                  );
                })}
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {/* Pagination */}
      <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6 rounded-b-lg shadow">
        <div className="flex-1 flex justify-between sm:hidden">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange(page - 1)}
            disabled={page === 1}
          >
            Previous
          </Button>
          <Button
            variant="outline" 
            size="sm"
            onClick={() => onPageChange(page + 1)}
            disabled={page === totalPages}
          >
            Next
          </Button>
        </div>
        <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
          <div className="flex items-center">
            <p className="text-sm text-text-secondary mr-4">
              Showing <span className="font-medium">{start}</span> to <span className="font-medium">{end}</span> of <span className="font-medium">{count}</span> results
            </p>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-text-secondary">Show:</span>
              <select
                value={localPageSize}
                onChange={(e) => handlePageSizeChange(Number(e.target.value))}
                className="text-sm border border-gray-300 rounded p-1 focus:ring-primary focus:border-primary"
              >
                <option value={10}>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
              </select>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    onClick={() => onPageChange(page - 1)}
                    className={page === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                  />
                </PaginationItem>
                
                {getPageNumbers().map(pageNum => (
                  <PaginationItem key={pageNum}>
                    <PaginationLink
                      onClick={() => onPageChange(pageNum)}
                      isActive={page === pageNum}
                    >
                      {pageNum}
                    </PaginationLink>
                  </PaginationItem>
                ))}
                
                <PaginationItem>
                  <PaginationNext 
                    onClick={() => onPageChange(page + 1)}
                    className={page === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        </div>
      </div>
    </div>
  );
}
