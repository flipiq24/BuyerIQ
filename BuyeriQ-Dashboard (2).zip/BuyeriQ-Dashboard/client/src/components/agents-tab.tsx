import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import SearchFilters from "@/components/search-filters-new";
import ResultsTable from "@/components/results-table-new";
import AgentCommunication from "@/components/agent-communication";
import { AgentResult, FilterParams } from "@/types";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function AgentsTab() {
  const [filters, setFilters] = useState<FilterParams>({
    county: "",
    city: "",
    zipcode: "", // Changed from zipCode to zipcode for consistency
    address: "",
    radius: 10,
    name: "",
    minUnits: "",
    maxUnits: "",
    doubleEnd: false,
  });

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [activeView, setActiveView] = useState<"results" | "communication">("results");

  const { data, isLoading, isError } = useQuery({
    queryKey: ["/api/agents", filters, page, pageSize],
    enabled: !!filters.county || !!filters.city || !!filters.zipcode || !!filters.address || !!filters.name,
  });

  const agentColumns = [
    { 
      id: "agentName", 
      header: "Agent Name", 
      accessorKey: "agentName", 
      sortable: true,
      tooltip: "Name of the real estate agent"
    },
    { 
      id: "lastPurchaseDate", 
      header: "Last Purchase", 
      accessorKey: "lastPurchaseDate", 
      sortable: true,
      tooltip: "Date of most recent property purchase"
    },
    { 
      id: "totalTransactionsWithInvestors", 
      header: "Total Trans.", 
      accessorKey: "totalTransactionsWithInvestors", 
      sortable: true,
      tooltip: "Count of all buy & sell transactions this agent completed with any investor"
    },
    { 
      id: "avgTransactionPrice", 
      header: "Avg. Purchase", 
      accessorKey: "avgTransactionPrice", 
      sortable: true, 
      isCurrency: true,
      tooltip: "Average price of all investor transactions this agent has facilitated"
    },
    { 
      id: "avgResalePrice", 
      header: "Avg. Resale", 
      accessorKey: "avgResalePrice", 
      sortable: true, 
      isCurrency: true,
      tooltip: "Average price properties were resold for"
    },
    { 
      id: "purchaseToFairValueRatio", 
      header: "P/FV Ratio", 
      accessorKey: "purchaseToFairValueRatio", 
      sortable: true,
      tooltip: "Ratio of purchase price to fair market value"
    },
    { 
      id: "listToSoldRatio", 
      header: "List/Sold Ratio", 
      accessorKey: "listToSoldRatio", 
      sortable: true,
      tooltip: "Ratio of list price to sold price"
    },
    { 
      id: "purchaseToMarketRatio", 
      header: "P/M Ratio", 
      accessorKey: "purchaseToMarketRatio", 
      sortable: true,
      tooltip: "Ratio of purchase price to market price"
    },
    { 
      id: "purchaseToResaleRatio", 
      header: "Purchase/Resale", 
      accessorKey: "purchaseToResaleRatio", 
      sortable: true,
      tooltip: "Ratio of purchase price to resale price"
    },
    { 
      id: "financingType", 
      header: "Financing", 
      accessorKey: "financingType", 
      isTag: true,
      sortable: true,
      tooltip: "Preferred method of financing (cash, loan, etc)"
    },
    { 
      id: "agentRelationships", 
      header: "Agent Rel.", 
      accessorKey: "agentRelationships", 
      sortable: true,
      tooltip: "Number of unique agent relationships" 
    },
    { 
      id: "lastInvestorProperty", 
      header: "Last Property Purchase", 
      accessorKey: "lastInvestorProperty", 
      sortable: false,
      tooltip: "Most recent property this agent closed involving an investor"
    },
    // Additional agent-specific fields
    { 
      id: "listingsSoldToInvestors", 
      header: "Listings Sold to Investors", 
      accessorKey: "listingsSoldToInvestors", 
      sortable: true,
      tooltip: "Number of listed properties sold to investors"
    },
    { 
      id: "percentageDoubleEndTransactions", 
      header: "% Double-end Trans.", 
      accessorKey: "percentageDoubleEndTransactions", 
      sortable: true, 
      isPercentage: true,
      tooltip: "Percentage of transactions where agent represented both buyer and seller"
    },
    { 
      id: "mostRecentBuyerTransaction", 
      header: "Most Recent Buyer's Agent", 
      accessorKey: "mostRecentBuyerTransaction", 
      sortable: true,
      tooltip: "Latest buyer-side agent, or the buyer's agent with the most deals alongside this listing agent"
    },
    { 
      id: "officeRepresentingBuyers", 
      header: "Office Representing Buyers", 
      accessorKey: "officeRepresentingBuyers", 
      sortable: true,
      tooltip: "Number of investor deals where this agent's office represented the buyer"
    },
    { 
      id: "listingsResoldForInvestors", 
      header: "Listings Re-Sold for Investors", 
      accessorKey: "listingsResoldForInvestors", 
      sortable: true,
      tooltip: "Properties this agent re-listed and sold for investors after renovations"
    },
    { 
      id: "uniqueInvestorRelationships", 
      header: "Unique Investor Relationships", 
      accessorKey: "uniqueInvestorRelationships", 
      sortable: true,
      tooltip: "Total distinct investors this agent has closed at least one deal with"
    },
  ];

  const handleSearch = (newFilters: FilterParams) => {
    setFilters(newFilters);
    setPage(1);
  };

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };
  
  const handlePageSizeChange = (newPageSize: number) => {
    setPageSize(newPageSize);
    setPage(1); // Reset to first page when changing page size
  };

  const additionalFilters = (
    <>
      <div>
        <label htmlFor="agent_name" className="block text-sm font-medium text-text-secondary mb-1">Agent Name</label>
        <input 
          type="text" 
          id="agent_name" 
          name="name" 
          placeholder="Enter agent name" 
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          value={filters.name}
          onChange={(e) => setFilters({...filters, name: e.target.value})}
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-text-secondary mb-1">Total Units</label>
        <div className="flex space-x-2">
          <input 
            type="number" 
            id="min_units" 
            name="minUnits" 
            placeholder="Min" 
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            value={filters.minUnits}
            onChange={(e) => setFilters({...filters, minUnits: e.target.value})}
          />
          <span className="self-center">-</span>
          <input 
            type="number" 
            id="max_units" 
            name="maxUnits" 
            placeholder="Max" 
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            value={filters.maxUnits}
            onChange={(e) => setFilters({...filters, maxUnits: e.target.value})}
          />
        </div>
      </div>
      <div className="flex items-center space-x-2">
        <Switch 
          id="double_end" 
          checked={filters.doubleEnd} 
          onCheckedChange={(checked) => setFilters({...filters, doubleEnd: checked})}
        />
        <Label htmlFor="double_end">Double-end Transactions</Label>
      </div>
    </>
  );

  return (
    <>
      <SearchFilters
        onSearch={handleSearch}
        additionalFilters={additionalFilters}
        filters={filters}
        setFilters={setFilters}
      />
      
      {isLoading ? (
        <div className="space-y-3 mt-5">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-[400px] w-full" />
        </div>
      ) : isError ? (
        <Alert variant="destructive" className="mt-5">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Error loading agent data. Please try again later.
          </AlertDescription>
        </Alert>
      ) : (
        <>
          {/* Removed the standalone toggle section */}
          
          {activeView === "results" ? (
            <ResultsTable
              title="Agents"
              count={data?.total || 0}
              data={data?.results as AgentResult[] || []}
              columns={agentColumns}
              page={page}
              pageSize={pageSize}
              totalPages={data?.totalPages || 1}
              resultTotals={data?.resultTotals}
              entityTotals={data?.entityTotals}
              onPageChange={handlePageChange}
              onPageSizeChange={handlePageSizeChange}
              onViewChange={(view) => setActiveView(view)}
            />
          ) : (
            <AgentCommunication onViewChange={(view) => setActiveView(view)} />
          )}
        </>
      )}
    </>
  );
}
