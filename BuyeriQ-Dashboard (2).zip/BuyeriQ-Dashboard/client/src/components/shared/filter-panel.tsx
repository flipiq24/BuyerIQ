import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Search, Sliders, ChevronDown, ChevronUp } from "lucide-react";

export interface FilterValues {
  name?: string;
  address?: string;
  county?: string;
  city?: string;
  zipCode?: string;
  transactionType?: string;
  transactionMin?: number;
  transactionMax?: number;
  radius?: number;
  priceMin?: number;
  priceMax?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  page: number;
  pageSize: number;
}

interface FilterPanelProps {
  values: FilterValues;
  onChange: (values: FilterValues) => void;
  onSearch: () => void;
  counties: Array<{ label: string; value: string }>;
  cities: Array<{ label: string; value: string }>;
  zipCodes: Array<{ label: string; value: string }>;
}

export default function FilterPanel({
  values,
  onChange,
  onSearch,
  counties,
  cities,
  zipCodes,
}: FilterPanelProps) {
  const [expanded, setExpanded] = useState(false);

  const handleChange = (key: keyof FilterValues, value: any) => {
    onChange({ ...values, [key]: value });
    
    // When county changes, reset city and zipCode
    if (key === 'county') {
      onChange({ ...values, county: value, city: undefined, zipCode: undefined });
    }
    
    // When city changes, reset zipCode
    if (key === 'city') {
      onChange({ ...values, city: value, zipCode: undefined });
    }
  };

  const togglePanel = () => {
    setExpanded(!expanded);
  };

  return (
    <Card className="mb-6">
      <CardHeader className="py-3">
        <div className="flex justify-between items-center">
          <CardTitle className="text-md flex items-center">
            <Sliders className="mr-2 h-4 w-4" />
            Filters
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={togglePanel}
            className="h-8 w-8 p-0"
          >
            {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </Button>
        </div>
      </CardHeader>

      {expanded && (
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                placeholder="Search by name"
                value={values.name || ''}
                onChange={(e) => handleChange('name', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                placeholder="Search by address"
                value={values.address || ''}
                onChange={(e) => handleChange('address', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="county">County</Label>
              <Select
                value={values.county || ''}
                onValueChange={(value) => handleChange('county', value)}
              >
                <SelectTrigger id="county">
                  <SelectValue placeholder="Select county" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Counties</SelectItem>
                  {counties.map((county) => (
                    <SelectItem key={county.value} value={county.value}>
                      {county.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <Select 
                value={values.city || ''} 
                onValueChange={(value) => handleChange('city', value)}
                disabled={!values.county}
              >
                <SelectTrigger id="city">
                  <SelectValue placeholder="Select city" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Cities</SelectItem>
                  {cities.map((city) => (
                    <SelectItem key={city.value} value={city.value}>
                      {city.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="zipCode">Zip Code</Label>
              <Select 
                value={values.zipCode || ''} 
                onValueChange={(value) => handleChange('zipCode', value)}
                disabled={!values.city}
              >
                <SelectTrigger id="zipCode">
                  <SelectValue placeholder="Select zip code" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Zip Codes</SelectItem>
                  {zipCodes.map((zipCode) => (
                    <SelectItem key={zipCode.value} value={zipCode.value}>
                      {zipCode.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="transaction-type">Transaction Type</Label>
              <Select 
                value={values.transactionType || ''} 
                onValueChange={(value) => handleChange('transactionType', value)}
              >
                <SelectTrigger id="transaction-type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Types</SelectItem>
                  <SelectItem value="purchase">Purchase</SelectItem>
                  <SelectItem value="sale">Sale</SelectItem>
                  <SelectItem value="refinance">Refinance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="transaction-count">Transaction Count</Label>
              <div className="flex gap-2 items-center">
                <Input
                  id="transaction-min"
                  type="number"
                  placeholder="Min"
                  className="w-1/2"
                  value={values.transactionMin || ''}
                  onChange={(e) => handleChange('transactionMin', e.target.value ? Number(e.target.value) : undefined)}
                />
                <span>-</span>
                <Input
                  id="transaction-max"
                  type="number"
                  placeholder="Max"
                  className="w-1/2"
                  value={values.transactionMax || ''}
                  onChange={(e) => handleChange('transactionMax', e.target.value ? Number(e.target.value) : undefined)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="price-range">Price Range</Label>
              <div className="flex gap-2 items-center">
                <Input
                  id="price-min"
                  type="number"
                  placeholder="Min"
                  className="w-1/2"
                  value={values.priceMin || ''}
                  onChange={(e) => handleChange('priceMin', e.target.value ? Number(e.target.value) : undefined)}
                />
                <span>-</span>
                <Input
                  id="price-max"
                  type="number"
                  placeholder="Max"
                  className="w-1/2"
                  value={values.priceMax || ''}
                  onChange={(e) => handleChange('priceMax', e.target.value ? Number(e.target.value) : undefined)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between mb-1">
                <Label htmlFor="radius">Search Radius (miles)</Label>
                <span className="text-xs">{values.radius || 0}</span>
              </div>
              <Slider
                id="radius"
                defaultValue={[values.radius || 0]}
                max={100}
                step={5}
                onValueChange={(value) => handleChange('radius', value[0])}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sort-by">Sort By</Label>
              <Select 
                value={values.sortBy || ''} 
                onValueChange={(value) => handleChange('sortBy', value)}
              >
                <SelectTrigger id="sort-by">
                  <SelectValue placeholder="Sort results by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="transactions">Transaction Count</SelectItem>
                  <SelectItem value="price">Average Price</SelectItem>
                  <SelectItem value="recent">Most Recent</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="sort-order">Sort Order</Label>
              <Select 
                value={values.sortOrder || 'desc'} 
                onValueChange={(value) => handleChange('sortOrder', value as 'asc' | 'desc')}
              >
                <SelectTrigger id="sort-order">
                  <SelectValue placeholder="Sort order" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="asc">Ascending</SelectItem>
                  <SelectItem value="desc">Descending</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="mt-6 flex justify-end">
            <Button onClick={onSearch} className="gap-2">
              <Search className="h-4 w-4" />
              Apply Filters
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}