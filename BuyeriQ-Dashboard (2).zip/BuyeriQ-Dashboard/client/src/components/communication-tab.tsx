import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Contact, CommFilterParams } from "@shared/schema";
import { PaginatedResponse } from "@/types";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Search, PhoneCall, MessageSquare, Mail, Volume2, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Default filter params
const defaultFilterParams: CommFilterParams = {
  page: 1,
  pageSize: 10,
  sortOrder: "desc",
  sortBy: "updatedAt"
};

export default function CommunicationTab() {
  const [filters, setFilters] = useState<CommFilterParams>(defaultFilterParams);
  const [activeContact, setActiveContact] = useState<Contact | null>(null);
  const [activeDrawer, setActiveDrawer] = useState<"conversation" | "task" | null>(null);
  const { toast } = useToast();

  // Fetch contacts with empty default values since the actual API isn't implemented yet
  const { data, isLoading, isError } = useQuery<PaginatedResponse<Contact>>({
    queryKey: ["/api/contacts", filters],
    placeholderData: {
      results: [],
      total: 0,
      page: 1,
      pageSize: 10,
      totalPages: 0
    }
  });

  // Handle filter changes
  const handleFilterChange = (key: keyof CommFilterParams, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value, page: 1 }));
  };

  // Handle pagination
  const handlePageChange = (newPage: number) => {
    setFilters(prev => ({ ...prev, page: newPage }));
  };

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-2xl">Communication & Outreach</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-4">
            <div className="col-span-1 md:col-span-5">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search contacts by name or company..."
                  className="pl-8"
                  value={filters.searchTerm || ""}
                  onChange={(e) => handleFilterChange("searchTerm", e.target.value)}
                />
              </div>
            </div>
            <div className="col-span-1 md:col-span-2">
              <Select
                value={filters.type || "all"}
                onValueChange={(value) => handleFilterChange("type", value === "all" ? undefined : value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Contact Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="INVESTOR">Investors</SelectItem>
                  <SelectItem value="AGENT">Agents</SelectItem>
                  <SelectItem value="OFFICE">Offices</SelectItem>
                  <SelectItem value="LENDER">Lenders</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-1 md:col-span-2">
              <Select
                value={filters.county || "all"}
                onValueChange={(value) => handleFilterChange("county", value === "all" ? undefined : value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="County" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Counties</SelectItem>
                  {/* Counties would be fetched and mapped here */}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-1 md:col-span-3 flex gap-2">
              <Button variant="default" className="flex-grow" onClick={() => toast({ title: "Feature coming soon", description: "This feature is not yet implemented" })}>
                <Plus className="h-4 w-4 mr-2" />
                New Contact
              </Button>
              <Button variant="outline" className="flex-grow" onClick={() => toast({ title: "Feature coming soon", description: "This feature is not yet implemented" })}>
                Import CSV
              </Button>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row gap-6">
            {/* Contact List Section - Left Side */}
            <div className="flex-1">
              <div className="rounded-md border">
                <div className="px-4 py-3 flex items-center justify-between bg-muted/50">
                  <h3 className="font-semibold">Contacts</h3>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{data?.total || 0} Results</Badge>
                  </div>
                </div>
                
                {isLoading ? (
                  <div className="flex justify-center items-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : isError ? (
                  <div className="flex justify-center items-center py-12 text-muted-foreground">
                    Error loading contacts. Please try again.
                  </div>
                ) : data?.results.length === 0 ? (
                  <div className="flex flex-col justify-center items-center py-12 text-muted-foreground">
                    <p>No contacts found</p>
                    <p className="text-sm">Try adjusting your filters or create a new contact</p>
                  </div>
                ) : (
                  <div className="divide-y">
                    {data?.results.map((contact: Contact) => (
                      <div
                        key={contact.id}
                        className={`px-4 py-3 hover:bg-muted/50 cursor-pointer ${activeContact?.id === contact.id ? 'bg-muted/80' : ''}`}
                        onClick={() => setActiveContact(contact)}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">{contact.name}</h4>
                            <p className="text-sm text-muted-foreground">{contact.type}</p>
                          </div>
                          <div className="flex gap-2">
                            {contact.phone && (
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <PhoneCall className="h-4 w-4" />
                              </Button>
                            )}
                            {contact.email && (
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Mail className="h-4 w-4" />
                              </Button>
                            )}
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MessageSquare className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Pagination would go here */}
              </div>
            </div>
            
            {/* Right Side Drawer */}
            {activeContact && (
              <div className="flex-1 border rounded-md">
                <div className="p-4 bg-muted/50 flex items-center justify-between">
                  <h3 className="font-semibold">{activeContact.name}</h3>
                  <Badge variant={activeContact.optOut ? "destructive" : "outline"}>
                    {activeContact.optOut ? "Opted Out" : "Active"}
                  </Badge>
                </div>
                
                <div className="p-4">
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label className="text-xs text-muted-foreground">Phone</Label>
                      <p>{activeContact.phone || "Not provided"}</p>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Email</Label>
                      <p>{activeContact.email || "Not provided"}</p>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Type</Label>
                      <p>{activeContact.type}</p>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Last Updated</Label>
                      <p>{new Date(activeContact.updatedAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <Tabs defaultValue="conversations" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="conversations">Conversations</TabsTrigger>
                      <TabsTrigger value="tasks">Tasks</TabsTrigger>
                    </TabsList>
                    <TabsContent value="conversations" className="pt-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <p>No conversations yet</p>
                        </div>
                      </div>
                      <div className="mt-4 flex gap-2">
                        <Button size="sm" className="gap-1">
                          <PhoneCall className="h-4 w-4" />
                          Call
                        </Button>
                        <Button size="sm" className="gap-1">
                          <MessageSquare className="h-4 w-4" />
                          Text
                        </Button>
                        <Button size="sm" className="gap-1">
                          <Mail className="h-4 w-4" />
                          Email
                        </Button>
                        <Button size="sm" className="gap-1">
                          <Volume2 className="h-4 w-4" />
                          Voicemail
                        </Button>
                      </div>
                    </TabsContent>
                    <TabsContent value="tasks" className="pt-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <p>No tasks yet</p>
                        </div>
                      </div>
                      <div className="mt-4">
                        <Button size="sm" className="gap-1">
                          <Plus className="h-4 w-4" />
                          Create AI Task
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}