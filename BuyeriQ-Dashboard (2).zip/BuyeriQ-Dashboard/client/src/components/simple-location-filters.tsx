import { useState, useEffect } from "react";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface SimpleLocationFiltersProps {
  county: string;
  city: string;
  zipcode: string; // Changed from zipCode to zipcode to match backend
  onCountyChange: (value: string) => void;
  onCityChange: (value: string) => void;
  onZipCodeChange: (value: string) => void;
}

// Hardcoded data - will be directly used no matter what
const ALL_COUNTIES = [
  { id: 1, name: "Los Angeles", value: "los_angeles" },
  { id: 2, name: "Orange", value: "orange" },
  { id: 3, name: "San Diego", value: "san_diego" }
];

const ALL_CITIES = [
  // Los Angeles County
  { id: 1, name: "Los Angeles", value: "los_angeles", countyId: 1 },
  { id: 2, name: "Long Beach", value: "long_beach", countyId: 1 },
  { id: 3, name: "Pasadena", value: "pasadena", countyId: 1 },
  
  // Orange County
  { id: 4, name: "Anaheim", value: "anaheim", countyId: 2 },
  { id: 5, name: "Irvine", value: "irvine", countyId: 2 },
  { id: 6, name: "Santa Ana", value: "santa_ana", countyId: 2 },
  
  // San Diego County
  { id: 7, name: "San Diego", value: "san_diego", countyId: 3 },
  { id: 8, name: "Chula Vista", value: "chula_vista", countyId: 3 },
  { id: 9, name: "Oceanside", value: "oceanside", countyId: 3 }
];

const ALL_ZIPCODES = [
  // Los Angeles
  { id: 1, name: "90001", value: "90001", cityId: 1 },
  { id: 2, name: "90002", value: "90002", cityId: 1 },
  { id: 3, name: "90003", value: "90003", cityId: 1 },
  
  // Long Beach
  { id: 4, name: "90801", value: "90801", cityId: 2 },
  { id: 5, name: "90802", value: "90802", cityId: 2 },
  { id: 6, name: "90803", value: "90803", cityId: 2 },
  
  // Pasadena
  { id: 7, name: "91101", value: "91101", cityId: 3 },
  { id: 8, name: "91102", value: "91102", cityId: 3 },
  { id: 9, name: "91103", value: "91103", cityId: 3 },
  
  // Anaheim
  { id: 10, name: "92801", value: "92801", cityId: 4 },
  { id: 11, name: "92802", value: "92802", cityId: 4 },
  { id: 12, name: "92803", value: "92803", cityId: 4 },
  
  // Irvine
  { id: 13, name: "92602", value: "92602", cityId: 5 },
  { id: 14, name: "92603", value: "92603", cityId: 5 },
  { id: 15, name: "92604", value: "92604", cityId: 5 },
  
  // Santa Ana
  { id: 16, name: "92701", value: "92701", cityId: 6 },
  { id: 17, name: "92702", value: "92702", cityId: 6 },
  { id: 18, name: "92703", value: "92703", cityId: 6 },
  
  // San Diego
  { id: 19, name: "92101", value: "92101", cityId: 7 },
  { id: 20, name: "92102", value: "92102", cityId: 7 },
  { id: 21, name: "92103", value: "92103", cityId: 7 },
  
  // Chula Vista
  { id: 22, name: "91910", value: "91910", cityId: 8 },
  { id: 23, name: "91911", value: "91911", cityId: 8 },
  { id: 24, name: "91912", value: "91912", cityId: 8 },
  
  // Oceanside
  { id: 25, name: "92049", value: "92049", cityId: 9 },
  { id: 26, name: "92051", value: "92051", cityId: 9 },
  { id: 27, name: "92052", value: "92052", cityId: 9 }
];

export default function SimpleLocationFilters({
  county,
  city,
  zipcode, // Updated from zipCode to zipcode
  onCountyChange,
  onCityChange,
  onZipCodeChange
}: SimpleLocationFiltersProps) {
  // State to hold filtered options based on parent selections
  const [filteredCities, setFilteredCities] = useState(ALL_CITIES);
  const [filteredZipCodes, setFilteredZipCodes] = useState(ALL_ZIPCODES);

  // When county changes, filter cities
  useEffect(() => {
    if (!county) {
      setFilteredCities(ALL_CITIES);
    } else {
      const selectedCounty = ALL_COUNTIES.find(c => c.value === county);
      if (selectedCounty) {
        setFilteredCities(ALL_CITIES.filter(c => c.countyId === selectedCounty.id));
      }
    }
  }, [county]);

  // When city changes, filter zipcodes
  useEffect(() => {
    if (!city) {
      setFilteredZipCodes(ALL_ZIPCODES);
    } else {
      const selectedCity = ALL_CITIES.find(c => c.value === city);
      if (selectedCity) {
        setFilteredZipCodes(ALL_ZIPCODES.filter(z => z.cityId === selectedCity.id));
      }
    }
  }, [city]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="space-y-2">
        <Label htmlFor="county">County</Label>
        <Select
          value={county}
          onValueChange={onCountyChange}
        >
          <SelectTrigger id="county">
            <SelectValue placeholder="Select county" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all_counties">All Counties</SelectItem>
            {ALL_COUNTIES.map((countyOption) => (
              <SelectItem key={countyOption.id} value={countyOption.value}>
                {countyOption.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="city">City</Label>
        <Select
          value={city}
          onValueChange={onCityChange}
          disabled={filteredCities.length === 0}
        >
          <SelectTrigger id="city">
            <SelectValue placeholder="Select city" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all_cities">All Cities</SelectItem>
            {filteredCities.map((cityOption) => (
              <SelectItem key={cityOption.id} value={cityOption.value}>
                {cityOption.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="zipcode">ZIP Code</Label>
        <Select
          value={zipcode}
          onValueChange={onZipCodeChange}
          disabled={filteredZipCodes.length === 0}
        >
          <SelectTrigger id="zipcode">
            <SelectValue placeholder="Select ZIP code" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all_zip_codes">All ZIP Codes</SelectItem>
            {filteredZipCodes.map((zipOption) => (
              <SelectItem key={zipOption.id} value={zipOption.value}>
                {zipOption.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}