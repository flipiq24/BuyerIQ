import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { InvestorResult, FilterParams, PaginatedResponse } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function MinimalSearch() {
  const { toast } = useToast();
  const [county, setCounty] = useState("");
  const [city, setCity] = useState("");
  const [zipCode, setZipCode] = useState("");

  const handleCountyChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setCounty(e.target.value);
    setCity("");
    setZipCode("");
  };

  const handleCityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setCity(e.target.value);
    setZipCode("");
  };

  const handleZipCodeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setZipCode(e.target.value);
  };

  const filters: FilterParams = {
    county,
    city,
    zipCode,
    radius: 10,
    address: "",
    name: "",
    minUnits: "",
    maxUnits: "",
    filterByHometown: false
  };

  const { data, refetch } = useQuery<PaginatedResponse<InvestorResult>>({
    queryKey: ["/api/investors", filters, 1, 10],
    enabled: false,
  });

  const handleSearch = () => {
    refetch();
    toast({
      title: "Search executed",
      description: `Searching with county=${county}, city=${city}, zipCode=${zipCode}`,
    });
  };

  return (
    <div className="bg-white p-5 rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4">Simple Location Search</h2>
      
      <div className="grid gap-4 mb-4">
        <div>
          <label htmlFor="county" className="block text-sm font-medium mb-1">County</label>
          <select 
            id="county" 
            value={county} 
            onChange={handleCountyChange}
            className="w-full p-2 border rounded"
          >
            <option value="">Select County</option>
            <option value="los_angeles">Los Angeles</option>
            <option value="orange">Orange</option>
            <option value="san_diego">San Diego</option>
          </select>
        </div>

        <div>
          <label htmlFor="city" className="block text-sm font-medium mb-1">City</label>
          <select 
            id="city" 
            value={city} 
            onChange={handleCityChange}
            className="w-full p-2 border rounded"
            disabled={!county}
          >
            <option value="">Select City</option>
            {county === "los_angeles" && (
              <>
                <option value="los_angeles">Los Angeles</option>
                <option value="long_beach">Long Beach</option>
                <option value="pasadena">Pasadena</option>
              </>
            )}
            {county === "orange" && (
              <>
                <option value="anaheim">Anaheim</option>
                <option value="irvine">Irvine</option>
                <option value="santa_ana">Santa Ana</option>
              </>
            )}
            {county === "san_diego" && (
              <>
                <option value="san_diego">San Diego</option>
                <option value="chula_vista">Chula Vista</option>
                <option value="oceanside">Oceanside</option>
              </>
            )}
          </select>
        </div>

        <div>
          <label htmlFor="zipCode" className="block text-sm font-medium mb-1">ZIP Code</label>
          <select 
            id="zipCode" 
            value={zipCode} 
            onChange={handleZipCodeChange}
            className="w-full p-2 border rounded"
            disabled={!city}
          >
            <option value="">Select ZIP Code</option>
            {city === "los_angeles" && (
              <>
                <option value="90001">90001</option>
                <option value="90002">90002</option>
                <option value="90003">90003</option>
              </>
            )}
            {city === "long_beach" && (
              <>
                <option value="90801">90801</option>
                <option value="90802">90802</option>
                <option value="90803">90803</option>
              </>
            )}
            {city === "pasadena" && (
              <>
                <option value="91101">91101</option>
                <option value="91102">91102</option>
                <option value="91103">91103</option>
              </>
            )}
            {city === "anaheim" && (
              <>
                <option value="92801">92801</option>
                <option value="92802">92802</option>
                <option value="92803">92803</option>
              </>
            )}
            {city === "irvine" && (
              <>
                <option value="92602">92602</option>
                <option value="92603">92603</option>
                <option value="92604">92604</option>
              </>
            )}
            {city === "santa_ana" && (
              <>
                <option value="92701">92701</option>
                <option value="92702">92702</option>
                <option value="92703">92703</option>
              </>
            )}
            {city === "san_diego" && (
              <>
                <option value="92101">92101</option>
                <option value="92102">92102</option>
                <option value="92103">92103</option>
              </>
            )}
            {city === "chula_vista" && (
              <>
                <option value="91910">91910</option>
                <option value="91911">91911</option>
                <option value="91912">91912</option>
              </>
            )}
            {city === "oceanside" && (
              <>
                <option value="92049">92049</option>
                <option value="92051">92051</option>
                <option value="92052">92052</option>
              </>
            )}
          </select>
        </div>
      </div>

      <Button onClick={handleSearch} className="w-full bg-primary hover:bg-primary-dark">
        Search
      </Button>

      {data && (
        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-2">Search Results</h3>
          <p className="mb-2">Total results: {data.total}</p>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-2 text-left">Entity Name</th>
                  <th className="border p-2 text-left">Location</th>
                  <th className="border p-2 text-left">Last Purchase</th>
                </tr>
              </thead>
              <tbody>
                {data.results.map((investor: InvestorResult) => (
                  <tr key={investor.id} className="border-b">
                    <td className="border p-2">{investor.entityName}</td>
                    <td className="border p-2">{investor.location}</td>
                    <td className="border p-2">{investor.lastPurchaseDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}