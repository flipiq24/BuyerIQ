import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import DirectSearchFilters from "@/components/direct-search-filters";
import ResultsTable from "@/components/results-table-new";
import { FilterParams, PaginatedResponse } from "@/types";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

interface PropertyResult {
  id: number;
  streetNumber: string;
  streetName: string;
  city: string;
  state: string;
  zipCode: string;
  county: string;
  apn: string;
  bedrooms: number;
  bathrooms: number;
  squareFeet: number;
  lotSize: number;
  yearBuilt: number;
  lastSaleDate: string;
  lastSalePrice: number;
  estimatedValue: number;
}

export default function PropertiesTab() {
  const [filters, setFilters] = useState<FilterParams>({
    county: "",
    city: "",
    zipcode: "", // Changed from zipCode to zipcode for consistency
    address: "",
    radius: 10,
    name: "",
    minUnits: "",
    maxUnits: "",
    filterByHometown: false,
  });

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  
  const { data, isLoading, isError } = useQuery<PaginatedResponse<PropertyResult>>({
    queryKey: ["/api/properties", filters, page, pageSize],
    enabled: !!filters.county || !!filters.city || !!filters.zipcode || !!filters.address,
  });

  const propertyColumns = [
    { 
      id: "address", 
      header: "Address", 
      accessorFn: (row: PropertyResult) => `${row.streetNumber} ${row.streetName}`,
      sortable: true,
      tooltip: "Property address"
    },
    { 
      id: "city", 
      header: "City", 
      accessorKey: "city", 
      sortable: true,
      tooltip: "Property city"
    },
    { 
      id: "county", 
      header: "County", 
      accessorKey: "county", 
      sortable: true,
      tooltip: "Property county"
    },
    { 
      id: "zipCode", 
      header: "ZIP Code", 
      accessorKey: "zipCode", 
      sortable: true,
      tooltip: "Property ZIP code"
    },
    { 
      id: "apn", 
      header: "APN", 
      accessorKey: "apn", 
      sortable: true,
      tooltip: "Assessor's Parcel Number"
    },
    { 
      id: "bedrooms", 
      header: "Beds", 
      accessorKey: "bedrooms", 
      sortable: true,
      tooltip: "Number of bedrooms"
    },
    { 
      id: "bathrooms", 
      header: "Baths", 
      accessorKey: "bathrooms", 
      sortable: true,
      tooltip: "Number of bathrooms"
    },
    { 
      id: "squareFeet", 
      header: "Sq. Ft.", 
      accessorKey: "squareFeet", 
      sortable: true,
      tooltip: "Property square footage"
    },
    { 
      id: "yearBuilt", 
      header: "Year Built", 
      accessorKey: "yearBuilt", 
      sortable: true,
      tooltip: "Year the property was built"
    },
    { 
      id: "lastSaleDate", 
      header: "Last Sale Date", 
      accessorKey: "lastSaleDate", 
      sortable: true,
      tooltip: "Date of last property sale"
    },
    { 
      id: "lastSalePrice", 
      header: "Last Sale Price", 
      accessorKey: "lastSalePrice", 
      sortable: true,
      isCurrency: true,
      tooltip: "Price of last property sale"
    },
    { 
      id: "estimatedValue", 
      header: "Est. Value", 
      accessorKey: "estimatedValue", 
      sortable: true,
      isCurrency: true,
      tooltip: "Estimated current property value"
    },
  ];

  const handleSearch = (newFilters: FilterParams) => {
    setFilters(newFilters);
    setPage(1);
  };

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };
  
  const handlePageSizeChange = (newPageSize: number) => {
    setPageSize(newPageSize);
    setPage(1); // Reset to first page when changing page size
  };

  const additionalFilters = (
    <>
      <div>
        <label htmlFor="min_price" className="block text-sm font-medium text-text-secondary mb-1">Price Range</label>
        <div className="flex space-x-2">
          <input 
            type="number" 
            id="min_price" 
            name="minPrice" 
            placeholder="Min" 
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            value={filters.minPrice || ""}
            onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
          />
          <span className="self-center">-</span>
          <input 
            type="number" 
            id="max_price" 
            name="maxPrice" 
            placeholder="Max" 
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            value={filters.maxPrice || ""}
            onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label htmlFor="min_beds" className="block text-sm font-medium text-text-secondary mb-1">Min Beds</label>
          <select
            id="min_beds"
            name="minBeds"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            value={filters.minBeds || ""}
            onChange={(e) => setFilters({...filters, minBeds: e.target.value})}
          >
            <option value="">Any</option>
            <option value="1">1+</option>
            <option value="2">2+</option>
            <option value="3">3+</option>
            <option value="4">4+</option>
            <option value="5">5+</option>
          </select>
        </div>
        <div>
          <label htmlFor="min_baths" className="block text-sm font-medium text-text-secondary mb-1">Min Baths</label>
          <select
            id="min_baths"
            name="minBaths"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            value={filters.minBaths || ""}
            onChange={(e) => setFilters({...filters, minBaths: e.target.value})}
          >
            <option value="">Any</option>
            <option value="1">1+</option>
            <option value="1.5">1.5+</option>
            <option value="2">2+</option>
            <option value="2.5">2.5+</option>
            <option value="3">3+</option>
            <option value="4">4+</option>
          </select>
        </div>
      </div>
    </>
  );

  return (
    <>
      <DirectSearchFilters
        onSearch={handleSearch}
        additionalFilters={additionalFilters}
        filters={filters}
        setFilters={setFilters}
        onSaveSearch={() => {}}
      />
      
      {isLoading ? (
        <div className="space-y-3 mt-5">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-[400px] w-full" />
        </div>
      ) : isError ? (
        <Alert variant="destructive" className="mt-5">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Error loading property data. Please try again later.
          </AlertDescription>
        </Alert>
      ) : (
        <>
          <ResultsTable
            title="Properties"
            count={data?.total || 0}
            data={data?.results as PropertyResult[] || []}
            columns={propertyColumns}
            page={page}
            pageSize={pageSize}
            totalPages={data?.totalPages || 1}
            resultTotals={data?.resultTotals}
            entityTotals={data?.entityTotals}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            onViewChange={() => {}}
          />
        </>
      )}
    </>
  );
}