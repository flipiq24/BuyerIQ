import { TabType, SavedSearch } from "@/types";
import { Button } from "@/components/ui/button";
import { Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import SavedSearches from "@/components/saved-searches";

interface TabNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export default function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  const { toast } = useToast();
  const tabs: { id: TabType; label: string }[] = [
    { id: "investors", label: "Investors" },
    { id: "agents", label: "Agents" },
    { id: "offices", label: "Offices" },
    { id: "lenders", label: "Lenders" }
  ];

  const handleImportCSV = () => {
    toast({ 
      title: "Feature coming soon", 
      description: "CSV import functionality is not yet implemented" 
    });
  };

  const handleLoadSearch = (search: SavedSearch) => {
    // Change to the appropriate tab
    onTabChange(search.tabType);
    
    // You'd normally set filters here in a real app
    toast({ 
      title: "Search loaded", 
      description: `Loaded search: ${search.name}` 
    });
  };

  return (
    <div className="bg-white border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="flex overflow-x-auto">
            {tabs.map(tab => (
              <button
                key={tab.id}
                className={`px-4 py-3 font-medium transition-colors ${
                  activeTab === tab.id
                    ? "text-primary border-b-2 border-primary"
                    : "text-text-secondary hover:text-primary hover:border-b-2 hover:border-primary-light"
                }`}
                onClick={() => onTabChange(tab.id)}
                aria-current={activeTab === tab.id ? "page" : undefined}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <SavedSearches onLoadSearch={handleLoadSearch} />
            <Button variant="outline" size="sm" onClick={handleImportCSV}>
              <Upload className="h-4 w-4 mr-2" />
              Import CSV
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
