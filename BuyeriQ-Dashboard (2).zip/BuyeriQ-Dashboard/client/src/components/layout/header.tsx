import { Home, Bell } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Header() {
  return (
    <header className="bg-primary-dark text-white">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <Home className="h-8 w-8 text-accent" />
          <div className="flex flex-col">
            <h1 className="text-xl font-semibold">Buyer<span className="text-orange-500">IQ</span></h1>
            <span className="text-xs -mt-1 text-gray-300">Powered by: Flip<span className="text-orange-500">IQ</span></span>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Notifications Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="p-1 rounded-full hover:bg-primary focus:outline-none" aria-label="Notifications">
                <Bell className="h-6 w-6" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64">
              <div className="px-4 py-2 border-b border-gray-200 font-semibold">Notifications</div>
              <div className="p-2">
                <div className="p-2 hover:bg-surface rounded">
                  <p className="text-sm">New investor data available for Los Angeles County</p>
                  <p className="text-xs text-text-secondary">2 hours ago</p>
                </div>
                <div className="p-2 hover:bg-surface rounded">
                  <p className="text-sm">Database update completed</p>
                  <p className="text-xs text-text-secondary">Yesterday</p>
                </div>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>
          
          {/* User Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center space-x-2 focus:outline-none">
                <span className="hidden md:inline-block font-medium">John Smith</span>
                <div className="h-8 w-8 rounded-full bg-white text-primary flex items-center justify-center">
                  <span className="font-semibold">JS</span>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Profile</DropdownMenuItem>
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuItem>Support</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
