export default function Footer() {
  return (
    <footer className="bg-primary-dark text-white mt-auto">
      <div className="container mx-auto px-4 py-3">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-2 md:mb-0">
            <p className="text-sm">&copy; {new Date().getFullYear()} Buyer<span className="text-orange-500">IQ</span>. All rights reserved.</p>
          </div>
          <div className="flex space-x-4">
            <a href="#" className="text-sm hover:text-primary-light">Terms of Service</a>
            <a href="#" className="text-sm hover:text-primary-light">Privacy Policy</a>
            <a href="#" className="text-sm hover:text-primary-light">Contact Support</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
