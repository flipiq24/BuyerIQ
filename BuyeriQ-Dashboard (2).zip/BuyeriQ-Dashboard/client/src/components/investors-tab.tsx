import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import DirectSearchFilters from "@/components/direct-search-filters";
import ResultsTable from "@/components/results-table-new";
import InvestorCommunication from "@/components/investor-communication";
import { InvestorResult, FilterParams, TabType, SaveSearchParams, PaginatedResponse } from "@/types";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function InvestorsTab() {
  const { toast } = useToast();
  const [filters, setFilters] = useState<FilterParams>({
    county: "",
    city: "",
    zipcode: "", // Changed from zipCode to zipcode for consistency
    address: "",
    radius: 10,
    name: "",
    minUnits: "",
    maxUnits: "",
    filterByHometown: false,
  });

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [saveSearchOpen, setSaveSearchOpen] = useState(false);
  const [searchName, setSearchName] = useState("");
  const [activeView, setActiveView] = useState<"results" | "communication">("results");

  const { data, isLoading, isError } = useQuery<PaginatedResponse<InvestorResult>>({
    queryKey: ["/api/investors", filters, page, pageSize],
    enabled: !!filters.county || !!filters.city || !!filters.zipcode || !!filters.address || !!filters.name,
  });

  const investorColumns = [
    { 
      id: "entityName", 
      header: "Entity Name", 
      accessorKey: "entityName", 
      sortable: true,
      tooltip: "Legal name of the investing entity or individual"
    },
    { 
      id: "location", 
      header: "HomeTown/State", 
      accessorKey: "location", 
      sortable: true,
      tooltip: "Primary location of the investor"
    },
    { 
      id: "lastPurchaseDate", 
      header: "Last Purchase", 
      accessorKey: "lastPurchaseDate", 
      sortable: true,
      tooltip: "Date of most recent property acquisition"
    },
    { 
      id: "totalTransactions", 
      header: "Total Trans.", 
      accessorKey: "totalTransactions", 
      sortable: true,
      tooltip: "Total number of completed real estate transactions"
    },
    { 
      id: "avgPurchasePrice", 
      header: "Avg. Purchase", 
      accessorKey: "avgPurchasePrice", 
      sortable: true, 
      isCurrency: true,
      tooltip: "Average price paid for acquired properties"
    },
    { 
      id: "avgResalePrice", 
      header: "Avg. Resale", 
      accessorKey: "avgResalePrice", 
      sortable: true, 
      isCurrency: true,
      tooltip: "Average price when properties were resold"
    },
    { 
      id: "purchaseToFutureValueRatio", 
      header: "P/FV Ratio", 
      accessorKey: "purchaseToFutureValueRatio", 
      sortable: true,
      tooltip: "Purchase to Future Value Ratio - Indicates the potential for profit based on future market projections"
    },
    { 
      id: "listToSoldPriceRatio", 
      header: "List/Sold Ratio", 
      accessorKey: "listToSoldPriceRatio", 
      sortable: true,
      tooltip: "List to Sold Price Ratio - How close the selling price was to the listing price"
    },
    { 
      id: "purchaseToMarketRatio", 
      header: "P/M Ratio", 
      accessorKey: "purchaseToMarketRatio", 
      sortable: true,
      tooltip: "Purchase to Market Ratio - Time from acquisition purchase to listing in MLS"
    },
    { 
      id: "purchaseToResaleRatio", 
      header: "Purchase/Resale", 
      accessorKey: "purchaseToResaleRatio", 
      sortable: true,
      tooltip: "Time from acquisition purchase to re-sale"
    },
    { 
      id: "financingType", 
      header: "Financing", 
      accessorKey: "financingType", 
      sortable: false, 
      isTag: true,
      tooltip: "Primary method of financing used (Cash or Loan)"
    },
    { 
      id: "agentRelationships", 
      header: "Agent Rel.", 
      accessorKey: "agentRelationships", 
      sortable: true,
      tooltip: "Agent Relationships shown as 20/18/1/1 where: First number = Unique Agent Relationships, Second = Listing Agent Relationships, Third = Buyers Agents Relationships, Fourth = Re-list Agent Relationships"
    },
    { 
      id: "lastPropertyPurchase", 
      header: "Last Property Purchase", 
      accessorKey: "lastPropertyPurchase", 
      sortable: false,
      tooltip: "Details of the most recent property purchased by this investor"
    },
  ];

  const handleSearch = (newFilters: FilterParams) => {
    setFilters(newFilters);
    setPage(1);
  };

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };
  
  const handlePageSizeChange = (newPageSize: number) => {
    setPageSize(newPageSize);
    setPage(1); // Reset to first page when changing page size
  };
  
  const saveSearchMutation = useMutation({
    mutationFn: async (saveParams: SaveSearchParams) => {
      const response = await apiRequest("POST", "/api/saved-searches", saveParams);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Search saved successfully",
        description: "Your search criteria has been saved for future use.",
      });
      setSearchName("");
      setSaveSearchOpen(false);
      // Invalidate saved searches query if we had one
      queryClient.invalidateQueries({ queryKey: ["/api/saved-searches"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to save search",
        description: error.message || "An error occurred while saving your search.",
        variant: "destructive",
      });
    }
  });
  
  const handleSaveSearch = () => {
    setSaveSearchOpen(true);
  };
  
  const handleSaveSearchSubmit = () => {
    if (!searchName.trim()) {
      toast({
        title: "Search name required",
        description: "Please provide a name for this saved search.",
        variant: "destructive",
      });
      return;
    }
    
    saveSearchMutation.mutate({
      name: searchName,
      tabType: "investors",
      filters: filters
    });
  };

  const additionalFilters = (
    <>
      <div>
        <label htmlFor="investor_name" className="block text-sm font-medium text-text-secondary mb-1">Investor Name</label>
        <input 
          type="text" 
          id="investor_name" 
          name="name" 
          placeholder="Enter investor name" 
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          value={filters.name}
          onChange={(e) => setFilters({...filters, name: e.target.value})}
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-text-secondary mb-1">Total Units</label>
        <div className="flex space-x-2">
          <input 
            type="number" 
            id="min_units" 
            name="minUnits" 
            placeholder="Min" 
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            value={filters.minUnits}
            onChange={(e) => setFilters({...filters, minUnits: e.target.value})}
          />
          <span className="self-center">-</span>
          <input 
            type="number" 
            id="max_units" 
            name="maxUnits" 
            placeholder="Max" 
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            value={filters.maxUnits}
            onChange={(e) => setFilters({...filters, maxUnits: e.target.value})}
          />
        </div>
      </div>
      <div className="flex items-center">
        <label className="flex items-center cursor-pointer">
          <div className="relative inline-block w-10 mr-2 align-middle select-none">
            <input 
              type="checkbox" 
              id="toggle-hometown" 
              checked={filters.filterByHometown}
              onChange={(e) => setFilters({...filters, filterByHometown: e.target.checked})}
              className="sr-only"
            />
            <div className={`block h-6 rounded-full w-10 ${filters.filterByHometown ? 'bg-primary' : 'bg-gray-300'}`}></div>
            <div className={`absolute left-1 top-1 bg-white border-gray-300 w-4 h-4 rounded-full transition-transform duration-200 ease-in-out transform ${filters.filterByHometown ? 'translate-x-4' : 'translate-x-0'}`}></div>
          </div>
          <span className="text-sm font-medium text-text-secondary">
            Filter by Investor's {filters.filterByHometown ? 'Hometown' : 'Property Address'}
          </span>
        </label>
      </div>
    </>
  );

  return (
    <>
      <DirectSearchFilters
        onSearch={handleSearch}
        additionalFilters={additionalFilters}
        filters={filters}
        setFilters={setFilters}
        onSaveSearch={handleSaveSearch}
      />
      
      {isLoading ? (
        <div className="space-y-3 mt-5">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-[400px] w-full" />
        </div>
      ) : isError ? (
        <Alert variant="destructive" className="mt-5">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Error loading investor data. Please try again later.
          </AlertDescription>
        </Alert>
      ) : (
        <>
          {/* Removed the standalone toggle section */}
          
          {activeView === "results" ? (
            <ResultsTable
              title="Investors"
              count={data?.total || 0}
              data={data?.results as InvestorResult[] || []}
              columns={investorColumns}
              page={page}
              pageSize={pageSize}
              totalPages={data?.totalPages || 1}
              resultTotals={data?.resultTotals}
              entityTotals={data?.entityTotals}
              onPageChange={handlePageChange}
              onPageSizeChange={handlePageSizeChange}
              onViewChange={(view) => setActiveView(view)}
            />
          ) : (
            <InvestorCommunication onViewChange={(view) => setActiveView(view)} />
          )}
        </>
      )}
      
      {/* Save Search Dialog */}
      <Dialog open={saveSearchOpen} onOpenChange={setSaveSearchOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Search</DialogTitle>
            <DialogDescription>
              Give your search a name to save it for future use.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Label htmlFor="search-name" className="mb-2 block">
              Search Name
            </Label>
            <Input
              id="search-name"
              placeholder="Enter a name for your search"
              value={searchName}
              onChange={(e) => setSearchName(e.target.value)}
              className="w-full"
            />
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setSaveSearchOpen(false)}
              className="mr-2"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSaveSearchSubmit}
              disabled={saveSearchMutation.isPending}
            >
              {saveSearchMutation.isPending ? "Saving..." : "Save Search"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
