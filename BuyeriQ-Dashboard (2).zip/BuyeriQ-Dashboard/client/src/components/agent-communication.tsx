import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Contact, PaginatedResponse } from "@/types";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Download, 
  Plus, 
  PhoneCall, 
  Mail, 
  MessageSquare, 
  Volume2, 
  Loader2 
} from "lucide-react";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

interface AgentCommunicationProps {
  agentId?: number;
  onViewChange?: (view: "results" | "communication") => void;
}

export default function AgentCommunication({ agentId, onViewChange }: AgentCommunicationProps) {
  const { toast } = useToast();
  const [activeContact, setActiveContact] = useState<Contact | null>(null);
  const [selectedContacts, setSelectedContacts] = useState<Set<number>>(new Set());
  const [bulkActionOpen, setBulkActionOpen] = useState<boolean>(false);
  const [filters, setFilters] = useState({
    type: "AGENT",
    county: "",
    searchTerm: "",
    page: 1,
    pageSize: 10,
  });

  const handleFilterChange = (key: string, value: any) => {
    setFilters({
      ...filters,
      [key]: value,
    });
  };
  
  const toggleContactSelection = (contactId: number) => {
    const newSelection = new Set(selectedContacts);
    if (newSelection.has(contactId)) {
      newSelection.delete(contactId);
    } else {
      newSelection.add(contactId);
    }
    setSelectedContacts(newSelection);
  };
  
  const toggleAllContacts = (contacts: Contact[]) => {
    if (contacts.length === 0) return;
    
    // If all are selected, clear the selection, otherwise select all
    if (contacts.every(c => selectedContacts.has(c.id))) {
      setSelectedContacts(new Set());
    } else {
      const newSelection = new Set<number>();
      contacts.forEach(c => newSelection.add(c.id));
      setSelectedContacts(newSelection);
    }
  };
  
  const handleBulkAction = (action: 'call' | 'text' | 'email' | 'voicemail') => {
    toast({
      title: "Bulk Action Triggered",
      description: `${action.charAt(0).toUpperCase() + action.slice(1)} action initiated for ${selectedContacts.size} contacts`,
    });
    
    // Clear selection after action
    setSelectedContacts(new Set());
    setBulkActionOpen(false);
  };

  // Query to fetch contacts based on filters
  const { data, isLoading, isError } = useQuery<PaginatedResponse<Contact>>({
    queryKey: ["/api/contacts", filters],
    placeholderData: { results: [], total: 0, page: 1, pageSize: 10, totalPages: 1 },
  });

  return (
    <Card className="mt-6">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle>Communication & Outreach</CardTitle>
        <div className="flex items-center space-x-2">
          {onViewChange && (
            <div className="flex bg-muted rounded-lg p-1 mr-2">
              <button
                className="px-4 py-[6px] rounded-md text-sm text-muted-foreground hover:text-primary"
                onClick={() => onViewChange("results")}
              >
                Results
              </button>
              <button
                className="px-4 py-[6px] rounded-md text-sm bg-white text-primary shadow"
                onClick={() => onViewChange("communication")}
              >
                Communication
              </button>
            </div>
          )}
          <Button variant="outline" size="sm" className="h-9" onClick={() => toast({ title: "Feature coming soon", description: "Export functionality is not yet implemented" })}>
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
          <Button variant="outline" size="sm" className="h-9">
            <span className="mr-1">↑↓</span> Sort By
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="col-span-1 md:col-span-2">
            <Input 
              placeholder="Search contacts..." 
              value={filters.searchTerm} 
              onChange={(e) => handleFilterChange("searchTerm", e.target.value)}
              className="w-full"
            />
          </div>
          <div className="col-span-1 md:col-span-1 flex gap-2">
            <Button variant="default" className="w-full" onClick={() => toast({ title: "Feature coming soon", description: "This feature is not yet implemented" })}>
              <Plus className="h-4 w-4 mr-2" />
              New Contact
            </Button>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row gap-6">
          {/* Contact List Section - Left Side */}
          <div className="flex-1">
            <div className="rounded-md border">
              <div className="px-4 py-3 flex items-center justify-between bg-muted/50">
                <div className="flex items-center gap-2">
                  <Checkbox 
                    id="select-all" 
                    checked={data?.results?.length > 0 && data?.results?.every(c => selectedContacts.has(c.id))}
                    onCheckedChange={() => toggleAllContacts(data?.results || [])}
                  />
                  <Label htmlFor="select-all" className="font-semibold cursor-pointer">Agent Contacts</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{data?.total || 0} Results</Badge>
                  <Badge variant="outline">{selectedContacts.size} Selected</Badge>
                </div>
              </div>
              
              {/* Bulk Action Tools */}
              {selectedContacts.size > 0 && (
                <div className="flex items-center justify-between p-2 bg-primary/5 border-b">
                  <span className="text-sm ml-2">Bulk Actions:</span>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" onClick={() => handleBulkAction('call')}>
                      <PhoneCall className="h-4 w-4 mr-1" />
                      Call
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleBulkAction('text')}>
                      <MessageSquare className="h-4 w-4 mr-1" />
                      Text
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleBulkAction('email')}>
                      <Mail className="h-4 w-4 mr-1" />
                      Email
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleBulkAction('voicemail')}>
                      <Volume2 className="h-4 w-4 mr-1" />
                      VM
                    </Button>
                  </div>
                </div>
              )}
              
              {isLoading ? (
                <div className="flex justify-center items-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : isError ? (
                <div className="flex justify-center items-center py-12 text-muted-foreground">
                  Error loading contacts. Please try again.
                </div>
              ) : data?.results.length === 0 ? (
                <div className="flex flex-col justify-center items-center py-12 text-muted-foreground">
                  <p>No contacts found</p>
                  <p className="text-sm">Try adjusting your filters or create a new contact</p>
                </div>
              ) : (
                <div className="divide-y">
                  {data?.results.map((contact: Contact) => (
                    <div
                      key={contact.id}
                      className={`px-4 py-3 hover:bg-muted/50 ${activeContact?.id === contact.id ? 'bg-muted/80' : ''} ${selectedContacts.has(contact.id) ? 'bg-primary/5' : ''}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Checkbox 
                            checked={selectedContacts.has(contact.id)} 
                            onCheckedChange={() => toggleContactSelection(contact.id)} 
                            onClick={(e) => e.stopPropagation()}
                          />
                          <div 
                            className="cursor-pointer"
                            onClick={() => setActiveContact(contact)}
                          >
                            <h4 className="font-medium">{contact.name}</h4>
                            <p className="text-sm text-muted-foreground">{contact.type}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          {contact.phone && (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8"
                              onClick={(e) => {
                                e.stopPropagation();
                                toast({ title: "Call initiated", description: `Calling ${contact.name}` });
                              }}
                            >
                              <PhoneCall className="h-4 w-4" />
                            </Button>
                          )}
                          {contact.email && (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8"
                              onClick={(e) => {
                                e.stopPropagation();
                                toast({ title: "Email initiated", description: `Composing email to ${contact.name}` });
                              }}
                            >
                              <Mail className="h-4 w-4" />
                            </Button>
                          )}
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8"
                            onClick={(e) => {
                              e.stopPropagation();
                              toast({ title: "Text initiated", description: `Sending text to ${contact.name}` });
                            }}
                          >
                            <MessageSquare className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {/* Pagination control */}
              <div className="px-4 py-3 flex items-center justify-between border-t">
                <div className="text-sm text-muted-foreground">
                  Showing {data?.results.length ? 1 : 0} to {data?.results.length} of {data?.total || 0} results
                </div>
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-muted-foreground">Show:</span>
                    <select 
                      className="h-8 w-16 rounded-md border border-input bg-transparent px-2 text-sm"
                      value={filters.pageSize}
                      onChange={(e) => handleFilterChange("pageSize", parseInt(e.target.value))}
                    >
                      <option value="10">10</option>
                      <option value="25">25</option>
                      <option value="50">50</option>
                    </select>
                  </div>
                  <nav className="flex items-center space-x-1">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="h-8 w-8 p-0"
                      disabled={filters.page <= 1}
                      onClick={() => handleFilterChange("page", filters.page - 1)}
                    >
                      <span className="sr-only">Previous</span>
                      &lt;
                    </Button>
                    <Button 
                      variant={filters.page === 1 ? "default" : "outline"}
                      size="sm" 
                      className="h-8 w-8 p-0"
                    >
                      1
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="h-8 w-8 p-0"
                      disabled={filters.page >= (data?.totalPages || 1)}
                      onClick={() => handleFilterChange("page", filters.page + 1)}
                    >
                      <span className="sr-only">Next</span>
                      &gt;
                    </Button>
                  </nav>
                </div>
              </div>
            </div>
          </div>
          
          {/* Right Side Drawer */}
          {activeContact && (
            <div className="flex-1 border rounded-md">
              <div className="p-4 bg-muted/50 flex items-center justify-between">
                <h3 className="font-semibold">{activeContact.name}</h3>
                <Badge variant={activeContact.optOut ? "destructive" : "outline"}>
                  {activeContact.optOut ? "Opted Out" : "Active"}
                </Badge>
              </div>
              
              <div className="p-4">
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">Phone</Label>
                    <p>{activeContact.phone || "Not provided"}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Email</Label>
                    <p>{activeContact.email || "Not provided"}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Type</Label>
                    <p>{activeContact.type}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Last Updated</Label>
                    <p>{new Date(activeContact.updatedAt).toLocaleDateString()}</p>
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                <Tabs defaultValue="conversations" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="conversations">Conversations</TabsTrigger>
                    <TabsTrigger value="tasks">Tasks</TabsTrigger>
                  </TabsList>
                  <TabsContent value="conversations" className="pt-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <p>No conversations yet</p>
                      </div>
                    </div>
                    <div className="mt-4 flex gap-2">
                      <Button size="sm" className="gap-1">
                        <PhoneCall className="h-4 w-4" />
                        Call
                      </Button>
                      <Button size="sm" className="gap-1">
                        <MessageSquare className="h-4 w-4" />
                        Text
                      </Button>
                      <Button size="sm" className="gap-1">
                        <Mail className="h-4 w-4" />
                        Email
                      </Button>
                      <Button size="sm" className="gap-1">
                        <Volume2 className="h-4 w-4" />
                        Voicemail
                      </Button>
                    </div>
                  </TabsContent>
                  <TabsContent value="tasks" className="pt-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <p>No tasks yet</p>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Button size="sm" className="gap-1">
                        <Plus className="h-4 w-4" />
                        Create AI Task
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}