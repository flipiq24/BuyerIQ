import { useState, useEffect } from "react";

interface LocationOption {
  label: string;
  value: string;
}

interface LocationFiltersProps {
  county: string;
  city: string;
  zipCode: string;
  onCountyChange: (value: string) => void;
  onCityChange: (value: string) => void;
  onZipCodeChange: (value: string) => void;
}

export default function LocationFilters({
  county,
  city,
  zipCode,
  onCountyChange,
  onCityChange,
  onZipCodeChange
}: LocationFiltersProps) {
  const [counties, setCounties] = useState<LocationOption[]>([]);
  const [cities, setCities] = useState<LocationOption[]>([]);
  const [zipCodes, setZipCodes] = useState<LocationOption[]>([]);
  
  const [isLoadingCounties, setIsLoadingCounties] = useState(false);
  const [isLoadingCities, setIsLoadingCities] = useState(false);
  const [isLoadingZipCodes, setIsLoadingZipCodes] = useState(false);

  // Fetch counties
  useEffect(() => {
    async function fetchCounties() {
      setIsLoadingCounties(true);
      try {
        const response = await fetch("/api/locations/counties");
        if (response.ok) {
          const data = await response.json();
          console.log("Counties fetched:", data);
          setCounties(data);
        } else {
          console.error("Failed to fetch counties:", response.statusText);
        }
      } catch (error) {
        console.error("Error fetching counties:", error);
      } finally {
        setIsLoadingCounties(false);
      }
    }
    
    fetchCounties();
  }, []);

  // Fetch cities when county changes
  useEffect(() => {
    if (!county) {
      setCities([]);
      return;
    }
    
    async function fetchCities() {
      setIsLoadingCities(true);
      try {
        const response = await fetch(`/api/locations/cities?county=${encodeURIComponent(county)}`);
        if (response.ok) {
          const data = await response.json();
          console.log("Cities fetched:", data);
          setCities(data);
        } else {
          console.error("Failed to fetch cities:", response.statusText);
        }
      } catch (error) {
        console.error("Error fetching cities:", error);
      } finally {
        setIsLoadingCities(false);
      }
    }
    
    fetchCities();
  }, [county]);

  // Fetch zip codes when city changes
  useEffect(() => {
    if (!county || !city) {
      setZipCodes([]);
      return;
    }
    
    async function fetchZipCodes() {
      setIsLoadingZipCodes(true);
      try {
        const response = await fetch(`/api/locations/zipcodes?county=${encodeURIComponent(county)}&city=${encodeURIComponent(city)}`);
        if (response.ok) {
          const data = await response.json();
          console.log("Zip codes fetched:", data);
          setZipCodes(data);
        } else {
          console.error("Failed to fetch zip codes:", response.statusText);
        }
      } catch (error) {
        console.error("Error fetching zip codes:", error);
      } finally {
        setIsLoadingZipCodes(false);
      }
    }
    
    fetchZipCodes();
  }, [county, city]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div>
        <label htmlFor="county" className="block text-sm font-medium text-text-secondary mb-1">County</label>
        <select
          id="county"
          name="county"
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          value={county}
          onChange={(e) => onCountyChange(e.target.value)}
          disabled={isLoadingCounties}
        >
          <option value="">Select County</option>
          {counties.map((countyOption) => (
            <option key={countyOption.value} value={countyOption.value}>{countyOption.label}</option>
          ))}
        </select>
      </div>
      
      <div>
        <label htmlFor="city" className="block text-sm font-medium text-text-secondary mb-1">City</label>
        <select
          id="city"
          name="city"
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          value={city}
          onChange={(e) => onCityChange(e.target.value)}
          disabled={!county || isLoadingCities}
        >
          <option value="">Select City</option>
          {cities.map((cityOption) => (
            <option key={cityOption.value} value={cityOption.value}>{cityOption.label}</option>
          ))}
        </select>
      </div>
      
      <div>
        <label htmlFor="zipCode" className="block text-sm font-medium text-text-secondary mb-1">Zip Code</label>
        <select
          id="zipCode"
          name="zipCode"
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          value={zipCode}
          onChange={(e) => onZipCodeChange(e.target.value)}
          disabled={!city || isLoadingZipCodes}
        >
          <option value="">Select Zip</option>
          {zipCodes.map((zipOption) => (
            <option key={zipOption.value} value={zipOption.value}>{zipOption.label}</option>
          ))}
        </select>
      </div>
    </div>
  );
}