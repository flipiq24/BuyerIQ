export type TabType = "investors" | "agents" | "offices" | "lenders";

export interface Contact {
  id: number;
  name: string;
  type: "INVESTOR" | "AGENT" | "OFFICE" | "LENDER";
  email: string | null;
  phone: string | null;
  optOut: boolean | null;
  llcId: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  entityId: number;
}

export interface Conversation {
  id: number;
  body: string | null;
  metadata: string | null;
  direction: "OUTBOUND" | "INBOUND";
  status: "QUEUED" | "SENT" | "DELIVERED" | "FAILED" | "PENDING" | "COMPLETE";
  contactId: number;
  channel: "CALL" | "SMS" | "EMAIL" | "VM";
  timestamp: string;
  externalId: string | null;
}

export interface Task {
  id: number;
  result: string | null;
  status: "QUEUED" | "SENT" | "DELIVERED" | "FAILED" | "PENDING" | "COMPLETE";
  createdAt: string;
  contactId: number;
  templateKey: string;
  dueAt: string;
  threadId: string | null;
  completedAt: string | null;
}

export interface Template {
  id: number;
  name: string;
  body: string;
  key: string;
  variables: string | null;
  createdAt: string;
  updatedAt: string;
  channel: "CALL" | "SMS" | "EMAIL" | "VM";
  followUp: string | null;
}

export interface FilterParams {
  county: string;
  city: string;
  zipcode: string; // Changed from zipCode to zipcode to match backend expectations
  address: string;
  radius: number;
  name: string;
  minUnits: string;
  maxUnits: string;
  doubleEnd?: boolean;
  filterByHometown?: boolean;
  sortByEntityTotals?: boolean;
}

export interface Column {
  id: string;
  header: string;
  accessorKey: string;
  sortable: boolean;
  isCurrency?: boolean;
  isPercentage?: boolean;
  isTag?: boolean;
  tooltip?: string;
}

export interface LocationOption {
  label: string;
  value: string;
}

export interface InvestorResult {
  id: number;
  entityName: string;
  location: string;
  lastPurchaseDate: string;
  totalTransactions: number;
  avgPurchasePrice: number;
  avgResalePrice: number;
  purchaseToFutureValueRatio: string; // Display as percentage (e.g., "85%")
  listToSoldPriceRatio: string; // Display as percentage (e.g., "92%")
  purchaseToMarketRatio: string; // Display as whole days (e.g., "45")
  purchaseToResaleRatio: string; // Display as whole days (e.g., "120")
  financingType: "CASH" | "LOAN" | "MIXED";
  agentRelationships: string;
  lastPropertyNumber: string;
  lastPropertyAddress: string;
  lastPropertyCity: string;
}

export interface AgentResult {
  id: number;
  agentName: string;
  avgTransactionPrice: number;
  totalTransactionsWithInvestors: number;
  listingsSoldToInvestors: number;
  percentageDoubleEndTransactions: string; // Display as percentage under 100% (e.g., "26%")
  mostRecentBuyerTransaction: string; // Display as agent's name
  officeRepresentingBuyers: number; // Display as whole number
  listingsResoldForInvestors: number;
  uniqueInvestorRelationships: number;
  lastInvestorProperty: string;
}

export interface OfficeResult {
  id: number;
  officeName: string;
  avgTransactionPrice: number;
  totalTransactionsWithInvestors: number;
  listingsSoldToInvestors: number;
  buyerRepresentationTransactions: number;
  listingsResoldForInvestors: number;
  uniqueInvestorRelationships: number;
}

export interface LenderResult {
  id: number;
  lenderName: string;
  avgLoanAmount: number;
  avgLoanToPurchasePriceRatio: string; // Display as percentage (e.g., "72%")
  totalTransactionsToInvestors: number;
  uniqueInvestorRelationships: number;
  avgLoansPerRelationship: number;
}

export interface PaginatedResponse<T> {
  results: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  resultTotals?: any;  // Totals based on filtered results
  entityTotals?: any;  // Totals based on all entity data
}

export interface SavedSearch {
  id: number;
  name: string;
  tabType: TabType;
  filters: FilterParams;
  createdAt: string;
  userId: number;
}

export interface SaveSearchParams {
  name: string;
  tabType: TabType;
  filters: FilterParams;
}
