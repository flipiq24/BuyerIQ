// Dashboard metrics data

export interface MetricCard {
  id: string;
  title: string;
  value: string | number;
  change: number;
  trend: 'up' | 'down' | 'neutral';
  description: string;
}

export interface ChartData {
  name: string;
  value: number;
}

export interface TimeSeriesData {
  date: string;
  value: number;
}

// Sample metrics data
export const investorMetrics: MetricCard[] = [
  {
    id: 'avg_purchase_price',
    title: 'Avg. Purchase Price',
    value: '$925,000',
    change: 4.2,
    trend: 'up',
    description: 'Average purchase price across all investor transactions'
  },
  {
    id: 'transaction_volume',
    title: 'Transaction Volume',
    value: 187,
    change: 12.5,
    trend: 'up',
    description: 'Total number of investor purchases in the last 90 days'
  },
  {
    id: 'avg_time_to_resale',
    title: 'Avg. Time to Resale',
    value: '108 days',
    change: -3.8,
    trend: 'down',
    description: 'Average time between purchase and resale'
  },
  {
    id: 'profit_margin',
    title: 'Avg. Profit Margin',
    value: '17.8%',
    change: 1.2,
    trend: 'up',
    description: 'Average profit margin on resold properties'
  }
];

export const agentMetrics: MetricCard[] = [
  {
    id: 'investor_relationships',
    title: 'Investor Relationships',
    value: 265,
    change: 8.4,
    trend: 'up',
    description: 'Number of active agent-investor relationships'
  },
  {
    id: 'double_ended_deals',
    title: 'Double-Ended Deals',
    value: '24.6%',
    change: 2.1,
    trend: 'up',
    description: 'Percentage of transactions that are double-ended'
  },
  {
    id: 'avg_commission',
    title: 'Avg. Commission',
    value: '$26,750',
    change: 5.2,
    trend: 'up',
    description: 'Average commission on investor transactions'
  },
  {
    id: 'new_agents',
    title: 'New Agents',
    value: 42,
    change: -1.8,
    trend: 'down',
    description: 'New agents working with investors in the last 90 days'
  }
];

// Sample chart data for investor categories
export const investorTypeData: ChartData[] = [
  { name: 'Fix & Flip', value: 42 },
  { name: 'Buy & Hold', value: 28 },
  { name: 'New Construction', value: 15 },
  { name: 'Wholesale', value: 10 },
  { name: 'Other', value: 5 }
];

// Sample chart data for financing types
export const financingTypeData: ChartData[] = [
  { name: 'Cash', value: 35 },
  { name: 'Conventional', value: 25 },
  { name: 'Hard Money', value: 20 },
  { name: 'Private', value: 15 },
  { name: 'Other', value: 5 }
];

// Sample time series data for transaction volume
export const transactionTrend: TimeSeriesData[] = [
  { date: 'Jan', value: 65 },
  { date: 'Feb', value: 59 },
  { date: 'Mar', value: 80 },
  { date: 'Apr', value: 81 },
  { date: 'May', value: 95 },
  { date: 'Jun', value: 88 },
  { date: 'Jul', value: 102 },
  { date: 'Aug', value: 110 },
  { date: 'Sep', value: 125 },
  { date: 'Oct', value: 118 },
  { date: 'Nov', value: 135 },
  { date: 'Dec', value: 162 }
];

// Sample time series data for average purchase price
export const priceTrend: TimeSeriesData[] = [
  { date: 'Jan', value: 840000 },
  { date: 'Feb', value: 850000 },
  { date: 'Mar', value: 860000 },
  { date: 'Apr', value: 865000 },
  { date: 'May', value: 870000 },
  { date: 'Jun', value: 880000 },
  { date: 'Jul', value: 885000 },
  { date: 'Aug', value: 890000 },
  { date: 'Sep', value: 900000 },
  { date: 'Oct', value: 910000 },
  { date: 'Nov', value: 915000 },
  { date: 'Dec', value: 925000 }
];

// Sample time series data for profit margins
export const marginTrend: TimeSeriesData[] = [
  { date: 'Jan', value: 15.2 },
  { date: 'Feb', value: 15.5 },
  { date: 'Mar', value: 15.8 },
  { date: 'Apr', value: 16.0 },
  { date: 'May', value: 16.3 },
  { date: 'Jun', value: 16.5 },
  { date: 'Jul', value: 16.7 },
  { date: 'Aug', value: 16.9 },
  { date: 'Sep', value: 17.2 },
  { date: 'Oct', value: 17.4 },
  { date: 'Nov', value: 17.6 },
  { date: 'Dec', value: 17.8 }
];

// Top investors by transaction volume
export interface TopInvestor {
  id: number;
  name: string;
  transactions: number;
  avgPrice: string;
  totalValue: string;
}

export const topInvestors: TopInvestor[] = [
  { id: 1, name: 'Elite Property Holdings, LLC', transactions: 28, avgPrice: '$925,000', totalValue: '$25.9M' },
  { id: 2, name: 'Golden Gate Investments', transactions: 22, avgPrice: '$1,200,000', totalValue: '$26.4M' },
  { id: 3, name: 'Blue Ridge Capital', transactions: 19, avgPrice: '$760,000', totalValue: '$14.4M' },
  { id: 4, name: 'Coastal Redevelopment Group', transactions: 17, avgPrice: '$850,000', totalValue: '$14.5M' },
  { id: 5, name: 'Pacific Northwest Holdings', transactions: 15, avgPrice: '$980,000', totalValue: '$14.7M' },
];

// Top agents by investor transactions
export interface TopAgent {
  id: number;
  name: string;
  transactions: number;
  doubleEnded: string;
  commissions: string;
}

export const topAgents: TopAgent[] = [
  { id: 1, name: 'James Smith', transactions: 18, doubleEnded: '26%', commissions: '$483K' },
  { id: 2, name: 'Jennifer Johnson', transactions: 22, doubleEnded: '32%', commissions: '$589K' },
  { id: 3, name: 'Robert Williams', transactions: 14, doubleEnded: '21%', commissions: '$378K' },
  { id: 4, name: 'Elizabeth Davis', transactions: 26, doubleEnded: '35%', commissions: '$780K' },
  { id: 5, name: 'Thomas Brown', transactions: 11, doubleEnded: '18%', commissions: '$247K' },
];