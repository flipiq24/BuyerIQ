import { 
  Contact,
  InvestorResult,
  AgentResult,
  OfficeResult,
  LenderResult,
  Conversation,
  Task
} from "@/types";

// Sample Investors
export const sampleInvestors: InvestorResult[] = [
  {
    id: 1,
    entityName: "Elite Properties",
    location: "Los Angeles, 90001",
    lastPurchaseDate: "2025-03-15",
    totalTransactions: 12,
    avgPurchasePrice: 750000,
    avgResalePrice: 925000,
    purchaseToFutureValueRatio: "85%", // Display as percentage
    listToSoldPriceRatio: "92%", // Display as percentage
    purchaseToMarketRatio: "45", // Display as whole days
    purchaseToResaleRatio: "120", // Display as whole days
    financingType: "CASH",
    agentRelationships: "5",
    lastPropertyNumber: "1234",
    lastPropertyAddress: "1234 Oak St",
    lastPropertyCity: "Los Angeles"
  },
  {
    id: 2,
    entityName: "Prime Investments",
    location: "San Francisco, 94105",
    lastPurchaseDate: "2025-04-02",
    totalTransactions: 23,
    avgPurchasePrice: 1250000,
    avgResalePrice: 1600000,
    purchaseToFutureValueRatio: "88%", // Display as percentage
    listToSoldPriceRatio: "95%", // Display as percentage
    purchaseToMarketRatio: "30", // Display as whole days
    purchaseToResaleRatio: "90", // Display as whole days
    financingType: "LOAN",
    agentRelationships: "8",
    lastPropertyNumber: "3456",
    lastPropertyAddress: "3456 Pine Ave",
    lastPropertyCity: "San Francisco"
  },
  {
    id: 3,
    entityName: "Blue Chip Holdings",
    location: "San Diego, 92101",
    lastPurchaseDate: "2025-03-22",
    totalTransactions: 9,
    avgPurchasePrice: 675000,
    avgResalePrice: 850000,
    purchaseToFutureValueRatio: "90%", // Display as percentage
    listToSoldPriceRatio: "93%", // Display as percentage
    purchaseToMarketRatio: "60", // Display as whole days
    purchaseToResaleRatio: "150", // Display as whole days
    financingType: "CASH",
    agentRelationships: "3",
    lastPropertyNumber: "7890",
    lastPropertyAddress: "7890 Beach Blvd",
    lastPropertyCity: "San Diego"
  },
  {
    id: 4,
    entityName: "Golden Estates",
    location: "Orange County, 92663",
    lastPurchaseDate: "2025-04-08",
    totalTransactions: 17,
    avgPurchasePrice: 825000,
    avgResalePrice: 1050000,
    purchaseToFutureValueRatio: "82%", // Display as percentage
    listToSoldPriceRatio: "90%", // Display as percentage
    purchaseToMarketRatio: "75", // Display as whole days
    purchaseToResaleRatio: "180", // Display as whole days
    financingType: "LOAN",
    agentRelationships: "6",
    lastPropertyNumber: "5678",
    lastPropertyAddress: "5678 Harbor Dr",
    lastPropertyCity: "Newport Beach" 
  },
  {
    id: 5,
    entityName: "Superior Realty",
    location: "Sacramento, 95814",
    lastPurchaseDate: "2025-03-30",
    totalTransactions: 14,
    avgPurchasePrice: 520000,
    avgResalePrice: 640000,
    purchaseToFutureValueRatio: "87%", // Display as percentage
    listToSoldPriceRatio: "94%", // Display as percentage
    purchaseToMarketRatio: "40", // Display as whole days
    purchaseToResaleRatio: "100", // Display as whole days
    financingType: "CASH",
    agentRelationships: "4",
    lastPropertyNumber: "2468",
    lastPropertyAddress: "2468 Capitol Ave",
    lastPropertyCity: "Sacramento"
  }
];

// Sample Agents
export const sampleAgents: AgentResult[] = [
  {
    id: 1,
    agentName: "James Smith",
    avgTransactionPrice: 780000,
    totalTransactionsWithInvestors: 18,
    listingsSoldToInvestors: 12,
    percentageDoubleEndTransactions: 26,
    mostRecentBuyerTransaction: "2025-04-05",
    officeRepresentingBuyers: "Keller Williams",
    listingsResoldForInvestors: 7,
    uniqueInvestorRelationships: 9,
    lastInvestorProperty: "123 Main St, Los Angeles"
  },
  {
    id: 2,
    agentName: "Jennifer Johnson",
    avgTransactionPrice: 950000,
    totalTransactionsWithInvestors: 22,
    listingsSoldToInvestors: 15,
    percentageDoubleEndTransactions: 32,
    mostRecentBuyerTransaction: "2025-04-10",
    officeRepresentingBuyers: "Compass",
    listingsResoldForInvestors: 11,
    uniqueInvestorRelationships: 13,
    lastInvestorProperty: "456 Ocean Ave, San Francisco"
  },
  {
    id: 3,
    agentName: "Robert Williams",
    avgTransactionPrice: 670000,
    totalTransactionsWithInvestors: 14,
    listingsSoldToInvestors: 9,
    percentageDoubleEndTransactions: 21,
    mostRecentBuyerTransaction: "2025-03-28",
    officeRepresentingBuyers: "Century 21",
    listingsResoldForInvestors: 5,
    uniqueInvestorRelationships: 7,
    lastInvestorProperty: "789 Mountain View, San Jose"
  },
  {
    id: 4,
    agentName: "Elizabeth Davis",
    avgTransactionPrice: 1200000,
    totalTransactionsWithInvestors: 26,
    listingsSoldToInvestors: 19,
    percentageDoubleEndTransactions: 35,
    mostRecentBuyerTransaction: "2025-04-12",
    officeRepresentingBuyers: "Sotheby's",
    listingsResoldForInvestors: 14,
    uniqueInvestorRelationships: 17,
    lastInvestorProperty: "101 Palisades Dr, Malibu"
  },
  {
    id: 5,
    agentName: "Thomas Brown",
    avgTransactionPrice: 580000,
    totalTransactionsWithInvestors: 11,
    listingsSoldToInvestors: 7,
    percentageDoubleEndTransactions: 18,
    mostRecentBuyerTransaction: "2025-04-01",
    officeRepresentingBuyers: "RE/MAX",
    listingsResoldForInvestors: 4,
    uniqueInvestorRelationships: 5,
    lastInvestorProperty: "202 Valley Rd, Fresno"
  }
];

// Sample Offices
export const sampleOffices: OfficeResult[] = [
  {
    id: 1,
    officeName: "Keller Williams Beverly Hills",
    avgTransactionPrice: 1350000,
    totalTransactionsWithInvestors: 45,
    listingsSoldToInvestors: 32,
    buyerRepresentationTransactions: 24,
    listingsResoldForInvestors: 18,
    uniqueInvestorRelationships: 28
  },
  {
    id: 2,
    officeName: "Compass San Francisco",
    avgTransactionPrice: 1680000,
    totalTransactionsWithInvestors: 58,
    listingsSoldToInvestors: 40,
    buyerRepresentationTransactions: 35,
    listingsResoldForInvestors: 26,
    uniqueInvestorRelationships: 33
  },
  {
    id: 3,
    officeName: "Century 21 Los Angeles",
    avgTransactionPrice: 890000,
    totalTransactionsWithInvestors: 36,
    listingsSoldToInvestors: 24,
    buyerRepresentationTransactions: 19,
    listingsResoldForInvestors: 15,
    uniqueInvestorRelationships: 22
  },
  {
    id: 4,
    officeName: "Sotheby's Orange County",
    avgTransactionPrice: 2100000,
    totalTransactionsWithInvestors: 65,
    listingsSoldToInvestors: 47,
    buyerRepresentationTransactions: 38,
    listingsResoldForInvestors: 30,
    uniqueInvestorRelationships: 42
  },
  {
    id: 5,
    officeName: "RE/MAX San Diego",
    avgTransactionPrice: 760000,
    totalTransactionsWithInvestors: 29,
    listingsSoldToInvestors: 18,
    buyerRepresentationTransactions: 15,
    listingsResoldForInvestors: 12,
    uniqueInvestorRelationships: 17
  }
];

// Sample Lenders
export const sampleLenders: LenderResult[] = [
  {
    id: 1,
    lenderName: "Pacific Investment Bank",
    avgLoanAmount: 850000,
    avgLoanToPurchasePriceRatio: 0.72,
    totalTransactionsToInvestors: 32,
    uniqueInvestorRelationships: 19,
    avgLoansPerRelationship: 1.7
  },
  {
    id: 2,
    lenderName: "Golden State Funding",
    avgLoanAmount: 1200000,
    avgLoanToPurchasePriceRatio: 0.68,
    totalTransactionsToInvestors: 45,
    uniqueInvestorRelationships: 27,
    avgLoansPerRelationship: 1.9
  },
  {
    id: 3,
    lenderName: "Coastal Capital Group",
    avgLoanAmount: 680000,
    avgLoanToPurchasePriceRatio: 0.75,
    totalTransactionsToInvestors: 26,
    uniqueInvestorRelationships: 15,
    avgLoansPerRelationship: 1.5
  },
  {
    id: 4,
    lenderName: "Bay Area Investment Loans",
    avgLoanAmount: 1450000,
    avgLoanToPurchasePriceRatio: 0.65,
    totalTransactionsToInvestors: 54,
    uniqueInvestorRelationships: 31,
    avgLoansPerRelationship: 2.1
  },
  {
    id: 5,
    lenderName: "Valley Mortgage Partners",
    avgLoanAmount: 520000,
    avgLoanToPurchasePriceRatio: 0.78,
    totalTransactionsToInvestors: 19,
    uniqueInvestorRelationships: 12,
    avgLoansPerRelationship: 1.4
  }
];

// Sample Contacts
export const sampleContacts: Contact[] = [
  {
    id: 1,
    type: "INVESTOR",
    name: "Elite Properties",
    email: "info@eliteproperties.com",
    phone: "+19491234567",
    llcId: "LLC123456",
    createdAt: "2025-01-15T10:30:00Z",
    updatedAt: "2025-04-10T14:20:00Z",
    entityId: 1,
    optOut: false,
    notes: "Interested in multi-family properties in LA County"
  },
  {
    id: 2,
    type: "AGENT",
    name: "James Smith",
    email: "james.smith@example.com",
    phone: "+17149876543",
    llcId: null,
    createdAt: "2025-02-03T09:45:00Z",
    updatedAt: "2025-04-08T11:15:00Z",
    entityId: 1,
    optOut: false,
    notes: "Best to reach via email"
  },
  {
    id: 3,
    type: "INVESTOR",
    name: "Prime Investments",
    email: "contact@primeinvestments.com",
    phone: "+16501234567",
    llcId: "LLC789012",
    createdAt: "2025-01-22T13:20:00Z",
    updatedAt: "2025-04-05T16:45:00Z",
    entityId: 2,
    optOut: false,
    notes: "Looking for commercial properties"
  },
  {
    id: 4,
    type: "AGENT",
    name: "Jennifer Johnson",
    email: "jennifer.johnson@example.com",
    phone: "+18589876543",
    llcId: null,
    createdAt: "2025-02-10T11:30:00Z",
    updatedAt: "2025-04-12T10:00:00Z",
    entityId: 2,
    optOut: false,
    notes: "Prefers phone calls"
  },
  {
    id: 5,
    type: "OFFICE",
    name: "Keller Williams Beverly Hills",
    email: "bh@kellerwilliams.com",
    phone: "+13101234567",
    llcId: null,
    createdAt: "2025-01-05T08:15:00Z",
    updatedAt: "2025-04-01T09:30:00Z",
    entityId: 1,
    optOut: false,
    notes: "Office contact for investor referrals"
  },
  {
    id: 6,
    type: "LENDER",
    name: "Pacific Investment Bank",
    email: "lending@pacificinvestment.com",
    phone: "+12139876543",
    llcId: null,
    createdAt: "2025-01-18T14:45:00Z",
    updatedAt: "2025-03-28T15:20:00Z",
    entityId: 1,
    optOut: false,
    notes: "Specializes in investment property financing"
  },
  {
    id: 7,
    type: "INVESTOR",
    name: "Blue Chip Holdings",
    email: "info@bluechipholdings.com",
    phone: "+16191234567",
    llcId: "LLC345678",
    createdAt: "2025-01-25T16:10:00Z",
    updatedAt: "2025-04-07T13:40:00Z",
    entityId: 3,
    optOut: false,
    notes: "Prefers morning calls"
  },
  {
    id: 8,
    type: "AGENT",
    name: "Robert Williams",
    email: "robert.williams@example.com",
    phone: "+14159876543",
    llcId: null,
    createdAt: "2025-02-15T10:20:00Z",
    updatedAt: "2025-04-09T11:50:00Z",
    entityId: 3,
    optOut: true,
    notes: "Currently on vacation until April 25th"
  },
  {
    id: 9,
    type: "INVESTOR",
    name: "Golden Estates",
    email: "contact@goldenestates.com",
    phone: "+17141234567",
    llcId: "LLC901234",
    createdAt: "2025-01-30T11:25:00Z",
    updatedAt: "2025-04-06T14:15:00Z",
    entityId: 4,
    optOut: false,
    notes: "Interested in luxury properties"
  },
  {
    id: 10,
    type: "LENDER",
    name: "Golden State Funding",
    email: "loans@goldenstatefunding.com",
    phone: "+14159876543",
    llcId: null,
    createdAt: "2025-01-20T13:00:00Z",
    updatedAt: "2025-03-30T09:45:00Z",
    entityId: 2,
    optOut: false,
    notes: "Offers competitive rates for investment properties"
  },
  {
    id: 11,
    type: "INVESTOR",
    name: "Superior Realty",
    email: "info@superiorrealty.com",
    phone: "+19161234567",
    llcId: "LLC567890",
    createdAt: "2025-02-05T09:40:00Z",
    updatedAt: "2025-04-11T15:30:00Z",
    entityId: 5,
    optOut: false,
    notes: "Looking for properties in Sacramento area"
  },
  {
    id: 12,
    type: "AGENT",
    name: "Elizabeth Davis",
    email: "elizabeth.davis@example.com",
    phone: "+13109876543",
    llcId: null,
    createdAt: "2025-02-20T14:10:00Z",
    updatedAt: "2025-04-13T16:20:00Z",
    entityId: 4,
    optOut: false,
    notes: "Good connection to luxury market investors"
  }
];

// Sample Conversations
export const sampleConversations: Conversation[] = [
  {
    id: 1,
    body: "Hi Elite Properties, following up on our conversation about investment properties in your area. We have some new listings that match your criteria.",
    metadata: null,
    direction: "OUTBOUND",
    status: "DELIVERED",
    contactId: 1,
    channel: "SMS",
    timestamp: "2025-04-05T10:15:00Z",
    externalId: null
  },
  {
    id: 2,
    body: "Yes, we're interested. Can you send details on the properties?",
    metadata: null,
    direction: "INBOUND",
    status: "DELIVERED",
    contactId: 1,
    channel: "SMS",
    timestamp: "2025-04-05T10:30:00Z",
    externalId: null
  },
  {
    id: 3,
    body: "Dear James,\n\nI hope this email finds you well. I wanted to reach out regarding potential partnership opportunities. I have several investors looking for properties in your area, and I believe there might be mutual benefit in collaborating.\n\nBest regards,\nFlipIQ Team",
    metadata: null,
    direction: "OUTBOUND",
    status: "SENT",
    contactId: 2,
    channel: "EMAIL",
    timestamp: "2025-04-06T14:45:00Z",
    externalId: null
  },
  {
    id: 4,
    body: "Call to discuss investment opportunities in Beverly Hills area",
    metadata: null,
    direction: "OUTBOUND",
    status: "COMPLETE",
    contactId: 3,
    channel: "CALL",
    timestamp: "2025-04-07T11:20:00Z",
    externalId: null
  },
  {
    id: 5,
    body: "Left voicemail for Jennifer about new investment opportunities in San Francisco",
    metadata: null,
    direction: "OUTBOUND",
    status: "DELIVERED",
    contactId: 4,
    channel: "VM",
    timestamp: "2025-04-08T15:10:00Z",
    externalId: null
  },
  {
    id: 6,
    body: "Jennifer called to inquire about the properties mentioned in the voicemail",
    metadata: null,
    direction: "INBOUND",
    status: "COMPLETE",
    contactId: 4,
    channel: "CALL",
    timestamp: "2025-04-09T09:30:00Z",
    externalId: null
  },
  {
    id: 7,
    body: "Hello Keller Williams Team,\n\nI'm reaching out to discuss potential partnership opportunities between our companies. We have several investors looking for properties in your area, and I believe there might be mutual benefit in collaborating.\n\nLooking forward to your response.\n\nBest regards,\nFlipIQ Team",
    metadata: null,
    direction: "OUTBOUND",
    status: "DELIVERED",
    contactId: 5,
    channel: "EMAIL",
    timestamp: "2025-04-10T13:45:00Z",
    externalId: null
  },
  {
    id: 8,
    body: "Just wanted to touch base about our lending program for investors. We're offering special rates this month.",
    metadata: null,
    direction: "OUTBOUND",
    status: "DELIVERED",
    contactId: 6,
    channel: "SMS",
    timestamp: "2025-04-11T10:20:00Z",
    externalId: null
  },
  {
    id: 9,
    body: "Dear Blue Chip Holdings,\n\nBased on your recent purchases in San Diego, I've prepared a comprehensive investment analysis for similar properties in the area.\n\nHighlights:\n- Average ROI: 12%\n- Projected appreciation: 8%\n- Comparable cap rates: 5.5%\n\nWould you like to schedule a 15-minute call to discuss these opportunities?\n\nBest regards,\nFlipIQ Team",
    metadata: null,
    direction: "OUTBOUND",
    status: "SENT",
    contactId: 7,
    channel: "EMAIL",
    timestamp: "2025-04-12T14:30:00Z",
    externalId: null
  },
  {
    id: 10,
    body: "Thanks for the information. I'd be interested in scheduling a call next Tuesday at 10am.",
    metadata: null,
    direction: "INBOUND",
    status: "DELIVERED",
    contactId: 7,
    channel: "EMAIL",
    timestamp: "2025-04-12T16:15:00Z",
    externalId: null
  }
];

// Sample Tasks
export const sampleTasks: Task[] = [
  {
    id: 1,
    result: null,
    status: "PENDING",
    createdAt: "2025-04-01T09:00:00Z",
    contactId: 1,
    templateKey: "initial_outreach",
    dueAt: "2025-04-20T10:00:00Z",
    threadId: null,
    completedAt: null
  },
  {
    id: 2,
    result: "Agent expressed interest in partnership. Follow-up meeting scheduled for April 25.",
    status: "COMPLETE",
    createdAt: "2025-04-02T11:30:00Z",
    contactId: 2,
    templateKey: "property_alert",
    dueAt: "2025-04-15T14:00:00Z",
    threadId: "thread_abc123",
    completedAt: "2025-04-14T16:30:00Z"
  },
  {
    id: 3,
    result: null,
    status: "QUEUED",
    createdAt: "2025-04-03T14:45:00Z",
    contactId: 3,
    templateKey: "market_update",
    dueAt: "2025-04-18T11:00:00Z",
    threadId: null,
    completedAt: null
  },
  {
    id: 4,
    result: null,
    status: "PENDING",
    createdAt: "2025-04-05T10:15:00Z",
    contactId: 4,
    templateKey: "initial_outreach",
    dueAt: "2025-04-22T15:30:00Z",
    threadId: null,
    completedAt: null
  },
  {
    id: 5,
    result: "Office requested additional information about partnership program. Sent detailed PDF.",
    status: "COMPLETE",
    createdAt: "2025-04-06T13:20:00Z",
    contactId: 5,
    templateKey: "property_alert",
    dueAt: "2025-04-16T13:00:00Z",
    threadId: "thread_def456",
    completedAt: "2025-04-15T11:45:00Z"
  },
  {
    id: 6,
    result: null,
    status: "QUEUED",
    createdAt: "2025-04-07T15:40:00Z",
    contactId: 6,
    templateKey: "market_update",
    dueAt: "2025-04-19T10:30:00Z",
    threadId: null,
    completedAt: null
  },
  {
    id: 7,
    result: null,
    status: "PENDING",
    createdAt: "2025-04-08T09:50:00Z",
    contactId: 7,
    templateKey: "initial_outreach",
    dueAt: "2025-04-21T14:15:00Z",
    threadId: null,
    completedAt: null
  },
  {
    id: 8,
    result: "Call scheduled for April 24th at 11:00 AM to discuss luxury property opportunities.",
    status: "COMPLETE",
    createdAt: "2025-04-09T12:10:00Z",
    contactId: 9,
    templateKey: "property_alert",
    dueAt: "2025-04-17T16:00:00Z",
    threadId: "thread_ghi789",
    completedAt: "2025-04-16T15:20:00Z"
  },
  {
    id: 9,
    result: null,
    status: "QUEUED",
    createdAt: "2025-04-10T14:30:00Z",
    contactId: 10,
    templateKey: "market_update",
    dueAt: "2025-04-23T11:45:00Z",
    threadId: null,
    completedAt: null
  },
  {
    id: 10,
    result: null,
    status: "PENDING",
    createdAt: "2025-04-11T10:05:00Z",
    contactId: 11,
    templateKey: "initial_outreach",
    dueAt: "2025-04-24T13:30:00Z",
    threadId: null,
    completedAt: null
  }
];