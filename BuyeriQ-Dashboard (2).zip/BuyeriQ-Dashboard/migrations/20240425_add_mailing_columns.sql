ALTER TABLE properties
  ADD COLUMN mailing_address        text,
  ADD COLUMN mailing_unit_type      text,
  ADD COLUMN mailing_unit_number    text,
  ADD COLUMN mailing_city           text,
  ADD COLUMN mailing_state          text,
  ADD COLUMN mailing_zip            text,
  ADD COLUMN mailing_zip4           text;

-- ❶ Location filters
CREATE INDEX idx_properties_location
  ON properties (county, city, zipcode);

-- ❷ Full-text search on owner / investor / lender names
CREATE INDEX idx_properties_name_search
  ON properties
  USING gin (to_tsvector('simple',
        coalesce(current_owner,'') || ' ' ||
        coalesce(investor,'')      || ' ' ||
        coalesce(lender,'')));

-- ❸ Geospatial radius search (if you store lat/long)
CREATE INDEX idx_properties_latlng
  ON properties
  USING gist (POINT(latitude, longitude));