import { db } from "../server/db";
import {
  counties, cities, zipCodes, 
  investors, agents, offices, lenders,
  contacts, conversations, aiTasks, templates, corporations
} from "../shared/schema";

// Clear existing data
async function clearData() {
  await db.delete(aiTasks);
  await db.delete(conversations);
  await db.delete(contacts);
  await db.delete(templates);
  await db.delete(corporations);
  await db.delete(investors);
  await db.delete(agents);
  await db.delete(offices);
  await db.delete(lenders);
  await db.delete(zipCodes);
  await db.delete(cities);
  await db.delete(counties);
}

// Create sample locations
async function createLocations() {
  // Counties
  const [losAngeles] = await db.insert(counties).values({
    name: "Los Angeles",
    value: "los_angeles"
  }).returning();
  
  const [orange] = await db.insert(counties).values({
    name: "Orange",
    value: "orange"
  }).returning();
  
  const [sanDiego] = await db.insert(counties).values({
    name: "San Diego",
    value: "san_diego" 
  }).returning();

  // Cities for Los Angeles County
  const [losAngelesCity] = await db.insert(cities).values({
    name: "Los Angeles",
    value: "los_angeles",
    countyId: losAngeles.id
  }).returning();
  
  const [longBeach] = await db.insert(cities).values({
    name: "Long Beach",
    value: "long_beach",
    countyId: losAngeles.id
  }).returning();
  
  const [pasadena] = await db.insert(cities).values({
    name: "Pasadena",
    value: "pasadena",
    countyId: losAngeles.id
  }).returning();

  // Cities for Orange County
  const [anaheim] = await db.insert(cities).values({
    name: "Anaheim",
    value: "anaheim",
    countyId: orange.id
  }).returning();
  
  const [irvine] = await db.insert(cities).values({
    name: "Irvine",
    value: "irvine",
    countyId: orange.id
  }).returning();
  
  const [newportBeach] = await db.insert(cities).values({
    name: "Newport Beach",
    value: "newport_beach",
    countyId: orange.id
  }).returning();

  // Cities for San Diego County
  const [sanDiegoCity] = await db.insert(cities).values({
    name: "San Diego",
    value: "san_diego",
    countyId: sanDiego.id
  }).returning();
  
  const [oceanside] = await db.insert(cities).values({
    name: "Oceanside",
    value: "oceanside",
    countyId: sanDiego.id
  }).returning();
  
  const [carlsbad] = await db.insert(cities).values({
    name: "Carlsbad",
    value: "carlsbad",
    countyId: sanDiego.id
  }).returning();

  // Zip Codes for Los Angeles
  await db.insert(zipCodes).values([
    { code: "90001", value: "90001", cityId: losAngelesCity.id },
    { code: "90012", value: "90012", cityId: losAngelesCity.id },
    { code: "90024", value: "90024", cityId: losAngelesCity.id },
    { code: "90210", value: "90210", cityId: losAngelesCity.id },
  ]);

  // Zip Codes for Long Beach
  await db.insert(zipCodes).values([
    { code: "90802", value: "90802", cityId: longBeach.id },
    { code: "90803", value: "90803", cityId: longBeach.id },
  ]);

  // Zip Codes for Pasadena
  await db.insert(zipCodes).values([
    { code: "91101", value: "91101", cityId: pasadena.id },
    { code: "91103", value: "91103", cityId: pasadena.id },
  ]);

  // Zip Codes for Anaheim
  await db.insert(zipCodes).values([
    { code: "92801", value: "92801", cityId: anaheim.id },
    { code: "92802", value: "92802", cityId: anaheim.id },
  ]);

  // Zip Codes for Irvine
  await db.insert(zipCodes).values([
    { code: "92602", value: "92602", cityId: irvine.id },
    { code: "92603", value: "92603", cityId: irvine.id },
  ]);

  // Zip Codes for Newport Beach
  await db.insert(zipCodes).values([
    { code: "92657", value: "92657", cityId: newportBeach.id },
    { code: "92660", value: "92660", cityId: newportBeach.id },
  ]);

  // Zip Codes for San Diego
  await db.insert(zipCodes).values([
    { code: "92101", value: "92101", cityId: sanDiegoCity.id },
    { code: "92109", value: "92109", cityId: sanDiegoCity.id },
  ]);

  // Zip Codes for Oceanside
  await db.insert(zipCodes).values([
    { code: "92054", value: "92054", cityId: oceanside.id },
    { code: "92056", value: "92056", cityId: oceanside.id },
  ]);

  // Zip Codes for Carlsbad
  await db.insert(zipCodes).values([
    { code: "92008", value: "92008", cityId: carlsbad.id },
    { code: "92009", value: "92009", cityId: carlsbad.id },
  ]);

  return {
    counties: { losAngeles, orange, sanDiego },
    cities: { 
      losAngelesCity, longBeach, pasadena, 
      anaheim, irvine, newportBeach,
      sanDiegoCity, oceanside, carlsbad
    }
  };
}

// Create sample investors
async function createInvestors(locationData: any) {
  // Los Angeles Investors
  await db.insert(investors).values([
    {
      entityName: "Elite Property Investments",
      location: "Los Angeles, CA",
      lastPurchaseDate: new Date("2024-03-15"),
      totalTransactions: 75,
      avgPurchasePrice: 804000,
      avgResalePrice: 1013000,
      purchaseToFutureValueRatio: 0.864,
      listToSoldPriceRatio: 0.928,
      purchaseToMarketRatio: 0.78,
      purchaseToResaleRatio: 0.83,
      financingType: "Cash",
      agentRelationships: "12/5/3/4",
      lastPropertyNumber: "APD-2024-0315",
      lastPropertyAddress: "123 Main St",
      lastPropertyCity: "Los Angeles",
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.losAngelesCity.id,
      address: "789 Corporate Ave, Los Angeles, CA 90024"
    },
    {
      entityName: "Westside Holdings",
      location: "Los Angeles, CA",
      lastPurchaseDate: new Date("2024-02-20"),
      totalTransactions: 42,
      avgPurchasePrice: 720000,
      avgResalePrice: 895000,
      purchaseToFutureValueRatio: 0.85,
      listToSoldPriceRatio: 0.94,
      purchaseToMarketRatio: 0.81,
      purchaseToResaleRatio: 0.8,
      financingType: "Mixed",
      agentRelationships: "8/3/2/1",
      lastPropertyNumber: "WH-2024-0220",
      lastPropertyAddress: "456 Sunset Blvd",
      lastPropertyCity: "Los Angeles",
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.losAngelesCity.id,
      address: "1200 Wilshire Blvd, Los Angeles, CA 90017"
    },
    {
      entityName: "Pacific Acquisition Group",
      location: "Long Beach, CA",
      lastPurchaseDate: new Date("2024-03-05"),
      totalTransactions: 28,
      avgPurchasePrice: 625000,
      avgResalePrice: 815000,
      purchaseToFutureValueRatio: 0.89,
      listToSoldPriceRatio: 0.96,
      purchaseToMarketRatio: 0.77,
      purchaseToResaleRatio: 0.85,
      financingType: "Conventional",
      agentRelationships: "5/2/1/2",
      lastPropertyNumber: "PAG-2024-0305",
      lastPropertyAddress: "789 Ocean Dr",
      lastPropertyCity: "Long Beach",
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.longBeach.id,
      address: "555 Ocean Blvd, Long Beach, CA 90802"
    }
  ]);

  // Orange County Investors
  await db.insert(investors).values([
    {
      entityName: "Newport Coastal Investments",
      location: "Newport Beach, CA",
      lastPurchaseDate: new Date("2024-01-12"),
      totalTransactions: 32,
      avgPurchasePrice: 1250000,
      avgResalePrice: 1575000,
      purchaseToFutureValueRatio: 0.82,
      listToSoldPriceRatio: 0.91,
      purchaseToMarketRatio: 0.73,
      purchaseToResaleRatio: 0.79,
      financingType: "Cash",
      agentRelationships: "7/4/2/1",
      lastPropertyNumber: "NCI-2024-0112",
      lastPropertyAddress: "123 Harbor View",
      lastPropertyCity: "Newport Beach",
      countyId: locationData.counties.orange.id,
      cityId: locationData.cities.newportBeach.id,
      address: "2400 Pacific Coast Hwy, Newport Beach, CA 92660"
    },
    {
      entityName: "Irvine Capital Partners",
      location: "Irvine, CA",
      lastPurchaseDate: new Date("2024-02-05"),
      totalTransactions: 48,
      avgPurchasePrice: 950000,
      avgResalePrice: 1200000,
      purchaseToFutureValueRatio: 0.87,
      listToSoldPriceRatio: 0.95,
      purchaseToMarketRatio: 0.8,
      purchaseToResaleRatio: 0.85,
      financingType: "Mixed",
      agentRelationships: "10/6/3/2",
      lastPropertyNumber: "ICP-2024-0205",
      lastPropertyAddress: "456 University Dr",
      lastPropertyCity: "Irvine",
      countyId: locationData.counties.orange.id,
      cityId: locationData.cities.irvine.id,
      address: "100 Technology Dr, Irvine, CA 92602"
    }
  ]);
  
  // San Diego Investors
  await db.insert(investors).values([
    {
      entityName: "Oceanfront Acquisitions",
      location: "San Diego, CA",
      lastPurchaseDate: new Date("2024-03-01"),
      totalTransactions: 36,
      avgPurchasePrice: 875000,
      avgResalePrice: 1085000,
      purchaseToFutureValueRatio: 0.86,
      listToSoldPriceRatio: 0.93,
      purchaseToMarketRatio: 0.76,
      purchaseToResaleRatio: 0.82,
      financingType: "Conventional",
      agentRelationships: "8/3/2/1",
      lastPropertyNumber: "OA-2024-0301",
      lastPropertyAddress: "789 Coastal Hwy",
      lastPropertyCity: "San Diego",
      countyId: locationData.counties.sanDiego.id,
      cityId: locationData.cities.sanDiegoCity.id,
      address: "750 B Street, San Diego, CA 92101"
    }
  ]);
}

// Create sample agents
async function createAgents(locationData: any) {
  // Los Angeles Agents
  await db.insert(agents).values([
    {
      agentName: "James Smith",
      avgTransactionPrice: 785000,
      totalTransactionsWithInvestors: 42,
      listingsSoldToInvestors: 25,
      percentageDoubleEndTransactions: 0.18,
      mostRecentBuyerTransaction: new Date("2024-03-10"),
      officeRepresentingBuyers: "LA Premier Realty",
      listingsResoldForInvestors: 18,
      uniqueInvestorRelationships: 12,
      lastInvestorProperty: "123 Highland Ave, Los Angeles",
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.losAngelesCity.id,
      address: "8500 Beverly Blvd, Los Angeles, CA 90048"
    },
    {
      agentName: "Sarah Johnson",
      avgTransactionPrice: 650000,
      totalTransactionsWithInvestors: 28,
      listingsSoldToInvestors: 16,
      percentageDoubleEndTransactions: 0.25,
      mostRecentBuyerTransaction: new Date("2024-02-15"),
      officeRepresentingBuyers: "Westside Properties",
      listingsResoldForInvestors: 12,
      uniqueInvestorRelationships: 8,
      lastInvestorProperty: "456 Venice Blvd, Los Angeles",
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.losAngelesCity.id,
      address: "9454 Wilshire Blvd, Beverly Hills, CA 90212"
    },
    {
      agentName: "Michael Rodriguez",
      avgTransactionPrice: 720000,
      totalTransactionsWithInvestors: 35,
      listingsSoldToInvestors: 22,
      percentageDoubleEndTransactions: 0.12,
      mostRecentBuyerTransaction: new Date("2024-03-05"),
      officeRepresentingBuyers: "Long Beach Realty",
      listingsResoldForInvestors: 15,
      uniqueInvestorRelationships: 9,
      lastInvestorProperty: "789 Ocean Dr, Long Beach",
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.longBeach.id,
      address: "200 Ocean Blvd, Long Beach, CA 90802"
    }
  ]);
  
  // Orange County Agents
  await db.insert(agents).values([
    {
      agentName: "Jennifer Lee",
      avgTransactionPrice: 1150000,
      totalTransactionsWithInvestors: 32,
      listingsSoldToInvestors: 18,
      percentageDoubleEndTransactions: 0.15,
      mostRecentBuyerTransaction: new Date("2024-02-20"),
      officeRepresentingBuyers: "Coastal Properties",
      listingsResoldForInvestors: 14,
      uniqueInvestorRelationships: 10,
      lastInvestorProperty: "123 Harbor Way, Newport Beach",
      countyId: locationData.counties.orange.id,
      cityId: locationData.cities.newportBeach.id,
      address: "1100 Newport Center Dr, Newport Beach, CA 92660"
    },
    {
      agentName: "David Chen",
      avgTransactionPrice: 895000,
      totalTransactionsWithInvestors: 40,
      listingsSoldToInvestors: 24,
      percentageDoubleEndTransactions: 0.22,
      mostRecentBuyerTransaction: new Date("2024-03-01"),
      officeRepresentingBuyers: "Irvine Real Estate",
      listingsResoldForInvestors: 16,
      uniqueInvestorRelationships: 11,
      lastInvestorProperty: "456 Spectrum Ctr, Irvine",
      countyId: locationData.counties.orange.id,
      cityId: locationData.cities.irvine.id,
      address: "5 Park Plaza, Irvine, CA 92614"
    }
  ]);
  
  // San Diego Agents
  await db.insert(agents).values([
    {
      agentName: "Robert Williams",
      avgTransactionPrice: 825000,
      totalTransactionsWithInvestors: 35,
      listingsSoldToInvestors: 20,
      percentageDoubleEndTransactions: 0.17,
      mostRecentBuyerTransaction: new Date("2024-02-25"),
      officeRepresentingBuyers: "San Diego Coastal",
      listingsResoldForInvestors: 15,
      uniqueInvestorRelationships: 9,
      lastInvestorProperty: "789 Harbor Dr, San Diego",
      countyId: locationData.counties.sanDiego.id,
      cityId: locationData.cities.sanDiegoCity.id,
      address: "550 Front St, San Diego, CA 92101"
    }
  ]);
}

// Create sample offices
async function createOffices(locationData: any) {
  // Los Angeles Offices
  await db.insert(offices).values([
    {
      officeName: "LA Premier Realty",
      avgTransactionPrice: 810000,
      totalTransactionsWithInvestors: 124,
      listingsSoldToInvestors: 75,
      buyerRepresentationTransactions: 49,
      listingsResoldForInvestors: 45,
      uniqueInvestorRelationships: 28,
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.losAngelesCity.id,
      address: "9000 Sunset Blvd, West Hollywood, CA 90069"
    },
    {
      officeName: "Westside Properties",
      avgTransactionPrice: 765000,
      totalTransactionsWithInvestors: 92,
      listingsSoldToInvestors: 56,
      buyerRepresentationTransactions: 36,
      listingsResoldForInvestors: 35,
      uniqueInvestorRelationships: 22,
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.losAngelesCity.id,
      address: "10880 Wilshire Blvd, Los Angeles, CA 90024"
    },
    {
      officeName: "Long Beach Realty",
      avgTransactionPrice: 685000,
      totalTransactionsWithInvestors: 78,
      listingsSoldToInvestors: 45,
      buyerRepresentationTransactions: 33,
      listingsResoldForInvestors: 32,
      uniqueInvestorRelationships: 18,
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.longBeach.id,
      address: "450 Ocean Blvd, Long Beach, CA 90802"
    }
  ]);
  
  // Orange County Offices
  await db.insert(offices).values([
    {
      officeName: "Coastal Properties",
      avgTransactionPrice: 1250000,
      totalTransactionsWithInvestors: 68,
      listingsSoldToInvestors: 42,
      buyerRepresentationTransactions: 26,
      listingsResoldForInvestors: 30,
      uniqueInvestorRelationships: 15,
      countyId: locationData.counties.orange.id,
      cityId: locationData.cities.newportBeach.id,
      address: "1200 Newport Center Dr, Newport Beach, CA 92660"
    },
    {
      officeName: "Irvine Real Estate",
      avgTransactionPrice: 925000,
      totalTransactionsWithInvestors: 88,
      listingsSoldToInvestors: 54,
      buyerRepresentationTransactions: 34,
      listingsResoldForInvestors: 38,
      uniqueInvestorRelationships: 20,
      countyId: locationData.counties.orange.id,
      cityId: locationData.cities.irvine.id,
      address: "2600 Michelson Dr, Irvine, CA 92612"
    }
  ]);
  
  // San Diego Offices
  await db.insert(offices).values([
    {
      officeName: "San Diego Coastal",
      avgTransactionPrice: 875000,
      totalTransactionsWithInvestors: 72,
      listingsSoldToInvestors: 45,
      buyerRepresentationTransactions: 27,
      listingsResoldForInvestors: 32,
      uniqueInvestorRelationships: 16,
      countyId: locationData.counties.sanDiego.id,
      cityId: locationData.cities.sanDiegoCity.id,
      address: "600 B Street, San Diego, CA 92101"
    }
  ]);
}

// Create sample lenders
async function createLenders(locationData: any) {
  // Los Angeles Lenders
  await db.insert(lenders).values([
    {
      lenderName: "Pacific Coast Financial",
      avgLoanAmount: 685000,
      avgLoanToPurchasePriceRatio: 0.75,
      totalTransactionsToInvestors: 85,
      uniqueInvestorRelationships: 24,
      avgLoansPerRelationship: 3.5,
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.losAngelesCity.id,
      address: "800 Wilshire Blvd, Los Angeles, CA 90017"
    },
    {
      lenderName: "First Capital Group",
      avgLoanAmount: 615000,
      avgLoanToPurchasePriceRatio: 0.68,
      totalTransactionsToInvestors: 72,
      uniqueInvestorRelationships: 19,
      avgLoansPerRelationship: 3.8,
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.losAngelesCity.id,
      address: "515 S Flower St, Los Angeles, CA 90071"
    },
    {
      lenderName: "Long Beach Mortgage Co",
      avgLoanAmount: 575000,
      avgLoanToPurchasePriceRatio: 0.78,
      totalTransactionsToInvestors: 45,
      uniqueInvestorRelationships: 13,
      avgLoansPerRelationship: 3.4,
      countyId: locationData.counties.losAngeles.id,
      cityId: locationData.cities.longBeach.id,
      address: "100 Oceangate, Long Beach, CA 90802"
    }
  ]);
  
  // Orange County Lenders
  await db.insert(lenders).values([
    {
      lenderName: "Newport Investment Bank",
      avgLoanAmount: 985000,
      avgLoanToPurchasePriceRatio: 0.72,
      totalTransactionsToInvestors: 52,
      uniqueInvestorRelationships: 14,
      avgLoansPerRelationship: 3.7,
      countyId: locationData.counties.orange.id,
      cityId: locationData.cities.newportBeach.id,
      address: "520 Newport Center Dr, Newport Beach, CA 92660" 
    },
    {
      lenderName: "Irvine Funding Partners",
      avgLoanAmount: 795000,
      avgLoanToPurchasePriceRatio: 0.76,
      totalTransactionsToInvestors: 65,
      uniqueInvestorRelationships: 17,
      avgLoansPerRelationship: 3.8,
      countyId: locationData.counties.orange.id,
      cityId: locationData.cities.irvine.id,
      address: "18500 Von Karman Ave, Irvine, CA 92612"
    }
  ]);
  
  // San Diego Lenders
  await db.insert(lenders).values([
    {
      lenderName: "San Diego Capital",
      avgLoanAmount: 685000,
      avgLoanToPurchasePriceRatio: 0.74,
      totalTransactionsToInvestors: 55,
      uniqueInvestorRelationships: 15,
      avgLoansPerRelationship: 3.6,
      countyId: locationData.counties.sanDiego.id,
      cityId: locationData.cities.sanDiegoCity.id,
      address: "225 Broadway, San Diego, CA 92101"
    }
  ]);
}

// Create sample communication data
async function createCommunicationData() {
  // Get some entities to associate contacts with
  const allInvestors = await db.select().from(investors);
  const allAgents = await db.select().from(agents);
  const allOffices = await db.select().from(offices);
  const allLenders = await db.select().from(lenders);

  // Templates
  await db.insert(templates).values([
    {
      key: "investor_intro_email",
      name: "Investor Introduction Email",
      channel: "EMAIL",
      body: "Hello {{name}},\n\nI noticed your investment activity in {{location}} and wanted to connect. I specialize in helping investors like you find great opportunities.\n\nLet's schedule a call to discuss how I can help with your investment strategy.\n\nBest regards,\nYour Name",
      variables: JSON.stringify(["name", "location"]),
      followUp: JSON.stringify({ days: 3, template: "investor_follow_up" }),
    },
    {
      key: "agent_intro_sms",
      name: "Agent Introduction SMS",
      channel: "SMS",
      body: "Hi {{name}}, I'm reaching out about potential collaboration on investor clients. I have buyers looking in your area. Let's connect! Reply YES for more info.",
      variables: JSON.stringify(["name"]),
      followUp: JSON.stringify({ days: 2, template: "agent_follow_up" }),
    },
    {
      key: "lender_intro_call",
      name: "Lender Introduction Call Script",
      channel: "CALL",
      body: "Hello, this is [Your Name] calling for {{name}}. I'm reaching out because I work with investors who are looking for financing options. I'd love to learn more about your lending programs for investors and how we might work together. Do you have a few minutes to chat?",
      variables: JSON.stringify(["name"]),
      followUp: null,
    }
  ]);

  // Contacts - create a few sample contacts
  const [investorContact1] = await db.insert(contacts).values({
    type: "INVESTOR",
    name: allInvestors[0].entityName,
    phone: "+13105551234",
    email: "contact@elitepropertyinvestments.com",
    entityId: allInvestors[0].id,
    optOut: false,
    notes: "Met at investment conference in January",
  }).returning();

  const [agentContact1] = await db.insert(contacts).values({
    type: "AGENT",
    name: allAgents[0].agentName,
    phone: "+12135557890",
    email: "james.smith@lapremierrealty.com",
    entityId: allAgents[0].id,
    optOut: false,
    notes: "Works primarily with high-end properties",
  }).returning();

  const [lenderContact1] = await db.insert(contacts).values({
    type: "LENDER",
    name: allLenders[0].lenderName,
    phone: "+13235559876",
    email: "loans@pacificcoastfinancial.com",
    entityId: allLenders[0].id,
    optOut: false,
    notes: "Offers special rates for repeat investors",
  }).returning();

  // Conversations
  await db.insert(conversations).values([
    {
      contactId: investorContact1.id,
      channel: "EMAIL",
      direction: "OUTBOUND",
      body: "Hello Elite Property Investments,\n\nI noticed your recent acquisition in Los Angeles and wanted to connect. I have some off-market properties that might interest you.\n\nLet's schedule a call to discuss these opportunities.\n\nBest regards,\nJohn Doe",
      status: "DELIVERED",
      timestamp: new Date("2024-03-10T14:30:00"),
      metadata: JSON.stringify({ campaign: "march_outreach" }),
      externalId: "msg_123456",
    },
    {
      contactId: investorContact1.id,
      channel: "EMAIL",
      direction: "INBOUND",
      body: "Hi John,\n\nThanks for reaching out. We're always interested in off-market opportunities in the Los Angeles area.\n\nLet's connect next week. Would Tuesday at 2pm work for you?\n\nRegards,\nElite Property Investments",
      status: "DELIVERED",
      timestamp: new Date("2024-03-11T09:15:00"),
      metadata: null,
      externalId: "msg_123457",
    },
    {
      contactId: agentContact1.id,
      channel: "SMS",
      direction: "OUTBOUND",
      body: "Hi James, I'm reaching out about potential collaboration on investor clients. I have buyers looking in your area. Let's connect!",
      status: "DELIVERED",
      timestamp: new Date("2024-03-12T11:00:00"),
      metadata: null,
      externalId: "sms_789012",
    },
    {
      contactId: lenderContact1.id,
      channel: "CALL",
      direction: "OUTBOUND",
      body: "Called to discuss financing options for investor clients. Spoke with loan manager who recommended setting up a formal meeting next week.",
      status: "COMPLETE",
      timestamp: new Date("2024-03-14T15:45:00"),
      metadata: JSON.stringify({ duration: "00:08:32", recorded: false }),
      externalId: "call_345678",
    }
  ]);

  // AI Tasks
  await db.insert(aiTasks).values([
    {
      contactId: investorContact1.id,
      templateKey: "investor_intro_email",
      dueAt: new Date("2024-03-20T10:00:00"),
      status: "PENDING",
      threadId: null,
      result: null,
    },
    {
      contactId: agentContact1.id,
      templateKey: "agent_intro_sms",
      dueAt: new Date("2024-03-18T14:00:00"),
      status: "COMPLETE",
      threadId: "thread_abcdef",
      result: "Agent responded positively and requested more information about our investor clients. Follow-up meeting scheduled.",
      completedAt: new Date("2024-03-18T14:30:00"),
    }
  ]);

  // Corporation data
  await db.insert(corporations).values([
    {
      name: "Elite Property Investments LLC",
      address: "789 Corporate Ave, Los Angeles, CA 90024",
      filingNumber: "202401234567",
      status: "Active",
      registeredAgent: "Corporate Services Inc.",
      officerName: "John Smith",
      officerAddress: "789 Corporate Ave, Los Angeles, CA 90024",
      dataSource: "opencorporates",
      fetchedAt: new Date("2024-03-01T00:00:00"),
      rawData: JSON.stringify({
        company_number: "202401234567",
        jurisdiction_code: "us_ca",
        incorporation_date: "2020-05-15",
        company_type: "Limited Liability Company",
        registry_url: "https://opencorporates.com/companies/us_ca/202401234567"
      }),
    },
    {
      name: "Newport Coastal Investments LLC",
      address: "2400 Pacific Coast Hwy, Newport Beach, CA 92660",
      filingNumber: "202106789012",
      status: "Active",
      registeredAgent: "Legal Agents Inc.",
      officerName: "Emily Chen",
      officerAddress: "2400 Pacific Coast Hwy, Newport Beach, CA 92660",
      dataSource: "opencorporates",
      fetchedAt: new Date("2024-02-15T00:00:00"),
      rawData: JSON.stringify({
        company_number: "202106789012",
        jurisdiction_code: "us_ca",
        incorporation_date: "2021-03-10",
        company_type: "Limited Liability Company",
        registry_url: "https://opencorporates.com/companies/us_ca/202106789012"
      }),
    }
  ]);
}

// Main function to seed the database
async function seedDatabase() {
  try {
    // Clear existing data
    await clearData();
    console.log("Cleared existing data");

    // Create sample data
    const locationData = await createLocations();
    console.log("Created locations");

    await createInvestors(locationData);
    console.log("Created investors");

    await createAgents(locationData);
    console.log("Created agents");

    await createOffices(locationData);
    console.log("Created offices");

    await createLenders(locationData);
    console.log("Created lenders");

    await createCommunicationData();
    console.log("Created communication data");

    console.log("Database seeded successfully");
    process.exit(0);
  } catch (error) {
    console.error("Error seeding database:", error);
    process.exit(1);
  }
}

// Run the seeding function
seedDatabase();